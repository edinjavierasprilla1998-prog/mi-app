/* Finanzas + Jornada — viaje.js: registro rápido de viaje con pagos flexibles (Etapa 5).
   Carrera nueva: {id,t,v,p,ap,pg:[{k:'a'|'b',b,v}],tf,cm,pb}
     v  = suma de las líneas (lo que realmente recibes)   p = propina (pb = billetera de la propina)
     pg = líneas de pago: k:'b' → billetera b ; k:'a' → saldo de la app ap (tarjeta)
     tf = tarifa total del viaje (si es mayor que v, la diferencia es «comisión / no acreditado»)   cm = comisión de la app (resta del saldo y cuenta como costo)
   Las carreras antiguas (sin pg) no cambian: siguen acreditando a 'Dinero digital' (valor) y 'Propinas' (propina). */
var VJ = { rows: [], tot: '', auto: true, edit: null, ap: null };
function vjApps() { return apList().filter(function (a) { return !a.arch }) }
function vjApSel() { var l = vjApps(); return l.some(function (a) { return a.id === S.apu }) ? S.apu : (l[0] ? l[0].id : null) }
function vjMetodos() { return BIL.filter(function (k) { var w = bwList().filter(function (x) { return x.k === k })[0]; return w && w.pay }) }
function vjLineTxt(l) { return l.k === 'a' ? '💳 App' : esc(wl(l.b)) }
function vjDet(c, ji) {
  if (!Array.isArray(c.pg)) return '📱 Digital';
  return (c.ap ? esc(apNom(c.ap)) + ' · ' : '') + c.pg.map(function (l) { return vjLineTxt(l) + ' ' + cop(l.v) }).join(' · ') + (c.cm ? ' · comisión −' + cop(c.cm) : '') + (c.tf && c.tf - c.v > 0.005 ? ' · sin acreditar ' + cop(c.tf - c.v) : '') + cpDetTxt(c, ji)
}
/* ---------- formulario rápido (pestaña Jornada) ---------- */
function vjForm() {
  var ap = vjApSel(), met = vjMetodos(), ps = BIL;
  return '<h2>🚕 Registrar viaje</h2><div class="card form">' +
    (vjApps().length ? '<div class="seg">' + vjApps().map(function (a) { return '<button class="' + (a.id === ap ? 'on' : '') + '" onclick="vjAp(\'' + a.id + '\')">' + esc(a.nom) + '</button>' }).join('') + '</div>' : '') +
    (ap ? '<small class="pase">' + apPaseTxt(ap) + (apPaseAct(ap) ? ' <button class="mini bad" onclick="apPaseQuitar(\'' + ap + '\')">🗑️ Quitar</button>' : '') + '</small>' : '') + '<label>Monto del viaje<input id="vm" type="number" inputmode="numeric" min="0" placeholder="0" class="vm"></label>' +
    '<small style="display:block;margin:-4px 0 8px;font-weight:600">¿Cómo te pagaron? Toca y se guarda</small>' +
    '<div class="mg"><button onclick="vjRapido(\'a\')"><span>💳</span>App</button>' +
    met.map(function (k, i) { return '<button onclick="vjRapido(' + i + ')"><span>' + esc(BI[k] || '👛') + '</span>' + esc(bn(k)) + '</button>' }).join('') +
    '<button class="cb2" onclick="vjRapido(\'c\')"><span>➗</span>Combinado</button></div>' +
    '<button class="btn out sm" onclick="var x=$(\'#vx\');x.style.display=x.style.display===\'block\'?\'none\':\'block\'">➕ Propina / comisión</button>' +
    '<div id="vx" style="display:none"><div class="two"><label>Propina<input id="vp" type="number" inputmode="numeric" min="0" placeholder="0"></label><label>Comisión app<input id="vc" type="number" inputmode="numeric" min="0" placeholder="0"></label></div>' +
    '<label>La propina va a' + bilSel('vpb', BIL.indexOf('Propinas') >= 0 ? 'Propinas' : BIL[0]) + '</label></div>' +
    cpQHTML() + '<button class="btn out sm" onclick="vjRepetir()">🔁 Repetir último viaje</button></div>'
}
function vjAp(id) { S.apu = id; sv(); var v = ($('#vm') || {}).value; render(); if (v && $('#vm')) $('#vm').value = v }
function vjExtra() { return { ap: vjApSel(), p: num('#vp') || 0, cm: num('#vc') || 0, pb: ($('#vpb') || {}).value || 'Propinas', cp: CPQ.id || null, rf: (CPQ.rf || '').trim() } }
function vjRapido(m) {
  var j = act(); if (!j) return;
  if (m === 'c') { vjCombi(false); return }
  var v = num('#vm');
  if (!(v > 0)) { toast('Escribe el monto del viaje'); if ($('#vm')) $('#vm').focus(); return }
  var ex = vjExtra(), line = m === 'a' ? { k: 'a', v: v } : { k: 'b', b: vjMetodos()[m], v: v };
  if (line.k === 'b' && !line.b) return;
  vjGuardar(j, [line], v, ex)
}
function vjGuardar(j, lines, tf, ex) {
  var sum = 0; lines.forEach(function (l) { sum += l.v });
  if (!(sum > 0)) { toast('Escribe un monto mayor que 0'); return false }
  if (!(ex.p >= 0) || !(ex.cm >= 0)) { toast('Revisa la propina y la comisión'); return false }
  var n = Date.now(), l0 = j.ca[j.ca.length - 1], pg = JSON.stringify(lines);
  if (l0 && l0.v === sum && l0.p === ex.p && n - l0.t < 3000 && JSON.stringify(l0.pg) === pg) { toast('Viaje repetido, ignorado'); return false }
  var c = { id: uid(), t: n, v: sum, p: ex.p, ap: ex.ap, pg: lines, tf: tf || sum, cm: ex.cm, pb: ex.p > 0 ? ex.pb : null };
  if (ex.cp) c.cp = ex.cp; if (ex.rf) c.rf = ex.rf; if (ex.cp && ex.cp === CPQ.id) cpQLimpiar();
  j.ca.push(c); S.apu = ex.ap; sv(); render();
  toastU('✅ ' + cop(sum) + ' · ' + lines.map(function (l) { return l.k === 'a' ? '💳 App' : wl(l.b) }).join(' + '), function () { j.ca = j.ca.filter(function (x) { return x.id !== c.id }); cpDel(c.cp); sv(); render() });
  if (lines.some(function (l) { return l.k === 'a' }) && !apPaseAct(ex.ap) && !(S.apq && S.apq[ex.ap] > n)) setTimeout(function () { apPaseAsk(ex.ap) }, 350);
  return true
}
function vjUltimo() {
  var u = null;
  S.j.forEach(function (j) { j.ca.forEach(function (c) { if (!u || c.t > u.t) u = c }) });
  return u
}
function vjRepetir() {
  var j = act(), u = vjUltimo(); if (!j) return;
  if (!u) { toast('Aún no hay viajes para repetir'); return }
  var lines = Array.isArray(u.pg) ? u.pg.map(function (l) { return { k: l.k, b: l.b, v: l.v } }) : [{ k: 'b', b: 'Dinero digital', v: u.v }];
  vjGuardar(j, lines, u.tf || u.v, { ap: u.ap || vjApSel(), p: u.p || 0, cm: u.cm || 0, pb: u.pb || 'Propinas' })
}

/* ---------- pago combinado / editar viaje ---------- */
function vjOpts(sel) {
  var ks = vjMetodos(); if (sel !== 'a' && ks.indexOf(sel) < 0 && BILX.indexOf(sel) >= 0) ks = ks.concat([sel]);
  return '<option value="a"' + (sel === 'a' ? ' selected' : '') + '>💳 App (saldo de la app)</option>' + ks.map(function (k) { return '<option value="' + esc(k) + '"' + (sel === k ? ' selected' : '') + '>' + esc(wl(k)) + '</option>' }).join('')
}
function vjCombi(edit, ji, ci) {
  var c = null, j = null;
  if (edit) { j = jf(ji); c = j && j.ca.filter(function (x) { return x.id === ci })[0]; if (!c) return }
  var met = vjMetodos();
  VJ = { edit: edit ? { ji: ji, ci: ci } : null, auto: !edit, ap: c ? (c.ap || vjApSel()) : vjApSel(), tot: '', rows: [], p: c ? c.p : '', cm: c ? (c.cm || '') : '', pb: c ? (c.pb || 'Propinas') : 'Propinas', t: c ? c.t : Date.now(), cp: c ? (c.cp || null) : (CPQ.id || null), cpo: c ? (c.cp || null) : null, rf: c ? (c.rf || '') : (CPQ.rf || '') };
  if (c) {
    VJ.tot = c.tf || c.v;
    VJ.rows = Array.isArray(c.pg) ? c.pg.map(function (l) { return { m: l.k === 'a' ? 'a' : l.b, v: l.v } }) : [{ m: 'Dinero digital', v: c.v }]
  } else {
    VJ.tot = num('#vm') || ''; VJ.p = num('#vp') || ''; VJ.cm = num('#vc') || ''; VJ.pb = ($('#vpb') || {}).value || 'Propinas';
    VJ.rows = [{ m: met[0] || 'a', v: '' }, { m: 'a', v: VJ.tot || '' }]
  }
  vjDraw()
}
function vjDraw() {
  var rows = VJ.rows.map(function (r, i) {
    return '<div class="two vr"><select id="vk' + i + '" onchange="vjSync()">' + vjOpts(r.m) + '</select><input id="vv' + i + '" type="number" inputmode="numeric" min="0" placeholder="0" value="' + (r.v === '' ? '' : r.v) + '" oninput="vjSync(' + i + ')"></div>'
  }).join('');
  openM('<h3>' + (VJ.edit ? '✏️ Editar viaje' : '➗ Pago combinado') + '</h3>' +
    '<label>App<select id="vcA">' + vjApps().map(function (a) { return '<option value="' + a.id + '"' + (a.id === VJ.ap ? ' selected' : '') + '>' + esc(a.nom) + '</option>' }).join('') + '</select></label>' +
    '<label>Tarifa total del viaje<input id="vct" type="number" inputmode="numeric" min="0" placeholder="0" value="' + (VJ.tot === '' ? '' : VJ.tot) + '" oninput="vjSync(-1)"></label>' +
    '<small style="display:block;margin-bottom:6px;font-weight:600">¿Cómo se pagó? (método y monto)</small>' + rows +
    '<button class="btn out sm" onclick="vjAdd()">➕ Agregar línea</button><div class="kv" id="vsum"></div>' +
    '<div class="two"><label>Propina<input id="vcp" type="number" inputmode="numeric" min="0" placeholder="0" value="' + (VJ.p === '' ? '' : VJ.p) + '"></label><label>Comisión app<input id="vcc" type="number" inputmode="numeric" min="0" placeholder="0" value="' + (VJ.cm === '' ? '' : VJ.cm) + '"></label></div>' +
    '<label>La propina va a' + bilSel('vcb', VJ.pb) + '</label>' +
 cpBoxHTML() +
    (VJ.edit ? '<label>Fecha y hora<input id="vcf" type="datetime-local" value="' + ldt(VJ.t) + '"></label>' : '') + btns('vjSave()'));
  vjSum()
}
/* i = fila editada (número), -1 = total, undefined = cambió un método */
function vjSync(i) {
  VJ.tot = ($('#vct').value === '' ? '' : parseFloat($('#vct').value));
  VJ.rows.forEach(function (r, k) { r.m = $('#vk' + k).value; var x = $('#vv' + k).value; r.v = x === '' ? '' : parseFloat(x) });
  if (i === 1 && VJ.rows.length === 2) VJ.auto = false;
  if (VJ.auto && VJ.rows.length === 2 && (i === 0 || i === -1)) {
    var r = Math.max(0, (VJ.tot || 0) - (VJ.rows[0].v || 0)); VJ.rows[1].v = r; $('#vv1').value = r || ''
  }
  vjSum()
}
function vjAdd() { vjSync(); VJ.auto = false; VJ.rows.push({ m: vjMetodos()[0] || 'a', v: '' }); vjDraw() }
function vjSum() {
  var s = 0; VJ.rows.forEach(function (r) { if (r.v > 0) s += r.v });
  var t = VJ.tot > 0 ? VJ.tot : s, d = t - s, e = $('#vsum'); if (!e) return;
  e.innerHTML = '<span>Suma de líneas · ' + cop(s) + '</span><b class="' + (d < -0.005 ? 'neg' : '') + '">' + (d < -0.005 ? 'Sobra ' + cop(-d) : d > 0.005 ? 'Sin acreditar ' + cop(d) : '✅ Cuadra') + '</b>'
}
function vjSave() {
  vjSync();
  var lines = [], sum = 0;
  VJ.rows.forEach(function (r) { if (r.v > 0) { lines.push(r.m === 'a' ? { k: 'a', v: r.v } : { k: 'b', b: r.m, v: r.v }); sum += r.v } });
  if (!lines.length) { toast('Agrega al menos una línea con monto'); return }
  var tot = VJ.tot > 0 ? VJ.tot : sum;
  if (sum > tot + 0.005) { toast('Las líneas suman más que la tarifa'); return }
  var ex = { ap: $('#vcA').value, p: num('#vcp') || 0, cm: num('#vcc') || 0, pb: $('#vcb').value, cp: VJ.cp || null, rf: (VJ.rf || '').trim() };
  if (!(ex.p >= 0) || !(ex.cm >= 0)) { toast('Revisa la propina y la comisión'); return }
  if (VJ.edit) {
    var j = jf(VJ.edit.ji), c = j && j.ca.filter(function (x) { return x.id === VJ.edit.ci })[0], t = pdt($('#vcf').value);
    if (!c || t === null) { toast('Revisa la fecha'); return }
    c.v = sum; c.p = ex.p; c.ap = ex.ap; c.pg = lines; c.tf = tot; c.cm = ex.cm; c.pb = ex.p > 0 ? ex.pb : null; c.t = t;
    var rf = (VJ.rf || '').trim(); if (rf) c.rf = rf; else delete c.rf;
    if (VJ.cp) c.cp = VJ.cp; else delete c.cp;
    if (VJ.cpo && VJ.cpo !== VJ.cp) cpDel(VJ.cpo);
    sv(); closeM(); render(); toast('✅ Viaje actualizado'); return
  }
  var j2 = act(); if (!j2) { closeM(); return }
  if (vjGuardar(j2, lines, tot, ex)) closeM()
}
function CE(ji, ci) { vjCombi(true, ji, ci) }
