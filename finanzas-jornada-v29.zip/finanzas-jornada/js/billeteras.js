/* Finanzas + Jornada — billeteras.js: Billeteras flexibles + ajustar saldo (Etapa 5).
   S.bw = {id,k,nom,ico,pay,arch,ua}. Los movimientos guardan la clave k (m.bil); renombrar solo cambia nom.
   Ajustar saldo = movimiento tipo 'ajuste' en S.mv {tipo:'ajuste',bil,v,sg:±1}: mueve el saldo de la billetera, nunca ingresos ni gastos. */
var bwArch = false, BW_ICONS = ['💵', '📱', '📲', '💳', '🏦', '🪙', '👛', '🎁', '💰', '🧾'];
function bwList() { return S.bw || [] }
function bwById(id) { return bwList().filter(function (w) { return w.id === id })[0] }
function bwRefs(k) {
  var n = 0;
  (S.mv || []).forEach(function (m) { if (m.bil === k || m.bil2 === k) n++ });
  ['fm', 'dm', 'pm', 'am'].forEach(function (l) { (S[l] || []).forEach(function (m) { if (m.bil === k) n++ }) });
  (S.j || []).forEach(function (j) { (j.ca || []).forEach(function (c) { if (c.pb === k) n++; (c.pg || []).forEach(function (l) { if (l.b === k) n++ }) }) });
  return n
}
function bwCard(f, w) {
  var x = w[f.k] || { s: 0, i: 0, g: 0, t: 0 };
  return '<div class="li fh"><div class="wr" style="padding:0"><span class="ic">' + esc(f.ico || '👛') + '</span><div class="g"><b>' + esc(f.nom) + (f.arch ? ' 📦' : '') + '</b><br><small>+' + cop(x.i) + ' · −' + cop(x.g) + (x.t ? ' · ↔ ' + cop(x.t) : '') + '</small></div><b class="big ' + (x.s < 0 ? 'neg' : '') + '">' + cop(x.s) + '</b></div>' +
    '<div class="ab"><button class="ed" onclick="bwAjuste(\'' + f.id + '\')">⚖️ Ajustar saldo</button><button class="ed" onclick="bwForm(\'' + f.id + '\')">✏️ Editar</button></div></div>'
}
function vBil() {
  var w = wal(), act = bwList().filter(function (f) { return !f.arch }), arc = bwList().filter(function (f) { return f.arch }), tot = 0;
  BILX.forEach(function (k) { tot += w[k] ? w[k].s : 0 });
  var h = '<div class="tiles">' + st('Total en billeteras', cop(tot)) + st('Billeteras activas', act.length) + '</div>' +
    '<button class="btn" style="margin-top:12px" onclick="bwForm()">➕ Nueva billetera</button><h2>👛 Mis billeteras</h2>' +
    act.map(function (f) { return bwCard(f, w) }).join('');
  if (arc.length) {
    h += '<button class="btn out sm" onclick="bwArch=!bwArch;render()">' + (bwArch ? '🔽' : '▶️') + ' 📦 Archivadas (' + arc.length + ')</button>';
    if (bwArch) h += arc.map(function (f) { return bwCard(f, w) }).join('')
  }
  return h + '<small style="display:block;margin:8px 4px">“Ajustar saldo” cuadra una billetera con lo que realmente tienes. La diferencia queda en el historial como un ajuste y no cuenta como ingreso ni como gasto.</small>'
}
function bwIco(el) {
  $('#wi').value = el.textContent;
  [].forEach.call(document.querySelectorAll('#wig button'), function (b) { b.className = b === el ? 'on' : '' })
}
function bwForm(id) {
  var f = id ? bwById(id) : null; if (id && !f) return;
  var ic = f ? f.ico : '💵', refs = f ? bwRefs(f.k) : 0, borrable = f && id.indexOf('bw_') !== 0 && refs === 0;
  openM('<h3>' + (f ? '✏️ Editar billetera' : '➕ Nueva billetera') + '</h3><label>Nombre<input id="wn" maxlength="20" value="' + esc(f ? f.nom : '') + '" placeholder="Ej. Tarjeta, Bancolombia"></label>' +
    '<small style="display:block;margin-bottom:6px;font-weight:600">Ícono</small><div class="ig" id="wig">' + BW_ICONS.map(function (x) { return '<button type="button" class="' + (x === ic ? 'on' : '') + '" onclick="bwIco(this)">' + x + '</button>' }).join('') + '</div><input id="wi" type="hidden" value="' + esc(ic) + '">' +
    '<label class="ck"><input id="wp" type="checkbox"' + (!f || f.pay ? ' checked' : '') + '> <span>Usar para cobrar viajes</span></label>' +
    (f ? '<button class="btn out sm" onclick="bwArchivar(\'' + id + '\')">' + (f.arch ? '📤 Desarchivar' : '📦 Archivar') + '</button>' : '') +
    (borrable ? '<button class="btn bad sm" onclick="bwDelAsk(\'' + id + '\')">🗑️ Eliminar billetera</button>' : (f ? '<small style="display:block;margin-bottom:10px">No se puede eliminar porque ' + (id.indexOf('bw_') === 0 ? 'es una billetera base' : 'tiene ' + refs + ' registro(s)') + '. Puedes archivarla.</small>' : '')) +
    btns("bwSave('" + (id || '') + "')"))
}
function bwSave(id) {
  var nom = $('#wn').value.trim().replace(/\s+/g, ' '), ico = $('#wi').value || '👛', pay = $('#wp').checked, f = id ? bwById(id) : null;
  if (!nom) { toast('Escribe un nombre'); return }
  if (/['"<>&\\`]/.test(nom)) { toast('El nombre no puede tener comillas ni los símbolos < > & \\'); return }
  if (bwList().some(function (x) { return x.id !== id && x.nom.toLowerCase() === nom.toLowerCase() })) { toast('Ya existe una billetera con ese nombre'); return }
  if (!Array.isArray(S.bw)) S.bw = bwDef();
  var n = Date.now();
  if (f) { f.nom = nom; f.ico = ico; f.pay = pay; f.ua = n }
  else { var k = 'w' + uid(); S.bw.push({ id: k, k: k, nom: nom, ico: ico, pay: pay, arch: false, ua: n }) }
  bilRefresh(); sv(); closeM(); render(); toast(f ? '✅ Billetera actualizada' : '✅ Billetera creada')
}
function bwArchivar(id) {
  var f = bwById(id); if (!f) return;
  if (!f.arch && BIL.length <= 1) { toast('Debe quedar al menos una billetera activa'); return }
  f.arch = !f.arch; f.ua = Date.now(); bilRefresh(); sv(); closeM(); render(); toast(f.arch ? '📦 Archivada' : '📤 Desarchivada')
}
function bwDelAsk(id) {
  var f = bwById(id); if (!f) return;
  openM('<h3>¿Eliminar “' + esc(f.nom) + '”?</h3><p>No tiene movimientos. Esta acción no se puede deshacer.</p><div class="two"><button class="btn out" onclick="closeM()">Cancelar</button><button class="btn bad" onclick="bwDel(\'' + id + '\')">Eliminar</button></div>')
}
function bwDel(id) {
  var f = bwById(id); if (!f || id.indexOf('bw_') === 0 || bwRefs(f.k)) { closeM(); return }
  if (BIL.length <= 1 && !f.arch) { closeM(); toast('Debe quedar al menos una billetera activa'); return }
  S.bw = S.bw.filter(function (x) { return x.id !== id }); bilRefresh(); sv(); closeM(); render(); toast('🗑️ Billetera eliminada')
}
function bwAjuste(id) {
  var f = bwById(id); if (!f) return;
  var s = (wal()[f.k] || { s: 0 }).s;
  openM('<h3>⚖️ Ajustar saldo · ' + esc(f.nom) + '</h3><p>La app registra <b>' + cop(s) + '</b>. Escribe el saldo real y se guarda la diferencia como un ajuste (no cuenta como ingreso ni gasto).</p>' +
    '<label>Saldo real<input id="ws" type="number" inputmode="decimal" placeholder="' + Math.round(s) + '"></label><label>Nota (opcional)<input id="wnn" maxlength="60" placeholder="Ej. Diferencia con la app"></label>' + btns("bwAjSave('" + id + "')"))
}
function bwAjSave(id) {
  var f = bwById(id), real = num('#ws'); if (!f) { closeM(); return }
  if (real === null) { toast('Escribe el saldo real'); return }
  var s = (wal()[f.k] || { s: 0 }).s, d = Math.round((real - s) * 100) / 100;
  if (Math.abs(d) < 0.005) { closeM(); toast('✅ Ya coincide'); return }
  var n = Date.now(); S.mv.push({ id: uid(), t: n, tipo: 'ajuste', cat: 'Ajuste de saldo', bil: f.k, bil2: null, v: Math.abs(d), sg: d > 0 ? 1 : -1, nota: $('#wnn').value.trim().slice(0, 60), cr: n });
  sv(); closeM(); render(); toast('⚖️ Saldo ajustado (' + (d > 0 ? '+' : '−') + cop(Math.abs(d)) + ')')
}
