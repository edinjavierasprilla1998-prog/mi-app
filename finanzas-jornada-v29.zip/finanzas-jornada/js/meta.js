/* Finanzas + Jornada — meta.js (Etapa 10): meta de la jornada en horas EFECTIVAS (sin pausas), con minutos,
   pausas previstas, salida estimada que se corrige sola, progreso, avisos y recordatorio de pausa.
   Campos nuevos (opcionales; las jornadas antiguas siguen como horas corridas):
   j.mt = 'e' (efectivas) | 't' (corridas) · j.pv = [{n:categoría de pausa, m:minutos previstos}] · S.jc = última elección + avisos {mt,h,mn,pv:[{n,m,on}],av,id}. */
function jcCfg() {
  var c = S.jc || {}, pv = Array.isArray(c.pv) ? c.pv : [{ n: 'Desayuno', m: 30, on: true }, { n: 'Almuerzo', m: 45, on: true }];
  return {
    po: c.po !== false, mt: c.mt === 't' ? 't' : 'e', h: c.h >= 0 && c.h <= 24 ? Math.floor(c.h) : 8, mn: c.mn >= 0 && c.mn < 60 ? Math.floor(c.mn) : 0,
    pv: pv.filter(function (x) { return x && typeof x.n === 'string' && x.m > 0 }).map(function (x) { return { n: x.n, m: +x.m, on: x.on !== false, mm: x.mm === true } }),
    av: c.av != null && c.av >= 0 ? +c.av : 30, id: c.id != null && c.id >= 0 ? +c.id : 90
  }
}
/* Lee el formulario de inicio (si está en pantalla) y devuelve la configuración. */
function jfLeer() {
  var c = jcCfg(); if (!$('#ih')) return c;
  c.h = Math.max(0, Math.floor(num('#ih') || 0)); c.mn = Math.min(59, Math.max(0, Math.floor(num('#imn') || 0)));
  c.mt = $('#imt').value === 't' ? 't' : 'e';
  document.querySelectorAll('.jfc').forEach(function (e) { var i = +e.dataset.i; if (c.pv[i]) { c.pv[i].on = e.checked; var m = parseFloat(document.querySelector('.jfm[data-i="' + i + '"]').value); if (m === 0) c.pv[i].on = false; if (m > 0) { c.pv[i].m = Math.round(m); var pr = jPromPausa(c.pv[i].n); c.pv[i].mm = !(pr && Math.round(m) === pr.m) } } });
  return c
}
function jfRender() { var k = $('#ik'), v = k ? k.value : ''; render(); var k2 = $('#ik'); if (k2) k2.value = v }
function jfPrev() {
  var c = jfLeer(), ms = (c.h * 60 + c.mn) * 60000, p = 0; if (c.mt === 'e' && c.po) c.pv.forEach(function (x) { if (x.on) p += x.m * 60000 });
  var e = $('#jfp'); if (!e) return; var t = Date.now() + ms, f = function (x) { return hm(x) + (dk(x) !== dk(Date.now()) ? ' (+1 día)' : '') };
  e.textContent = ms > 0 ? (p ? 'Si inicias ahora, terminarías hacia ' + f(t) + ' sin pausas, o hacia ' + f(t + p) + ' con las previstas (' + dm(p) + ')' : 'Si inicias ahora, terminarías hacia ' + f(t) + (c.mt === 'e' ? ' más las pausas que hagas' : '')) : ''
}
function jfOn(on) { var c = jfLeer(); c.po = !!on; S.jc = Object.assign({}, S.jc, { po: c.po, mt: c.mt, h: c.h, mn: c.mn, pv: c.pv }); sv(); jfRender() }
function jfSet(i, m) { var e = document.querySelector('.jfm[data-i="' + i + '"]'); if (e) { e.value = m; jfPrev() } }
/* Sugerencia inteligente: las pausas que haces la mayoría de tus días (50 % o más), con tu promedio real, ordenadas por hora habitual. */
function jfSug() {
  var H = jHist(); if (H.nj < 3) { toast('Aún no hay suficientes jornadas para sugerir (mínimo 3 terminadas)'); return }
  var L = Object.keys(H.P).map(function (n) { return { n: n, pr: jPromPausa(n) } }).filter(function (x) { return x.pr && x.pr.fr >= 0.5 }).sort(function (a, b) { return a.pr.hr - b.pr.hr });
  if (!L.length) { toast('No tienes pausas que repitas la mayoría de los días'); return }
  var c = jfLeer(); c.po = true; c.pv = L.map(function (x) { return { n: x.n, m: x.pr.m, on: true, mm: false } });
  S.jc = Object.assign({}, S.jc, { po: true, mt: c.mt, h: c.h, mn: c.mn, pv: c.pv }); sv(); jfRender(); toast('✨ Puse tus pausas habituales')
}
function jfQ(h) { $('#ih').value = h; $('#imn').value = 0; jfPrev() }
function jfAdd() {
  var c = jfLeer(), m = Math.round(num('#jfm') || 0), n = $('#jfn').value; if (!(m > 0) || m > 600) { toast('Pon los minutos de la pausa'); return }
  var x = c.pv.filter(function (p) { return p.n === n })[0]; if (x) { x.m = m; x.on = true; x.mm = true } else c.pv.push({ n: n, m: m, on: true, mm: true });
  S.jc = c; sv(); jfRender()
}
function jfDel(i) { var c = jfLeer(); c.pv.splice(i, 1); S.jc = c; sv(); jfRender() }
function jfHTML() {
  var c = jcCfg(), o = function (v, t) { return '<option value="' + v + '"' + (c.mt === v ? ' selected' : '') + '>' + t + '</option>' }, H = jHist();
  var rows = c.pv.map(function (x, i) {
    var pr = jPromPausa(x.n), vm = x.mm || !pr ? x.m : pr.m;
    return '<div style="margin-bottom:10px"><div class="row" style="align-items:center;gap:8px"><label class="ck" style="flex:1;margin:0"><input type="checkbox" class="jfc" data-i="' + i + '" ' + (x.on ? 'checked' : '') + ' onchange="jfPrev()"> <span>' + esc(x.n) + '</span></label>' +
      '<input class="jfm" data-i="' + i + '" type="number" inputmode="numeric" min="0" max="600" value="' + vm + '" style="width:72px" oninput="jfPrev()"><small>min</small><button class="mini" aria-label="Quitar" onclick="jfDel(' + i + ')">✕</button></div>' +
      '<div class="hg" style="margin-top:4px">' + [15, 30, 45, 60].map(function (m) { return '<button class="mini" onclick="jfSet(' + i + ',' + m + ')">' + m + '</button>' }).join('') + '</div>' +
      '<small>' + (pr ? 'Tu promedio: ' + pr.m + ' min (entre ' + pr.lo + ' y ' + pr.hi + ') · la haces el ' + Math.round(pr.fr * 100) + ' % de tus días' : 'Aún sin historial suficiente') + '</small></div>'
  }).join('');
  return '<h1>🏍️ Jornada</h1><div class="card form"><b style="font-size:13px">🎯 Meta de hoy</b>' +
    '<div class="two"><label>Horas<input id="ih" type="number" inputmode="numeric" min="0" max="24" step="1" value="' + c.h + '" oninput="jfPrev()"></label><label>Minutos<input id="imn" type="number" inputmode="numeric" min="0" max="59" step="1" value="' + c.mn + '" oninput="jfPrev()"></label></div>' +
    '<div class="hg" style="margin:2px 0 8px">' + [6, 8, 10, 12].map(function (h) { return '<button class="mini" onclick="jfQ(' + h + ')">' + h + ' h</button>' }).join('') + '</div>' +
    '<label>La meta cuenta como<select id="imt" onchange="jfPrev()">' + o('e', '⏱️ Efectivas (sin pausas)') + o('t', '🕐 Corridas (desde que inicio)') + '</select></label>' +
    '<b style="font-size:13px">⏸️ Pausas previstas</b>' +
    '<label class="ck"><input type="checkbox" ' + (c.po ? 'checked' : '') + ' onchange="jfOn(this.checked)"> <span>Usar pausas previstas</span></label>' +
    (c.po ? '<small style="display:block;margin:2px 0 8px">Son solo un cálculo: la salida real solo suma las pausas que de verdad hagas. Con ellas ves un rango de salida.</small>' + rows +
      '<div class="row" style="align-items:center;gap:8px;margin:4px 0 8px"><select id="jfn" style="flex:1">' + paAll().map(function (p) { return '<option value="' + esc(p[1]) + '">' + p[0] + ' ' + esc(p[1]) + '</option>' }).join('') + '</select><input id="jfm" type="number" inputmode="numeric" min="1" value="30" style="width:72px"><small>min</small><button class="mini" onclick="jfAdd()">➕</button></div>' +
      (H.nj >= 3 ? '<button class="btn out sm" onclick="jfSug()">✨ Sugerir según mis últimos días</button>' : '<small>Con 3 jornadas terminadas, la app podrá sugerir tus pausas habituales.</small>') :
      '<small style="display:block;margin:2px 0 8px">Sin pausas previstas: la salida estimada solo suma las pausas que hagas durante la jornada.</small>') +
    '<small id="jfp" style="display:block;margin:10px 0;font-weight:600"></small>' +
    '<label>Km iniciales<input id="ik" type="number" inputmode="decimal" min="0"></label><button class="btn" onclick="startJ()">▶️ Iniciar jornada</button></div>'
}
/* Promedio real de una pausa en los últimos 30 días (necesita 3 pausas o más). */
function jHist() {
  var a = Date.now() - 30 * 86400000, nj = 0, P = {};
  S.j.forEach(function (j) {
    if (j.ini < a || !j.fin) return; nj++; var seen = {};
    j.pa.forEach(function (p) {
      if (!p.b || !p.m) return; var d = P[p.m] || (P[p.m] = { ds: [], hs: [], dias: 0 }); d.ds.push(p.b - p.a); var t = new Date(p.a); d.hs.push(t.getHours() * 60 + t.getMinutes());
      if (!seen[p.m]) { seen[p.m] = 1; d.dias++ }
    })
  });
  return { nj: nj, P: P }
}
/* Lo que sabemos de tu costumbre con una pausa (últimos 30 días, jornadas terminadas; necesita 3 pausas o más): promedio, rango, hora habitual y cuántos días la haces. */
function jPromPausa(n) {
  var H = jHist(), d = H.P[n]; if (!d || d.ds.length < 3) return null;
  var sum = 0, hs = 0; d.ds.forEach(function (x) { sum += x }); d.hs.forEach(function (x) { hs += x });
  var mins = d.ds.map(function (x) { return Math.round(x / 60000) });
  return { m: Math.max(1, Math.round(sum / d.ds.length / 60000)), c: d.ds.length, lo: Math.min.apply(null, mins), hi: Math.max.apply(null, mins), hr: Math.round(hs / d.hs.length), fr: H.nj ? d.dias / H.nj : 0, nj: H.nj }
}
/* Una pausa prevista que no hiciste y cuya hora habitual ya pasó hace más de 3 h se da por omitida hoy. */
function jOmit(n) { var pr = jPromPausa(n); if (!pr) return false; var d = new Date(); return d.getHours() * 60 + d.getMinutes() > pr.hr + 180 }
/* Salida estimada: horas corridas → inicio + meta. Efectivas → inicio + meta + pausas (reales + las previstas que aún faltan). */
function jPendiente(j) {
  var r = [], e = j.fin || Date.now();
  /* Una pausa prevista ya terminada se da por cumplida (aunque durara menos); si está en curso, se descuenta lo que lleva. */
  (j.pv || []).forEach(function (x) {
    var t = 0, ab = false, fin = false; j.pa.forEach(function (p) { if (p.m === x.n) { t += (p.b || e) - p.a; if (p.b) fin = true; else ab = true } });
    if (fin && !ab) return; var f = x.m * 60000 - t; if (f > 0) r.push({ n: x.n, ms: f, om: !fin && !ab && t === 0 && jOmit(x.n) })
  });
  return r
}
function jEst(j) {
  var h = j.hp * 3600000; if (j.mt !== 'e') return j.ini + h;
  /* Efectivas: inicio + meta + SOLO las pausas que de verdad hiciste; las previstas no se suman hasta que ocurren. */
  var e = j.fin || Date.now(), ps = 0; j.pa.forEach(function (p) { ps += (p.b || e) - p.a });
  return j.ini + h + ps
}
function jHm(t, j) { return hm(t) + (dk(t) !== dk(j.ini) ? ' (+1 día)' : '') }
function jProg(j, s) {
  if (j.mt !== 'e') return '';
  var meta = j.hp * 3600000, f = meta - s.ef, pe = jPendiente(j);
  if (f <= 0) return '<div class="li"><small>🎯 <b>¡Meta cumplida!</b> Llevas ' + dm(s.ef) + ' efectivas de ' + dm(meta) + '.</small></div>';
  var live = pe.filter(function (x) { return !x.om }), om = pe.filter(function (x) { return x.om }), pt = 0; live.forEach(function (x) { pt += x.ms });
  return '<div class="li"><small>🎯 Llevas <b>' + dm(s.ef) + '</b> efectivas de ' + dm(meta) + ' · faltan <b>' + dm(f) + '</b> · terminas aprox. <b>' + estTxt(j) + '</b>' +
    (live.length ? '<br>⏸️ Salida entre <b>' + jHm(jEst(j), j) + '</b> (sin más pausas) y <b>' + jHm(jEst(j) + pt, j) + '</b> (con ' + live.map(function (x) { return esc(x.n) + ' ~' + dm(x.ms) }).join(', ') + ')' : '') +
    (om.length ? '<br>' + om.map(function (x) { return esc(x.n) }).join(', ') + ': ya pasó tu hora habitual, no la cuento. Si hoy no la harás, quítala en “Pausas previstas”.' : '') + '</small></div>'
}
function jMetaBtn(j) { return '<div class="hg" style="margin-top:8px"><button class="btn out sm" onclick="jMeta()">🎯 Cambiar meta</button><button class="btn out sm" onclick="jpvForm()">⏸️ Pausas previstas</button></div>' }
/* Pausas previstas de la jornada en curso: quitar, cambiar minutos o agregar. */
var JPV = null;
function jpvForm() { var j = act(); if (!j) return; JPV = (j.pv || []).map(function (x) { return { n: x.n, m: x.m } }); jpvDraw() }
function jpvLeer() { document.querySelectorAll('.jpm').forEach(function (e) { var i = +e.dataset.i, m = Math.round(parseFloat(e.value)); if (JPV && JPV[i] && m >= 0) JPV[i].m = m }) }
function jpvDraw() {
  var j = act(); if (!j || !JPV) return;
  openM('<h3>⏸️ Pausas previstas de hoy</h3><small style="display:block;margin-bottom:8px">Quita las que hoy no harás (✕ o 0 minutos) o cambia cuánto crees que durarán. Las que ya hiciste se cuentan por su tiempo real.</small>' +
    (JPV.length ? JPV.map(function (x, i) {
      var done = j.pa.some(function (p) { return p.m === x.n && p.b }), pr = jPromPausa(x.n);
      return '<div class="row" style="align-items:center;gap:8px;margin-bottom:6px"><span style="flex:1">' + esc(x.n) + (done ? ' <small>✓ hecha</small>' : '') + (pr ? '<br><small>tu promedio: ' + pr.m + ' min</small>' : '') + '</span><input class="jpm" data-i="' + i + '" type="number" inputmode="numeric" min="0" max="600" value="' + x.m + '" style="width:72px"><small>min</small><button class="mini" aria-label="Quitar" onclick="jpvDel(' + i + ')">✕</button></div>'
    }).join('') : '<div class="li"><small>Sin pausas previstas: la salida solo suma las pausas que hagas.</small></div>') +
    '<div class="row" style="align-items:center;gap:8px;margin:8px 0 10px"><select id="jpn" style="flex:1">' + paAll().map(function (p) { return '<option value="' + esc(p[1]) + '">' + p[0] + ' ' + esc(p[1]) + '</option>' }).join('') + '</select><input id="jpa" type="number" inputmode="numeric" min="1" value="30" style="width:72px"><small>min</small><button class="mini" onclick="jpvAdd()">➕</button></div>' + btns('jpvSave()'))
}
function jpvDel(i) { jpvLeer(); JPV.splice(i, 1); jpvDraw() }
function jpvAdd() {
  jpvLeer(); var m = Math.round(num('#jpa') || 0), n = $('#jpn').value; if (!(m > 0 && m <= 600)) { toast('Pon los minutos de la pausa'); return }
  var x = JPV.filter(function (p) { return p.n === n })[0]; if (x) x.m = m; else JPV.push({ n: n, m: m }); jpvDraw()
}
function jpvSave() { var j = act(); if (!j) return; jpvLeer(); j.pv = JPV.filter(function (x) { return x.m > 0 }); JPV = null; sv(); closeM(); render() }
function jMeta() {
  var j = act(); if (!j) return; var tot = Math.round(j.hp * 60);
  openM('<h3>🎯 Meta de la jornada</h3><div class="two"><label>Horas<input id="mh" type="number" inputmode="numeric" min="0" max="24" value="' + Math.floor(tot / 60) + '"></label><label>Minutos<input id="mm" type="number" inputmode="numeric" min="0" max="59" value="' + (tot % 60) + '"></label></div>' +
    '<label>La meta cuenta como<select id="mt"><option value="e"' + (j.mt === 'e' ? ' selected' : '') + '>⏱️ Efectivas (sin pausas)</option><option value="t"' + (j.mt !== 'e' ? ' selected' : '') + '>🕐 Corridas</option></select></label>' + btns('jMetaOk()'))
}
function jMetaOk() {
  var j = act(); if (!j) return; var h = Math.floor(num('#mh') || 0), m = Math.floor(num('#mm') || 0), t = h + m / 60;
  if (!(t > 0) || t > 24 || m > 59) { toast('Revisa horas y minutos (máximo 24 h)'); return }
  j.hp = Math.round(t * 60) / 60; j.mt = $('#mt').value === 'e' ? 'e' : 't'; sv(); closeM(); render()
}
/* Avisos de la jornada: meta cerca/cumplida y «¿estás en pausa?» (sin viajes ni pausa por un rato). Se activan/desactivan en Ajustes → Avisos. */
function jAvisos() {
  var A = [], j = act(), n = Date.now(); if (!j) return A;
  var c = jcCfg(), s = js(j), go = ['jornada', typeof fsub !== 'undefined' ? fsub : null];
  if (j.mt === 'e') {
    var meta = j.hp * 3600000, f = meta - s.ef;
    if (f <= 0) A.push({ k: 'jmc' + j.id, sev: 1, ic: '🎯', tx: 'Completaste tu meta de ' + dm(meta) + ' efectivas', sub: 'Puedes terminar la jornada o seguir', t: n, hr: 0, go: go });
    else if (c.av > 0 && f <= c.av * 60000) A.push({ k: 'jmf' + j.id, sev: 1, ic: '🎯', tx: 'Te faltan ' + dm(f) + ' para tu meta efectiva', sub: 'Terminas aprox. a las ' + estTxt(j), t: n, hr: 0, go: go })
  }
  if (c.id > 0 && !j.pa.some(function (p) { return !p.b })) {
    var l = j.ini; j.ca.forEach(function (x) { if (x.t > l) l = x.t }); j.pa.forEach(function (p) { if (p.b > l) l = p.b });
    if (n - l >= c.id * 60000) A.push({ k: 'jsp' + j.id + '_' + l, sev: 1, ic: '⏸️', tx: '¿Estás en pausa?', sub: 'Llevas ' + dm(n - l) + ' sin viajes ni pausa. Si estás descansando, regístralo para que no cuente como trabajo.', t: n, hr: 0, go: go })
  }
  return A
}
function jcSet(k, v) { var c = jcCfg(); c[k] = +v; S.jc = Object.assign({}, S.jc, { mt: c.mt, h: c.h, mn: c.mn, pv: c.pv, av: c.av, id: c.id }); sv(); render() }
function jcCfgHTML() {
  var c = jcCfg(), s = function (k, L, cur) { return L.map(function (v) { return '<option value="' + v + '"' + (cur === v ? ' selected' : '') + '>' + (v === 0 ? 'No avisar' : v >= 60 && v % 60 === 0 ? (v / 60) + ' h' : v + ' min') + '</option>' }).join('') };
  return '<h2>🎯 Meta de la jornada</h2><div class="card form"><label>Avisar cuando falte para la meta<select onchange="jcSet(\'av\',this.value)">' + s('av', [0, 15, 30, 45, 60], c.av) + '</select></label>' +
    '<label>Avisar si llevo sin viajes ni pausa<select onchange="jcSet(\'id\',this.value)">' + s('id', [0, 45, 60, 90, 120, 180], c.id) + '</select></label>' +
    '<small>El aviso de “¿estás en pausa?” te ayuda a que las pausas no cuenten como trabajo. Se muestran solo con una jornada activa.</small></div>'
}
