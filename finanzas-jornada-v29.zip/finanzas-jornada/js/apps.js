/* Finanzas + Jornada — apps.js: saldos de las apps (DiDi, Uber) con retiros, premios y cuadre (Etapa 5).
   S.ap = apps {id,nom,arch}.  S.am = movimientos {id,aid,t,tipo,v,sg,bil,est,nota,ua}
   tipos: premio (+, ingreso) · comision (−, costo) · recarga (−, costo: PASE de 24 h = comisión adelantada; activo 24 h desde m.t) · ajuste (±, neutral) · retiro (−; entra a la billetera cuando est==='ok').
   El saldo se calcula: parte pagada con tarjeta de cada viaje (pg k:'a') − comisión del viaje (cm) + S.am. Nunca se guarda. */
var adet = null;
function apList() { return S.ap || [] }
function apById(id) { return apList().filter(function (a) { return a.id === id })[0] }
function apNom(id) { var a = apById(id); return a ? a.nom : '' }
function amSig(m) { return m.tipo === 'premio' ? m.v : m.tipo === 'ajuste' ? (m.sg < 0 ? -m.v : m.v) : -m.v }
function apTrips(id, fn) { (S.j || []).forEach(function (j) { (j.ca || []).forEach(function (c) { if (c.ap === id) fn(c, j) }) }) }
function apSaldo(id) {
  var s = 0;
  apTrips(id, function (c) { (c.pg || []).forEach(function (l) { if (l.k === 'a') s += l.v }); s -= (c.cm || 0) });
  (S.am || []).forEach(function (m) { if (m.aid === id) s += amSig(m) });
  return s
}
function apCamino(id) { var s = 0; (S.am || []).forEach(function (m) { if (m.aid === id && m.tipo === 'retiro' && m.est === 'camino') s += m.v }); return s }
/* Ingresos (premios) y costos (comisiones, recargas) de las apps entre a y b; los usan dash() y js(). */
function amWin(a, b) {
  var r = { ing: 0, co: 0 };
  (S.am || []).forEach(function (m) {
    if (m.t >= a && m.t <= b) { if (m.tipo === 'premio') r.ing += m.v; else if (m.tipo === 'comision' || m.tipo === 'recarga') r.co += m.v; else if (m.tipo === 'retiro' && m.cr > 0) r.co += m.cr }
  });
  (S.xm || []).forEach(function (m) { if (m.tipo === 'cobro' && m.t >= a && m.t <= b) r.ing += m.v });
  return r
}
/* Pase de 24 h: comisión adelantada. a.pase = valor habitual (9.000 por defecto). S.apq[aid] = no volver a preguntar hasta esa hora. */
function apPaseMonto(a) { return a && a.pase > 0 ? a.pase : 9000 }
function apPaseAct(aid) { var n = Date.now(), r = null; (S.am || []).forEach(function (m) { if (m.aid === aid && m.tipo === 'recarga' && m.t <= n && n < m.t + 86400000 && (!r || m.t > r.t)) r = m }); return r }
function apPaseTxt(aid) { var m = apPaseAct(aid); return m ? '🎟️ Pase activo hasta ' + hm(m.t + 86400000) + (dk(m.t + 86400000) !== dk(Date.now()) ? ' (mañana)' : '') : 'Sin pase activo' }
function apPaseAsk(aid) {
  var a = apById(aid); if (!a || apPaseAct(aid)) return;
  var v = apPaseMonto(a);
  openM('<h3>🎟️ ¿Se cobró el pase de ' + esc(a.nom) + '?</h3><p>No hay un pase activo en ' + esc(a.nom) + '. Si te cobraron el pase de 24 h (comisión adelantada), lo registro como costo y se descuenta del saldo de la app.</p>' +
    '<button class="btn" style="margin-bottom:8px" onclick="apPaseSave(\'' + aid + '\',' + v + ',' + Date.now() + ')">Sí, se cobró ' + cop(v) + '</button>' +
    '<button class="btn out" style="margin-bottom:8px" onclick="apPase(\'' + aid + '\')">Otro monto…</button>' +
    '<button class="btn out" onclick="apPaseNo(\'' + aid + '\')">No, todavía no</button>')
}
function apPaseNo(aid) { if (!S.apq) S.apq = {}; S.apq[aid] = Date.now() + 3 * 3600000; sv(); closeM() }
function apPase(aid) {
  var a = apById(aid); if (!a) return;
  openM('<h3>🎟️ Activar pase · ' + esc(a.nom) + '</h3><p>Comisión adelantada de 24 horas. Se descuenta del saldo de la app y cuenta como costo.</p><label>Valor del pase<input id="qv" type="number" inputmode="numeric" min="0" value="' + apPaseMonto(a) + '"></label><label>Fecha y hora del cobro<input id="qt" type="datetime-local" value="' + ldt(Date.now()) + '"></label>' + btns("apPaseOk('" + aid + "')"))
}
function apPaseOk(aid) { var v = num('#qv'), t = pdt($('#qt').value); if (!(v > 0) || t === null) { toast('Revisa el valor y la fecha'); return } apPaseSave(aid, v, t) }
function apPaseSave(aid, v, t) {
  var a = apById(aid); if (!a) { closeM(); return }
  if (!Array.isArray(S.am)) S.am = [];
  var n = Date.now(); S.am.push({ id: uid(), aid: aid, t: t, tipo: 'recarga', v: v, bil: null, nota: 'Pase 24 h', ua: n });
  a.pase = v; sv(); closeM(); render(); toast('🎟️ Pase activo hasta ' + hm(t + 86400000))
}
function apPaseQuitar(aid) {
  var m = apPaseAct(aid), a = apById(aid); if (!m || !a) return;
  openM('<h3>¿Quitar el pase de ' + esc(a.nom) + '?</h3><p>Se elimina el cobro de <b>' + cop(m.v) + '</b>: vuelve al saldo de la app, deja de contar como costo y el pase deja de estar activo.</p><div class="two"><button class="btn out" onclick="closeM()">Cancelar</button><button class="btn bad" onclick="apPaseQuitarOk(\'' + aid + '\')">Quitar pase</button></div>')
}
function apPaseQuitarOk(aid) {
  var m = apPaseAct(aid); if (!m) { closeM(); return }
  S.am = (S.am || []).filter(function (x) { return x.id !== m.id });
  if (S.apq) delete S.apq[aid];
  sv(); closeM(); render(); toast('🗑️ Pase quitado')
}
function apPaseCfg(aid) {
  var a = apById(aid); if (!a) return;
  openM('<h3>Valor habitual del pase · ' + esc(a.nom) + '</h3><label>Valor<input id="qc" type="number" inputmode="numeric" min="0" value="' + apPaseMonto(a) + '"></label>' + btns("apPaseCfgOk('" + aid + "')"))
}
function apPaseCfgOk(aid) { var v = num('#qc'), a = apById(aid); if (!(v > 0) || !a) { toast('Escribe un valor mayor que 0'); return } a.pase = v; sv(); closeM(); render() }
function apInicio() {
  var l = apList().filter(function (a) { return !a.arch }); if (!l.length) return '';
  var tot = 0, cam = 0;
  l.forEach(function (a) { tot += apSaldo(a.id); cam += apCamino(a.id) });
  return '<h2>📲 En las apps</h2><div class="card">' + l.map(function (a) { var s = apSaldo(a.id); return kv(esc(a.nom), cop(s), s < 0 ? 'neg' : '') }).join('') +
    (cam ? kv('🚚 En camino a tu billetera', cop(cam)) : '') + '</div>'
}

/* ---------- lista y detalle ---------- */
function apCard(a) {
  var s = apSaldo(a.id), c = apCamino(a.id);
  return '<div class="li tap fc" onclick="adet=\'' + a.id + '\';render()"><div class="row"><b>' + esc(a.nom) + '</b><b class="big ' + (s < 0 ? 'neg' : '') + '">' + cop(s) + '</b></div><small>' + (c ? '🚚 ' + cop(c) + ' en camino a tu billetera' : 'Saldo en la app') + '</small></div>'
}
function vApps() {
  var l = apList().filter(function (a) { return !a.arch }), tot = 0;
  l.forEach(function (a) { tot += apSaldo(a.id) });
  return '<div class="tiles">' + st('Total en las apps', cop(tot)) + st('Apps', l.length) + '</div><h2>📲 Mis apps</h2>' +
    (l.length ? l.map(apCard).join('') : '<div class="li"><small>No hay apps activas.</small></div>') +
    '<small style="display:block;margin:8px 4px">Lo que te pagan por tarjeta se suma al saldo de la app. Lo que te paga el pasajero directo no lo cambia. Usa “Cuadrar” cuando el saldo de la app no coincida.</small>'
}
function apEventos(a) {
  var E = [];
  apTrips(a.id, function (c) {
    var t = 0; (c.pg || []).forEach(function (l) { if (l.k === 'a') t += l.v });
    if (t) E.push({ t: c.t, ic: '🚕', nm: 'Viaje (tarjeta)', det: '', v: t });
    if (c.cm) E.push({ t: c.t, ic: '➖', nm: 'Comisión del viaje', det: '', v: -c.cm })
  });
  (S.am || []).forEach(function (m) {
    if (m.aid !== a.id) return;
    var nm = { premio: '🎁 Premio', comision: '➖ Comisión', recarga: '🎟️ Pase 24 h', ajuste: '⚖️ Ajuste', retiro: '💸 Retiro' }[m.tipo] || m.tipo, det = '';
    if (m.tipo === 'retiro') det = ' · ' + (m.bil ? 'a ' + esc(wl(m.bil)) : '') + ' · ' + (m.est === 'ok' ? '✅ recibido' : '🚚 en camino') + (m.cr > 0 ? ' · comisión −' + cop(m.cr) : '');
    if (m.tipo === 'premio' && m.pt) det = ' · ' + ptNom(m.pt);
    if (m.nota && m.tipo !== 'retiro') det += ' · ' + esc(m.nota);
    E.push({ t: m.t, m: m, nm: nm, det: det, v: amSig(m) })
  });
  return E.sort(function (a, b) { return b.t - a.t }).slice(0, 80)
}
function apEvLi(e) {
  var h = '<div class="li fh"><div class="wr" style="padding:0">' + (e.ic ? '<span class="ic">' + e.ic + '</span>' : '') + '<div class="g"><b>' + e.nm + '</b><br><small>' + fd(e.t) + ' ' + hm(e.t) + e.det + '</small></div><b class="big ' + (e.v < 0 ? 'neg' : 'pos') + '">' + (e.v < 0 ? '−' : '+') + cop(Math.abs(e.v)) + '</b></div>';
  if (e.m) {
    h += '<div class="ab">' + (e.m.tipo === 'premio' ? '<button class="ed" onclick="apPremio(\'' + e.m.aid + '\',\'' + e.m.id + '\')">✏️ Editar</button>' : '') + (e.m.tipo === 'retiro' && e.m.est === 'camino' ? '<button class="ed" onclick="apRecibido(\'' + e.m.id + '\')">✅ Ya llegó</button>' : '') +
      '<button onclick="ask(this,function(){apDelM(\'' + e.m.id + '\')},\'movimiento\')">🗑️ Eliminar</button></div>'
  }
  return h + '</div>'
}
function vApDet(a) {
  var s = apSaldo(a.id), c = apCamino(a.id), ev = apEventos(a);
  return '<button class="btn out sm" onclick="adet=null;render()">← Volver a apps</button><h1>📲 ' + esc(a.nom) + '</h1>' +
    '<div class="hero"><small>Saldo en la app</small><b>' + cop(s) + '</b>' + (c ? '<div class="sub"><span>🚚 En camino<br><b>' + cop(c) + '</b></span></div>' : '') + '</div>' +
    '<div class="card" style="padding:4px 16px">' + kv('🎟️ Pase 24 h', apPaseTxt(a.id)) + (apPaseAct(a.id) ? '<div class="kv"><span>Cobro del pase</span><b>' + cop(apPaseAct(a.id).v) + ' <button class="mini bad" onclick="apPaseQuitar(\'' + a.id + '\')">🗑️ Quitar</button></b></div>' : '') + '<div class="kv"><span>Valor habitual del pase</span><b>' + cop(apPaseMonto(a)) + ' <button class="mini" onclick="apPaseCfg(\'' + a.id + '\')">✏️</button></b></div><div class="kv"><span>Comisión habitual de retiro</span><b>' + apRetHabTxt(a) + ' <button class="mini" onclick="apRetCfg(\'' + a.id + '\')">✏️</button></b></div></div>' +
    '<div class="pz p4"><button onclick="apRetiro(\'' + a.id + '\')"><span>💸</span>Retirar</button><button onclick="apPase(\'' + a.id + '\')"><span>🎟️</span>Pase</button><button onclick="apPremio(\'' + a.id + '\')"><span>🎁</span>Premio</button><button onclick="apCuadrar(\'' + a.id + '\')"><span>⚖️</span>Cuadrar</button></div>' +
    pxApHTML(a) + '<h2>📜 Historial (' + ev.length + ')</h2>' + (ev.length ? ev.map(apEvLi).join('') : '<div class="li"><small>Todavía no hay movimientos en esta app.</small></div>')
}

/* ---------- retirar ---------- */
function apRetiro(aid) {
  var a = apById(aid); if (!a) return;
  openM('<h3>💸 Retirar de ' + esc(a.nom) + '</h3><p>Saldo en la app: <b>' + cop(apSaldo(aid)) + '</b></p><label>Monto que sale de la app<input id="rv" type="number" inputmode="numeric" min="0" placeholder="0" oninput="apRetCr(\'' + aid + '\')"></label>' +
    '<label>Comisión del retiro (opcional)<input id="rcr" type="number" inputmode="numeric" min="0" placeholder="0" value="' + (a.rf > 0 && !(a.rp > 0) ? a.rf : '') + '" oninput="this.dataset.m=1"></label><small style="display:block;margin:-4px 0 10px">Llega a tu billetera el monto menos la comisión, y la comisión cuenta como costo de la app.</small>' +
    '<label>¿A qué billetera va?' + bilSel('rb', S.rbl || BIL[0]) + '</label>' +
    '<label>Estado<select id="re"><option value="camino">🚚 En camino (aún no llega)</option><option value="ok">✅ Ya llegó a mi billetera</option></select></label>' +
    '<label>Fecha y hora<input id="rt" type="datetime-local" value="' + ldt(Date.now()) + '"></label><label>Nota (opcional)<input id="rn" maxlength="60"></label>' + btns("apRetSave('" + aid + "')"))
}
function apRetSave(aid) {
  var v = num('#rv'), t = pdt($('#rt').value), b = $('#rb').value, e = $('#re').value;
  if (!(v > 0) || t === null) { toast('Revisa el monto y la fecha'); return }
  if (BILX.indexOf(b) < 0) { toast('Elige una billetera'); return }
  if (v > apSaldo(aid) + 0.005) { toast('Supera el saldo registrado (' + cop(apSaldo(aid)) + '). Cuádralo primero con la app.'); return }
  var rcr = $('#rcr').value === '' ? 0 : num('#rcr');
  if (!(rcr >= 0) || rcr >= v) { toast('La comisión debe ser menor que el monto, o déjala vacía'); return }
  if (!Array.isArray(S.am)) S.am = [];
  var n = Date.now(); S.am.push({ id: uid(), aid: aid, t: t, tipo: 'retiro', v: v, bil: b, est: e === 'ok' ? 'ok' : 'camino', nota: $('#rn').value.trim().slice(0, 60), ua: n });
  if (rcr > 0) S.am[S.am.length - 1].cr = Math.round(rcr * 100) / 100;
  S.rbl = b; sv(); closeM(); render(); toast(e === 'ok' ? '✅ Retiro registrado' : '🚚 Retiro en camino')
}
function apRecibido(id) {
  var m = (S.am || []).filter(function (x) { return x.id === id })[0]; if (!m) return;
  m.est = 'ok'; m.ua = Date.now(); sv(); render(); toast('✅ Entró a ' + bn(m.bil))
}
function apDelM(id) { S.am = (S.am || []).filter(function (x) { return x.id !== id }); sv(); render() }

/* ---------- premio ---------- */
var PT = [['meta', '🎯 Meta de viajes'], ['bono', '🎁 Bono'], ['otro', '✨ Otro']];
function ptNom(x) { var r = PT.filter(function (p) { return p[0] === x })[0]; return r ? r[1] : '' }
function apPremio(aid, mid) {
  var a = apById(aid); if (!a) return;
  var m = mid ? (S.am || []).filter(function (x) { return x.id === mid && x.tipo === 'premio' })[0] : null; if (mid && !m) return;
  openM('<h3>' + (m ? '✏️ Editar premio' : '🎁 Premio') + ' · ' + esc(a.nom) + '</h3><p>Suma al saldo de la app, cuenta como ingreso y queda en el Historial.</p>' +
    '<label>¿Por qué fue?<select id="pt">' + PT.map(function (p) { return '<option value="' + p[0] + '"' + ((m && m.pt || 'meta') === p[0] ? ' selected' : '') + '>' + p[1] + '</option>' }).join('') + '</select></label>' +
    '<label>Monto<input id="pv" type="number" inputmode="numeric" min="0" placeholder="0" value="' + (m ? m.v : '') + '"></label>' +
    '<label>Fecha y hora<input id="ptf" type="datetime-local" value="' + ldt(m ? m.t : Date.now()) + '"></label>' +
    '<label>Nota (opcional)<input id="pn" maxlength="60" value="' + esc(m ? m.nota : '') + '" placeholder="Ej. 50 viajes de la semana"></label>' + btns("apPremioSave('" + aid + "','" + (mid || '') + "')"))
}
function apPremioSave(aid, mid) {
  var v = num('#pv'), t = pdt($('#ptf').value); if (!(v > 0)) { toast('Escribe un monto mayor que 0'); return }
  if (t === null) { toast('Revisa la fecha'); return }
  if (!Array.isArray(S.am)) S.am = [];
  var n = Date.now(), pt = $('#pt').value, nota = $('#pn').value.trim().slice(0, 60), m = mid ? S.am.filter(function (x) { return x.id === mid })[0] : null;
  if (mid && !m) { closeM(); return }
  if (m) { m.v = v; m.t = t; m.pt = pt; m.nota = nota; m.ua = n }
  else S.am.push({ id: uid(), aid: aid, t: t, tipo: 'premio', pt: pt, v: v, bil: null, nota: nota, ua: n });
  sv(); closeM(); render(); toast(m ? '✅ Premio actualizado' : '🎁 Premio registrado')
}
/* ---------- cuadrar con la app ---------- */
function apCuadrar(aid) {
  var a = apById(aid); if (!a) return;
  openM('<h3>⚖️ Cuadrar ' + esc(a.nom) + '</h3><p>La app registra <b>' + cop(apSaldo(aid)) + '</b>. Escribe el saldo que ves hoy en la app de ' + esc(a.nom) + '.</p><label>Saldo en la app<input id="as" type="number" inputmode="decimal" placeholder="0"></label>' +
    '<div class="two"><button class="btn out" onclick="closeM()">Cancelar</button><button class="btn" onclick="apCuadrar2(\'' + aid + '\')">Continuar</button></div>')
}
function apCuadrar2(aid) {
  var real = num('#as'); if (real === null) { toast('Escribe el saldo'); return }
  var d = Math.round((real - apSaldo(aid)) * 100) / 100;
  if (Math.abs(d) < 0.005) { closeM(); toast('✅ Ya cuadra'); return }
  var o = d > 0 ? [['premio', '🎁 Fue un premio o bono', 'Cuenta como ingreso'], ['ajuste', '⚖️ Es un ajuste', 'No afecta tus ganancias']] :
    [['recarga', '🎟️ Pase de 24 h (comisión adelantada)', 'Cuenta como costo y activa el pase desde ahora'], ['comision', '➖ Comisión de la app', 'Cuenta como costo'], ['ajuste', '⚖️ Es un ajuste', 'No afecta tus ganancias']];
  openM('<h3>Diferencia de ' + (d > 0 ? '+' : '−') + cop(Math.abs(d)) + '</h3><p>¿Qué fue esa diferencia?</p>' +
    o.map(function (x) { return '<button class="btn out opt" onclick="apCuadrar3(\'' + aid + '\',' + d + ',\'' + x[0] + '\')"><b>' + x[1] + '</b><small>' + x[2] + '</small></button>' }).join('') +
    '<button class="btn out sm" onclick="closeM()">Cancelar</button>')
}
function apCuadrar3(aid, d, tipo) {
  if (!Array.isArray(S.am)) S.am = [];
  var n = Date.now(); S.am.push({ id: uid(), aid: aid, t: n, tipo: tipo, v: Math.abs(d), sg: d > 0 ? 1 : -1, bil: null, nota: 'Cuadre con la app', ua: n });
  sv(); closeM(); render(); toast('⚖️ Saldo cuadrado')
}

/* ---------- comisión habitual de retiro (Etapa 9) ---------- */
function apRetFee(a, v) { return a && a.rp > 0 ? Math.round(v * a.rp / 100) : a && a.rf > 0 ? a.rf : 0 }
function apRetHabTxt(a) { return a.rp > 0 ? a.rp + ' % del retiro' : a.rf > 0 ? cop(a.rf) : 'Sin comisión' }
function apRetCr(aid) { var a = apById(aid), c = $('#rcr'); if (!a || !c || c.dataset.m === '1') return; var v = num('#rv'); c.value = v > 0 ? (apRetFee(a, v) || '') : (a.rf > 0 && !(a.rp > 0) ? a.rf : '') }
function apRetCfg(aid) {
  var a = apById(aid); if (!a) return;
  openM('<h3>Comisión habitual de retiro · ' + esc(a.nom) + '</h3><p>Se propone sola al retirar y cuenta como costo. Pon un monto fijo <b>o</b> un porcentaje (deja el otro vacío).</p>' +
    '<label>Monto fijo<input id="rfv" type="number" inputmode="numeric" min="0" value="' + (a.rf > 0 ? a.rf : '') + '" placeholder="Ej. 500"></label><label>% del retiro<input id="rfp" type="number" inputmode="decimal" min="0" max="100" step="0.1" value="' + (a.rp > 0 ? a.rp : '') + '" placeholder="Ej. 1.5"></label>' + btns("apRetCfgOk('" + aid + "')"))
}
function apRetCfgOk(aid) {
  var a = apById(aid); if (!a) { closeM(); return }
  var f = $('#rfv').value === '' ? 0 : num('#rfv'), p = $('#rfp').value === '' ? 0 : num('#rfp');
  if (!(f >= 0) || !(p >= 0) || p > 100) { toast('Revisa los valores'); return }
  if (f > 0 && p > 0) { toast('Usa solo uno: monto fijo o porcentaje'); return }
  if (f > 0) a.rf = f; else delete a.rf; if (p > 0) a.rp = p; else delete a.rp;
  a.ua = Date.now(); sv(); closeM(); render(); toast('✅ Guardado')
}
