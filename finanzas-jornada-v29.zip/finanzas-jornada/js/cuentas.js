/* Finanzas + Jornada — cuentas.js: Deudas y Préstamos (Etapa 3).
   Dos listas con la misma mecánica, configuradas en CU:
   - Deudas (lo que debes):   S.de = {id,nom,fv,arch,ca,ua}   S.dm = {id,cid,t,tipo:'inicial'|'pago'|'cargo',v,bil,nota,ua}
   - Préstamos (te deben):    S.pr = {id,nom,fv,arch,ca,ua}   S.pm = {id,cid,t,tipo:'inicial'|'cobro'|'prestamo',v,bil,nota,ua}
   El saldo se calcula (nunca se guarda). Si un movimiento tiene billetera (bil), wal() lo refleja:
     pago = sale de la billetera · cargo = entra · cobro = entra · prestamo (prestar más) = sale.
   'inicial' nunca toca billeteras. fv = fecha límite opcional. */
var cdet = null, cArch = false, cLastBil = '';
var CU = {
  deudas: {
    L: 'de', M: 'dm', menos: 'pago', mas: 'cargo', menosIn: false, ico: '🤝', lista: 'Mis deudas', sing: 'deuda',
    nuevo: '➕ Nueva deuda', vacio: 'Aún no tienes deudas registradas. Agrega una para llevar lo que debes y tus pagos.',
    quien: '¿A quién le debes?', ph: 'Ej. Banco, Juan, Tienda', iniNew: '¿Cuánto debes hoy?',
    totTile: 'Total que debes', cntTile: 'Deudas pendientes', saldoLbl: 'Saldo pendiente', totLbl: '💳 Total adeudado', partLbl: '✅ Pagado',
    partTxt: 'pagado', done: '🎉 Saldada', archTxt: 'Archivada', back: 'deudas',
    menosBtn: '➖ Pagar', masBtn: '➕ Aumentar', menosNm: 'Pago', masNm: 'Aumento', menosIc: '💸', masIc: '📈', menosTit: 'Pagar a ', masTit: 'Aumentar ',
    menosLbl: '¿De qué billetera sale el pago?', masLbl: '¿A qué billetera entró el dinero?',
    hintMenos: 'Si eliges una billetera, el pago se descuenta de ella.', hintMas: 'Úsalo si la deuda crece (más dinero recibido, intereses o compras a crédito). Si eliges una billetera, el valor se suma a ella.',
    masCls: 'neg'
  },
  cobros: {
    L: 'xc', M: 'xm', menos: 'cobro', mas: 'extra', menosIn: true, noMasBil: true, ico: '⏳', lista: 'Por cobrar', sing: 'cobro pendiente',
    nuevo: '➕ Nuevo por cobrar', vacio: 'No tienes cobros pendientes. Agrega un domicilio o servicio que aún no te pagan.',
    quien: '¿Quién te debe?', ph: 'Ej. Domicilio Laura', iniNew: '¿Cuánto te deben?',
    totTile: 'Total por cobrar', cntTile: 'Pendientes', saldoLbl: 'Por cobrar', totLbl: '⏳ Valor del servicio', partLbl: '✅ Cobrado',
    partTxt: 'cobrado', done: '🎉 Cobrado', archTxt: 'Archivado', back: 'por cobrar',
    menosBtn: '✅ Cobrar', masBtn: '📈 Aumentar', menosNm: 'Cobro', masNm: 'Aumento', menosIc: '💵', masIc: '📈', menosTit: 'Cobrar a ', masTit: 'Aumentar ',
    menosLbl: '¿A qué billetera entra lo cobrado?', masLbl: '',
    hintMenos: 'Lo cobrado entra a esa billetera y cuenta como ingreso del día en que lo cobras. Si te pagan en dos billeteras, registra dos cobros.', hintMas: 'Úsalo si el valor del servicio sube. No mueve billeteras.',
    masCls: ''
  },
  prestamos: {
    L: 'pr', M: 'pm', menos: 'cobro', mas: 'prestamo', menosIn: true, ico: '💵', lista: 'Mis préstamos', sing: 'préstamo',
    nuevo: '➕ Nuevo préstamo', vacio: 'Aún no has registrado préstamos. Agrega a quién le prestaste dinero para no olvidar cuánto te deben.',
    quien: '¿A quién le prestaste?', ph: 'Ej. Carlos, Hermano', iniNew: '¿Cuánto te deben hoy?',
    totTile: 'Total que te deben', cntTile: 'Préstamos pendientes', saldoLbl: 'Por cobrar', totLbl: '💵 Total prestado', partLbl: '✅ Cobrado',
    partTxt: 'cobrado', done: '🎉 Cobrado', archTxt: 'Archivado', back: 'por cobrar',
    menosBtn: '➕ Cobrar', masBtn: '➖ Prestar más', menosNm: 'Cobro', masNm: 'Préstamo adicional', menosIc: '💵', masIc: '🤲', menosTit: 'Cobrar a ', masTit: 'Prestar más a ',
    menosLbl: '¿A qué billetera entra lo cobrado?', masLbl: '¿De qué billetera sale el dinero?',
    hintMenos: 'Si eliges una billetera, lo cobrado se suma a ella.', hintMas: 'Si eliges una billetera, el valor se descuenta de ella.',
    masCls: ''
  }
};

/* ---------- tipos de cobro (Etapa 8): préstamo de dinero · carrera o domicilio · los que crees ---------- */
var CTB = [{ id: 'prestamo', ico: '🤲', nom: 'Préstamo de dinero', k: 'prestamos' }, { id: 'carrera', ico: '🏍️', nom: 'Carrera o domicilio', k: 'cobros' }];
function ctAll() { return CTB.concat((S.ct || []).map(function (x) { return { id: x.id, ico: x.ico || '🏷️', nom: x.nom, k: x.k === 'cobros' ? 'cobros' : 'prestamos', custom: 1 } })) }
function ctGet(k, f) {
  var id = f.tp || (k === 'prestamos' ? 'prestamo' : 'carrera'), t = ctAll().filter(function (x) { return x.id === id })[0];
  return t || (k === 'prestamos' ? CTB[0] : CTB[1])
}
function cuInfo(k, f) {
  var uni = k === 'prestamos' || k === 'cobros', r = '';
  if (uni) { var t = ctGet(k, f); r += kv('Tipo', t.ico + ' ' + esc(t.nom)) }
  r += kv('📅 Inicio', fdl(f.fi || f.ca || Date.now())) + kv('⏰ Fecha límite', f.fv ? fdl(f.fv) : 'Sin fecha');
  if (k === 'deudas' && f.cq > 0) r += kv('💳 Cuota mensual', cop(f.cq) + (f.cd ? ' · día ' + f.cd : ''));
  if (f.rd > 0) r += kv('🔔 Aviso', avDia(f.rd) + ' antes');
  return '<div class="card" style="padding:4px 16px;margin-top:10px">' + r + '</div>'
}

/* ---------- datos ---------- */
function cuEns(c) { if (!Array.isArray(S[c.L])) S[c.L] = []; if (!Array.isArray(S[c.M])) S[c.M] = [] }
function cuLst(c) { return S[c.L] || [] }
function cuById(c, id) { return cuLst(c).filter(function (f) { return f.id === id })[0] }
function cuMovs(c, id) { return (S[c.M] || []).filter(function (m) { return m.cid === id }) }
function cuMById(c, id) { return (S[c.M] || []).filter(function (m) { return m.id === id })[0] }
function cuSig(c, m) { return m.tipo === c.menos ? -m.v : m.v }
function cuSaldo(c, id) { var s = 0; cuMovs(c, id).forEach(function (m) { s += cuSig(c, m) }); return s }
function cuTot(c, id) { var s = 0; cuMovs(c, id).forEach(function (m) { if (m.tipo !== c.menos) s += m.v }); return s }
function cuIni(c, id) { return cuMovs(c, id).filter(function (m) { return m.tipo === 'inicial' })[0] }
function cuVenc(f, s) {
  if (!f.fv || s < 0.005) return '';
  var d = Math.round((d0(f.fv) - d0(Date.now())) / 86400000);
  return d < 0 ? '⚠️ Vencida hace ' + (-d) + (d === -1 ? ' día' : ' días') : d === 0 ? '⏰ Vence hoy' : d === 1 ? '⏰ Vence mañana' : d <= 7 ? '⏰ Vence en ' + d + ' días' : '📅 Vence ' + fd(f.fv)
}
function cuOrden(c, a, b) {
  var sa = cuSaldo(c, a.id) < 0.005, sb = cuSaldo(c, b.id) < 0.005;
  if (sa !== sb) return sa ? 1 : -1;
  var fa = a.fv || Infinity, fb = b.fv || Infinity;
  if (fa !== fb) return fa < fb ? -1 : 1;
  return (b.ua || 0) - (a.ua || 0)
}

/* ---------- lista ---------- */
function fdl(t) { return new Date(t).toLocaleDateString('es-CO', { day: 'numeric', month: 'short', year: 'numeric' }) }
function cuFechas(k, f) {
  var t = (k === 'prestamos' || k === 'cobros') ? ctGet(k, f) : null;
  return (t ? t.ico + ' ' + esc(t.nom) + ' · ' : '') + '📅 ' + fdl(f.fi || f.ca || Date.now())
}
function cuCard(k, f) {
  var c = CU[k], s = cuSaldo(c, f.id), t = cuTot(c, f.id), ok = t > 0 && s < 0.005, p = t > 0 ? Math.min(100, (t - s) / t * 100) : null, v = cuVenc(f, s);
  return '<div class="li tap fc" onclick="fsub=\'' + k + '\';cdet=\'' + f.id + '\';render()"><div class="row"><b>' + esc(f.nom) + (f.arch ? ' 📦' : '') + '</b><b class="big ' + (ok ? 'pos' : '') + '">' + cop(Math.max(0, s)) + '</b></div>' +
    (p === null ? '<small>Sin movimientos</small>' : fBar(p) + '<div class="row"><small>' + (ok ? c.done : fp(p) + ' ' + c.partTxt + ' de ' + cop(t)) + '</small><small>' + v + '</small></div>') +
    '<small style="display:block;margin-top:2px">' + cuFechas(k, f) + (f.fv && !v ? ' · ⏰ ' + fdl(f.fv) : '') + '</small></div>'
}
function vCuentas(k) {
  if (k === 'cobros' || k === 'prestamos') return vCobros();
  var c = CU[k], all = cuLst(c), act = all.filter(function (f) { return !f.arch }).sort(function (a, b) { return cuOrden(c, a, b) }),
    arc = all.filter(function (f) { return f.arch }), tot = 0, pend = 0, venc = 0;
  act.forEach(function (f) {
    var s = cuSaldo(c, f.id);
    if (s > 0.005) { tot += s; pend++; if (f.fv && d0(f.fv) < d0(Date.now())) venc++ }
  });
  var h = '<div class="tiles">' + st(c.totTile, cop(tot)) + st(c.cntTile, pend) + '</div>' +
    (venc ? '<div class="warn" style="margin-top:8px"><span>⚠️ ' + venc + (venc === 1 ? ' vencida' : ' vencidas') + '</span></div>' : '') +
    '<button class="btn" style="margin-top:12px" onclick="cuForm(\'' + k + '\')">' + c.nuevo + '</button><h2>' + c.ico + ' ' + c.lista + '</h2>';
  h += act.length ? act.map(function (f) { return cuCard(k, f) }).join('') : '<div class="li"><small>' + c.vacio + '</small></div>';
  if (arc.length) {
    h += '<button class="btn out sm" onclick="cArch=!cArch;render()">' + (cArch ? '🔽' : '▶️') + ' 📦 Archivados (' + arc.length + ')</button>';
    if (cArch) h += arc.map(function (f) { return cuCard(k, f) }).join('')
  }
  return h
}
/* ---------- detalle ---------- */
function cuMovLi(k, f, m) {
  var c = CU[k], me = m.tipo === c.menos, ini = m.tipo === 'inicial', entra = me ? c.menosIn : !c.menosIn,
    ic = ini ? '🏁' : me ? c.menosIc : c.masIc, nm = ini ? 'Saldo inicial' : me ? c.menosNm : c.masNm,
    det = fd(m.t) + ' ' + hm(m.t) + ' · ' + (m.bil ? (entra ? 'a ' : 'de ') + esc(wl(m.bil)) : 'sin afectar billetera') + (m.nota && !ini ? ' · ' + esc(m.nota) : ''),
    acc = f.arch ? '' : ini ? '<div class="ab"><button class="ed" onclick="cuForm(\'' + k + '\',\'' + f.id + '\')">✏️ Editar</button></div>' :
      abtn("cuMov('" + k + "','" + f.id + "','" + m.tipo + "','" + m.id + "')", "cuMDel('" + k + "','" + m.id + "')", 'movimiento');
  return '<div class="li fh"><div class="wr" style="padding:0"><span class="ic">' + ic + '</span><div class="g"><b>' + nm + '</b><br><small>' + det + '</small></div><b class="big ' + (me ? 'pos' : ini ? '' : c.masCls) + '">' + (me ? '−' : '+') + cop(m.v) + '</b></div>' + acc + '</div>'
}
function vCuentaDet(k) {
  var c = CU[k], f = cuById(c, cdet), s = cuSaldo(c, f.id), t = cuTot(c, f.id), pg = t - s, p = t > 0 ? Math.min(100, pg / t * 100) : null, ok = t > 0 && s < 0.005,
    ms = cuMovs(c, f.id).sort(function (a, b) { return b.t - a.t || b.ua - a.ua }), v = cuVenc(f, s);
  var h = '<button class="btn out sm" onclick="cdet=null;render()">← Volver a ' + c.back + '</button><h1>' + c.ico + ' ' + esc(f.nom) + (f.arch ? ' <span class="chip pause">📦 ' + c.archTxt + '</span>' : '') + '</h1>' +
    '<div class="hero"><small>' + c.saldoLbl + '</small><b>' + cop(Math.max(0, s)) + '</b><div class="sub"><span>' + c.totLbl + '<br><b>' + cop(t) + '</b></span><span>' + c.partLbl + '<br><b>' + cop(pg) + '</b></span></div></div>';
  h += cuInfo(k, f);
  if (p !== null) h += '<div class="card" style="padding:12px 16px">' + fBar(p) + '<div class="row"><small>' + (ok ? c.done : fp(p) + ' ' + c.partTxt) + '</small><small>' + (v || (f.fv && !ok ? '📅 Vence ' + fd(f.fv) : '')) + '</small></div></div>';
  else if (f.fv) h += '<div class="li"><small>📅 Fecha límite: ' + fd(f.fv) + '</small></div>';
  if (f.arch) h += '<div class="warn" style="margin-top:10px"><span>Está archivado. Desarchívalo para registrar movimientos.</span></div>';
  else h += '<div class="two" style="margin-top:12px"><button class="btn" onclick="cuMov(\'' + k + '\',\'' + f.id + '\',\'' + c.menos + '\')">' + c.menosBtn + '</button><button class="btn out" onclick="cuMov(\'' + k + '\',\'' + f.id + '\',\'' + c.mas + '\')">' + c.masBtn + '</button></div>';
  h += '<div class="two" style="margin-top:12px"><button class="btn out sm" onclick="cuForm(\'' + k + '\',\'' + f.id + '\')">✏️ Editar</button><button class="btn out sm" onclick="cuArchivar(\'' + k + '\',\'' + f.id + '\')">' + (f.arch ? '📤 Desarchivar' : '📦 Archivar') + '</button></div>' +
    (f.fv ? '<button class="btn out sm" onclick="avIcsCu(\'' + k + '\',\'' + f.id + '\')">📅 Agregar al calendario</button>' : '') + '<button class="btn bad sm" onclick="cuDelAsk(\'' + k + '\',\'' + f.id + '\')">🗑️ Eliminar ' + c.sing + '</button><h2>📜 Historial (' + ms.length + ')</h2>';
  return h + (ms.length ? ms.map(function (m) { return cuMovLi(k, f, m) }).join('') : '<div class="li"><small>Todavía no hay movimientos.</small></div>')
}

/* ---------- crear / editar ---------- */
/* Billetera de la que sale el préstamo de dinero (opcional). Solo se ve cuando el tipo elegido es un préstamo de dinero. */
function cuEsPrest(tid, k) { var t = ctAll().filter(function (x) { return x.id === tid })[0]; return t ? t.k === 'prestamos' : k === 'prestamos' }
function cuBilHTML(k, f, m, cur) {
  var w = wal(), b0 = m && m.bil ? m.bil : '';
  return '<div id="cbw" style="display:' + (cuEsPrest(cur, k) ? 'block' : 'none') + '"><label>¿De qué billetera salió el dinero?<select id="cbl"><option value="">Sin billetera (no descuenta)</option>' +
    bilOpts([b0]).map(function (b) { return '<option value="' + esc(b) + '"' + (b0 === b ? ' selected' : '') + '>' + esc(wl(b)) + ' (' + cop(w[b] ? w[b].s : 0) + ')</option>' }).join('') + '</select></label>' +
    '<small style="display:block;margin:-4px 0 12px">Si eliges una billetera, el valor se descuenta de ella. Sin billetera no cambia ninguna. Lo que te devuelvan, cóbralo después y entra a la billetera que elijas.</small></div>'
}
function cuTipoSel() { var e = $('#cbw'), t = $('#ctp'); if (e && t) e.style.display = cuEsPrest(t.value, 'cobros') ? 'block' : 'none' }
function cuForm(k, id) {
  var c = CU[k], f = id ? cuById(c, id) : null, m = f ? cuIni(c, id) : null;
  if (id && !f) return;
  var uni = k === 'prestamos' || k === 'cobros', ds = k === 'deudas', ts = '';
  if (uni) {
    var cur = f ? ctGet(k, f).id : 'prestamo';
    ts = '<label>Tipo<select id="ctp" onchange="cuTipoSel()">' + ctAll().filter(function (t) { return !f || t.k === k }).map(function (t) { return '<option value="' + t.id + '"' + (t.id === cur ? ' selected' : '') + '>' + esc(t.ico + ' ' + t.nom) + '</option>' }).join('') + '</select></label>' +
      '<small style="display:block;margin:-4px 0 12px">Préstamo de dinero: lo que te devuelven vuelve a tu billetera y no cuenta como ingreso. Carrera o domicilio: al cobrarlo sí cuenta como ingreso.</small>'
  }
  var tit = uni ? (f ? '✏️ Editar por cobrar' : '➕ Nuevo por cobrar') : (f ? '✏️ Editar ' + c.sing : c.nuevo);
  openM('<h3>' + tit + '</h3>' + ts + '<label>' + c.quien + '<input id="cn" maxlength="40" value="' + esc(f ? f.nom : '') + '" placeholder="' + c.ph + '"></label>' +
    '<label>' + (f ? 'Saldo inicial' : c.iniNew) + '<input id="cs" type="number" inputmode="numeric" min="0" value="' + (m ? m.v : '') + '" placeholder="0"></label>' +
    '<small style="display:block;margin:-4px 0 12px">' + (f ? 'Los pagos y demás movimientos se registran aparte, en el historial.' : uni ? 'Si es un préstamo de dinero, elige abajo de qué billetera salió (o ninguna).' : 'No cambia tus billeteras. Si el dinero se movió hoy, créala con 0 y registra el movimiento eligiendo la billetera.') + '</small>' + (uni ? cuBilHTML(k, f, m, cur) : '') +
    '<label>📅 Fecha de inicio<input id="cfi" type="date" value="' + iso(f && (f.fi || f.ca) ? (f.fi || f.ca) : Date.now()) + '"></label>' +
    '<label>⏰ Fecha límite (opcional)<input id="cf" type="date" value="' + (f && f.fv ? iso(f.fv) : '') + '"></label>' +
    '<label>🔔 Avisarme antes (días, opcional)<input id="crd" type="number" inputmode="numeric" min="1" value="' + (f && f.rd > 0 ? f.rd : '') + '" placeholder="Usa el aviso general"></label>' +
    (ds ? '<label>💳 Cuota mensual (opcional)<input id="ccq" type="number" inputmode="numeric" min="0" value="' + (f && f.cq > 0 ? f.cq : '') + '" placeholder="Ej. 150000"></label>' +
      '<label>Día del mes en que se paga (1–31)<input id="ccd" type="number" inputmode="numeric" min="1" max="31" value="' + (f && f.cd > 0 ? f.cd : '') + '" placeholder="Ej. 5"></label>' +
      '<small style="display:block;margin:-4px 0 12px">Con cuota y día, la deuda aparece en “Apartar hoy” y se crea su fondo de pago.</small>' : '') +
    btns("cuSave('" + k + "','" + (id || '') + "')"))
}
function cuSave(k, id) {
  var nom = $('#cn').value.trim(), rs = $('#cs').value, ini = rs === '' ? 0 : num('#cs'), rf = $('#cf').value, fv = rf ? pd(rf) : null,
    rfi = $('#cfi').value, fi = rfi ? pd(rfi) : null, rrd = $('#crd').value, rd = rrd === '' ? null : num('#crd'), uni = k === 'prestamos' || k === 'cobros', tp = null, cq = null, cd = null;
  if (uni) {
    var t = ctAll().filter(function (x) { return x.id === $('#ctp').value })[0];
    if (!t) { toast('Elige un tipo'); return }
    if (id && t.k !== k) { toast('Ese tipo se maneja distinto. Crea uno nuevo con el tipo que quieras.'); return }
    tp = t.id; if (!id) k = t.k
  }
  var c = CU[k], bl = (k === 'prestamos' && $('#cbl')) ? $('#cbl').value : ''; if (BILX.indexOf(bl) < 0) bl = '';
  if (!nom) { toast('Escribe un nombre'); return }
  if (nom.length > 40) { toast('El nombre es muy largo (máximo 40)'); return }
  if (ini === null || ini < 0) { toast('Revisa el saldo'); return }
  if (rf && isNaN(fv)) { toast('Revisa la fecha límite'); return }
  if (rfi && isNaN(fi)) { toast('Revisa la fecha de inicio'); return }
  if (fv != null && fi != null && fv < fi) { toast('La fecha límite no puede ser anterior a la de inicio'); return }
  if (rrd !== '' && !(rd >= 1)) { toast('Los días de aviso deben ser 1 o más, o déjalo vacío'); return }
  if (k === 'deudas') {
    var rq = $('#ccq').value, rdd = $('#ccd').value; cq = rq === '' ? null : num('#ccq'); cd = rdd === '' ? null : num('#ccd');
    if (rq !== '' && !(cq > 0)) { toast('La cuota debe ser mayor que 0, o déjala vacía'); return }
    if (cq > 0 && !(cd >= 1 && cd <= 31 && cd === Math.floor(cd))) { toast('Pon el día del mes en que se paga la cuota (1–31)'); return }
    if (!(cq > 0)) cd = null
  }
  var alc = uni ? ['prestamos', 'cobros'] : [k], dup = false;
  alc.forEach(function (kk) { cuLst(CU[kk]).forEach(function (x) { if (x.id !== id && x.nom.toLowerCase() === nom.toLowerCase()) dup = true }) });
  if (dup) { toast('Ya existe uno con ese nombre'); return }
  cuEns(c); var n = Date.now(), f = id ? cuById(c, id) : null;
  if (id && !f) { closeM(); return }
  if (!f) {
    f = { id: uid(), nom: nom, fv: fv, fi: fi, arch: false, ca: n, ua: n }; if (rd) f.rd = rd; if (tp) f.tp = tp; if (cq) { f.cq = cq; f.cd = cd } S[c.L].push(f);
    if (ini > 0) { var mi = { id: uid(), cid: f.id, t: fi != null ? fi : n, tipo: 'inicial', v: ini, bil: bl || null, nota: 'Saldo inicial', ua: n }; if (bl) mi.bd = 1; S[c.M].push(mi) }
  } else {
    var m = cuIni(c, id), base = cuSaldo(c, id) - (m ? m.v : 0);
    if (base + ini < 0) { toast('Con ese saldo inicial quedaría en negativo'); return }
    f.nom = nom; f.fv = fv; f.fi = fi; f.ua = n; f.rd = rd || null; if (tp) f.tp = tp; if (k === 'deudas') { f.cq = cq || null; f.cd = cd || null }
    if (m && ini > 0) { m.v = ini; m.ua = n; if (fi != null) m.t = fi; if (k === 'prestamos') { m.bil = bl || null; if (bl) m.bd = 1; else delete m.bd } }
    else if (m) S[c.M] = S[c.M].filter(function (x) { return x.id !== m.id })
    else if (ini > 0) { var mj = { id: uid(), cid: id, t: fi != null ? fi : (f.ca || n), tipo: 'inicial', v: ini, bil: bl || null, nota: 'Saldo inicial', ua: n }; if (bl) mj.bd = 1; S[c.M].push(mj) }
  }
  if (k === 'deudas' && typeof fxSyncDeuda === 'function') fxSyncDeuda(f);
  sv(); closeM(); render();
  var ng = bl && wal()[bl] && wal()[bl].s < 0; toast(ng ? '⚠️ Guardado. ' + bn(bl) + ' quedó en ' + cop(wal()[bl].s) : (id ? '✅ Actualizado' : '✅ Creado'))
}
/* ---------- pagos / cobros / aumentos ---------- */
function cuMov(k, cid, tipo, mid) {
  var c = CU[k], f = cuById(c, cid), m = mid ? cuMById(c, mid) : null;
  if (!f || (mid && !m) || f.arch) return;
  var w = wal(), me = tipo === c.menos, nb = !me && c.noMasBil, b0 = m ? (m.bil || '') : cLastBil;
  openM('<h3>' + (m ? '✏️ Editar ' + (me ? c.menosNm.toLowerCase() : c.masNm.toLowerCase()) : (me ? c.menosTit : c.masTit) + esc(f.nom)) + '</h3>' +
    '<label>Valor<input id="cv2" type="number" inputmode="numeric" min="0" value="' + (m ? m.v : '') + '" placeholder="0"></label>' +
    (nb ? '' :     '<label>' + (me ? c.menosLbl : c.masLbl) + '<select id="cb2"><option value=""' + (b0 === '' ? ' selected' : '') + '>Sin afectar billetera</option>' +
    bilOpts([b0]).map(function (b) { return '<option value="' + b + '"' + (b0 === b ? ' selected' : '') + '>' + esc(wl(b)) + ' (' + cop(w[b].s) + ')</option>' }).join('') + '</select></label>' +
    '<small style="display:block;margin:-4px 0 12px">' + (me ? c.hintMenos : c.hintMas) + ' Con “Sin afectar billetera” solo se registra aquí.</small>') +
    '<label>Fecha y hora<input id="ct2" type="datetime-local" value="' + ldt(m ? m.t : Date.now()) + '"></label>' +
    '<label>Nota (opcional)<input id="cn2" maxlength="80" value="' + esc(m ? m.nota : '') + '"></label>' + btns("cuMovSave('" + k + "','" + cid + "','" + tipo + "','" + (mid || '') + "')"))
}
function cuMovSave(k, cid, tipo, mid) {
  var c = CU[k], f = cuById(c, cid), m = mid ? cuMById(c, mid) : null;
  if (!f || (mid && !m)) { closeM(); return }
  var v = num('#cv2'), t = pdt($('#ct2').value), bil = $('#cb2') ? $('#cb2').value : '', nota = $('#cn2').value.trim().slice(0, 80);
  if (!(v > 0) || t === null) { toast('Revisa el valor y la fecha'); return }
  if (BILX.indexOf(bil) < 0) bil = '';
  var sg = tipo === c.menos ? -1 : 1, base = cuSaldo(c, cid) - (m ? cuSig(c, m) : 0);
  if (base + sg * v < 0) { toast(tipo === c.menos ? 'El valor supera el saldo pendiente (' + cop(base) + ')' : 'Con ese valor quedaría en negativo'); return }
  var n = Date.now();
  if (m) { m.v = v; m.t = t; m.bil = bil || null; m.nota = nota; m.ua = n }
  else {
    var l = cuMovs(c, cid).sort(function (a, b) { return b.ua - a.ua })[0];
    if (l && l.tipo === tipo && l.v === v && (l.bil || '') === bil && n - l.ua < 3000) { toast('Movimiento repetido, ignorado'); return }
    cuEns(c); S[c.M].push({ id: uid(), cid: cid, t: t, tipo: tipo, v: v, bil: bil || null, nota: nota, ua: n })
  }
  f.ua = n; cLastBil = bil; sv(); closeM(); render();
  var neg = bil && wal()[bil].s < 0;
  toast(neg ? '⚠️ Guardado. ' + bil + ' quedó en ' + cop(wal()[bil].s) : (cuSaldo(c, cid) < 0.005 && cuTot(c, cid) > 0 ? '✅ Guardado · ' + c.done.replace('🎉 ', '') : '✅ Guardado'))
}
function cuMDel(k, mid) {
  var c = CU[k], m = cuMById(c, mid); if (!m) return;
  if (m.tipo !== c.menos && cuSaldo(c, m.cid) - m.v < 0) { toast('No se puede eliminar: el saldo quedaría en negativo'); return }
  S[c.M] = S[c.M].filter(function (x) { return x.id !== mid }); var f = cuById(c, m.cid); if (f) f.ua = Date.now();
  sv(); render()
}

/* ---------- archivar y eliminar ---------- */
function cuArchivar(k, id) {
  var c = CU[k], f = cuById(c, id); if (!f) return;
  f.arch = !f.arch; f.ua = Date.now(); sv();
  if (f.arch) cdet = null;
  render(); toast(f.arch ? '📦 Archivado' : '📤 Desarchivado')
}
function cuDelAsk(k, id) {
  var c = CU[k], f = cuById(c, id); if (!f) return;
  var ms = cuMovs(c, id), cb = ms.filter(function (m) { return m.bil }).length;
  openM('<h3>¿Eliminar “' + esc(f.nom) + '”?</h3><p>Se borrará y sus ' + ms.length + ' movimiento(s) del historial.' +
    (cb ? ' <b>' + cb + ' de ellos afectaron billeteras: esas billeteras volverán al saldo que tendrían sin esos movimientos.</b>' : '') +
    ' Esta acción no se puede deshacer.</p><p><small>Si solo quieres ocultarlo, usa “Archivar”.</small></p>' +
    '<div class="two"><button class="btn out" onclick="closeM()">Cancelar</button><button class="btn bad" onclick="cuDel(\'' + k + '\',\'' + id + '\')">Eliminar</button></div>')
}
function cuDel(k, id) {
  var c = CU[k];
  S[c.M] = (S[c.M] || []).filter(function (m) { return m.cid !== id }); S[c.L] = (S[c.L] || []).filter(function (f) { return f.id !== id });
  if (k === 'deudas' && typeof fxDesligarDeuda === 'function') fxDesligarDeuda(id);
  cdet = null; sv(); closeM(); render(); toast('🗑️ Eliminado')
}
