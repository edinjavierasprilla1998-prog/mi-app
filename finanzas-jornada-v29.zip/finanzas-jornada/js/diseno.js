/* Finanzas + Jornada — diseno.js: sistema de íconos SVG, post-proceso de títulos y gráfico de 7 días (Etapa 8).
   Los íconos son trazos de 1.8 px que heredan el color del texto (currentColor), así funcionan igual en claro y oscuro.
   icoPass() cambia el emoji inicial de cada título (h1/h2) por su ícono; los emojis que elige el usuario (billeteras) no se tocan. */
var IC = {
  home: '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/>',
  moto: '<circle cx="5" cy="17" r="3"/><circle cx="19" cy="17" r="3"/><path d="M19 17l-2.4-9"/><path d="M14.4 7h3.6"/><path d="M16.2 9c-2.6.1-4 1.4-5 3H6.5c-1.4 0-2.2.6-2.6 1.6"/><path d="M8 17h4.5l1.5-5"/><path d="M13 17.2h-1"/>',
  swap: '<path d="M4 8h15"/><path d="M15 4l4 4-4 4"/><path d="M20 16H5"/><path d="M9 12l-4 4 4 4"/>',
  history: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  wallet: '<path d="M3 7a2 2 0 0 1 2-2h13v4"/><path d="M3 7v11a2 2 0 0 0 2 2h14a1 1 0 0 0 1-1v-3"/><path d="M21 9h-4a2 2 0 0 0 0 4h4z"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>',
  phone: '<rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18h2"/>',
  target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
  receipt: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
  coins: '<circle cx="9" cy="12" r="6"/><path d="M15 6.3a6 6 0 0 1 0 11.4"/>',
  hourglass: '<path d="M6 3h12M6 21h12"/><path d="M7 3v3a5 5 0 0 0 10 0V3"/><path d="M7 21v-3a5 5 0 0 1 10 0v3"/>',
  pie: '<path d="M21 12A9 9 0 1 1 12 3v9z"/><path d="M15 3.5A9 9 0 0 1 20.5 9H15z"/>',
  bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 8 3 8H3s3-1 3-8"/><path d="M10 20a2 2 0 0 0 4 0"/>',
  chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  card: '<rect x="2.5" y="5" width="19" height="14" rx="3"/><path d="M2.5 10h19"/>',
  scale: '<path d="M12 4v16M6 20h12M5 7h14"/><path d="M5 7l-3 7a3 3 0 0 0 6 0zM19 7l-3 7a3 3 0 0 0 6 0z"/>',
  pause: '<rect x="6" y="5" width="4" height="14" rx="1"/><rect x="14" y="5" width="4" height="14" rx="1"/>',
  flag: '<path d="M5 21V4"/><path d="M5 4h12l-2 4 2 4H5"/>',
  box: '<path d="M3 7l9-4 9 4v10l-9 4-9-4z"/><path d="M3 7l9 4 9-4M12 11v10"/>',
  cloud: '<path d="M7 18a4 4 0 0 1-.5-7.97A6 6 0 0 1 18 9a4.5 4.5 0 0 1 0 9z"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
  ticket: '<path d="M3 9a2 2 0 0 0 0 6v3h18v-3a2 2 0 0 1 0-6V6H3z"/><path d="M13 6v12" stroke-dasharray="2 3"/>'
};
var EMO = { '🏠': 'home', '🏍️': 'moto', '🏍': 'moto', '🚕': 'moto', '💰': 'wallet', '📜': 'history', '⚙️': 'gear', '⚙': 'gear', '👛': 'wallet', '📲': 'phone', '🤝': 'receipt', '💵': 'coins', '💸': 'coins', '⏳': 'hourglass', '📊': 'pie', '🎯': 'target', '🔔': 'bell', '🧾': 'receipt', '📈': 'chart', '💳': 'card', '⚖️': 'scale', '⚖': 'scale', '⏸️': 'pause', '⏸': 'pause', '🏁': 'flag', '📦': 'box', '☁️': 'cloud', '☁': 'cloud', '👤': 'user', '🎟️': 'ticket', '🎟': 'ticket', '🔄': 'swap' };
function ico(n, s) { var p = IC[n]; if (!p) return ''; s = s || 22; return '<svg class="ics" viewBox="0 0 24 24" width="' + s + '" height="' + s + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>' }
function icoE(e) { var n = EMO[e]; return n ? ico(n, 22) : e }
/* Reemplaza el emoji inicial de h1/h2 por su ícono (o lo quita si no hay equivalente). */
function icoPass() {
  [].forEach.call(document.querySelectorAll('#app h1,#app h2'), function (h) {
    var t = h.firstChild; if (!t || t.nodeType !== 3) return;
    var m = t.nodeValue.match(/^\s*(\p{Extended_Pictographic}(?:\uFE0F|\u200D\p{Extended_Pictographic})*)\s*/u); if (!m) return;
    t.nodeValue = t.nodeValue.slice(m[0].length);
    var n = EMO[m[1]] || EMO[m[1].replace(/\uFE0F/g, '')];
    if (n) { var s = document.createElement('span'); s.className = 'hico'; s.innerHTML = ico(n, h.tagName === 'H1' ? 24 : 16); h.insertBefore(s, t) }
  })
}
/* Quita el emoji inicial de los rótulos pequeños (tarjetas, héroe) para un look más limpio. */
function lblPass() {
  [].forEach.call(document.querySelectorAll('#app .tile small,#app .hero>small,#app .hero .sub span,#app .kv>span:first-child,#app .chart .lg span'), function (e) {
    var t = e.firstChild; if (!t || t.nodeType !== 3) return;
    var m = t.nodeValue.match(/^\s*(?:\p{Extended_Pictographic}(?:\uFE0F|\u200D\p{Extended_Pictographic})*)\s*/u); if (m) t.nodeValue = t.nodeValue.slice(m[0].length)
  })
}
/* Gráfico: ingresos y costos de los últimos 7 días. */
function dChart() {
  var D = 86400000, hoy = d0(Date.now()), days = [], i;
  for (i = 6; i >= 0; i--) days.push(hoy - i * D);
  var ing = [0, 0, 0, 0, 0, 0, 0], cos = [0, 0, 0, 0, 0, 0, 0];
  function ix(t) { var k = Math.floor((d0(t) - days[0]) / D); return k >= 0 && k < 7 ? k : -1 }
  (S.j || []).forEach(function (j) { (j.ca || []).forEach(function (c) { var k = ix(c.t); if (k >= 0) { ing[k] += c.v + c.p; cos[k] += c.cm || 0 } }) });
  (S.mv || []).forEach(function (m) { var k = ix(m.t); if (k < 0) return; if (m.tipo === 'ingreso') ing[k] += m.v; else if (m.tipo === 'costo') cos[k] += m.v });
  (S.am || []).forEach(function (m) { var k = ix(m.t); if (k < 0) return; if (m.tipo === 'premio') ing[k] += m.v; else if (m.tipo === 'recarga' || m.tipo === 'comision') cos[k] += m.v; else if (m.tipo === 'retiro' && m.cr > 0) cos[k] += m.cr });
  (S.xm || []).forEach(function (m) { if (m.tipo === 'cobro') { var k = ix(m.t); if (k >= 0) ing[k] += m.v } });
  var mx = Math.max.apply(null, ing.concat(cos)), ti = 0, tc = 0; if (!(mx > 0)) return '';
  ing.forEach(function (v) { ti += v }); cos.forEach(function (v) { tc += v });
  var L = ['D', 'L', 'M', 'M', 'J', 'V', 'S'], g = '';
  days.forEach(function (d, k) {
    var x = k * 48 + 8, hi = Math.round(ing[k] / mx * 78), hc = Math.round(cos[k] / mx * 78), hoyk = k === 6;
    g += '<rect class="bi" x="' + (x + 4) + '" y="' + (92 - hi) + '" width="14" height="' + Math.max(hi, ing[k] > 0 ? 3 : 0) + '" rx="4"/><rect class="bc" x="' + (x + 22) + '" y="' + (92 - hc) + '" width="14" height="' + Math.max(hc, cos[k] > 0 ? 3 : 0) + '" rx="4"/>' +
      '<text x="' + (x + 20) + '" y="112" text-anchor="middle" class="' + (hoyk ? 'tx on' : 'tx') + '">' + L[new Date(d).getDay()] + '</text>'
  });
  return '<h2>📈 Últimos 7 días</h2><div class="card chart"><svg viewBox="0 0 336 120" role="img" aria-label="Ingresos y costos de los últimos 7 días"><line x1="0" y1="92.5" x2="336" y2="92.5" class="ax"/>' + g + '</svg>' +
    '<div class="lg"><span><i class="bi"></i>Ingresos ' + cop(ti) + '</span><span><i class="bc"></i>Costos ' + cop(tc) + '</span></div></div>'
}
