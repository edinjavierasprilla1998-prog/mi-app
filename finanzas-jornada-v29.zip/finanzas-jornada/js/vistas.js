/* Finanzas + Jornada — vistas.js: vistas: inicio, jornada, movimientos, historial y detalle. Separado de index.html en la Etapa 1, sin cambios de lógica. */
/* ---- vistas ---- */
function st(l,v){return '<div class="tile"><small>'+l+'</small><b>'+v+'</b></div>'}
function kv(l,v,c){return '<div class="kv"><span>'+l+'</span><b class="'+(c||'')+'">'+v+'</b></div>'}
function sec(t,b){return '<h2>'+t+'</h2><div class="card">'+b+'</div>'}
function dm(ms){ms=Math.max(0,Math.floor(ms/60000));return Math.floor(ms/60)+'h '+String(ms%60).padStart(2,'0')+'m'}
function wcard(b,x){return '<div class="wr"><span class="ic">'+(BI[b]||'❔')+'</span><div class="g"><b>'+esc(bn(b))+'</b><br><small>+'+cop(x.i)+' · −'+cop(x.g)+(x.t?' · ↔ '+cop(x.t):'')+'</small></div><b class="big '+(x.s<0?'neg':'')+'">'+cop(x.s)+'</b></div>'}
function vInicio(){var d=dash(),w=wal(),disp=0;BILX.forEach(function(b){disp+=w[b].s});
return '<h1>Finanzas + Jornada</h1><div class="seg">'+['hoy','semana','mes'].map(function(p){return '<button class="'+(p===per?'on':'')+'" onclick="per=\''+p+'\';render()">'+p[0].toUpperCase()+p.slice(1)+'</button>'}).join('')+'</div>'+
'<div class="hero"><small>📈 Ganancia real</small><b>'+cop(d.gr)+'</b><div class="sub"><span>💵 Disponible ahora<br><b>'+cop(disp)+'</b></span><span>📈 Ganancia/hora<br><b>'+cop(d.h)+'</b></span></div></div>'+
avPanel()+(per==='hoy'?gpHTML()+ccHTML()+mdHTML():'')+fxHoyHTML()+pxHoyHTML(false)+'<div class="tiles">'+st('💰 Ingresos',cop(d.ing))+st('🏍️ Costos operativos',cop(d.co))+st('⏱️ Tiempo efectivo',dm(d.ef))+st('🏍️ Km recorridos',d.km+' km')+'</div>'+
dChart()+sec('Otros indicadores',kv('👤 Gastos personales',cop(d.gp))+kv('⏸️ Pausas',dm(d.ps)))+
'<h2>Billeteras</h2><div class="card">'+bilVis(w).map(function(b){return wcard(b,w[b])}).join('')+'</div>'+apInicio()+cuInicio()}
function live(j){var s=js(j),op=j.pa.filter(function(p){return !p.b})[0];
return '<div class="hero"><span class="wm">'+ico('moto',176)+'</span><div class="row"><small>🏍️ Jornada · inició '+hm(j.ini)+'</small>'+(op?'<span class="chip pause">⏸️ En pausa</span>':'<span class="chip">● En curso</span>')+'</div><small>⏱️ Tiempo efectivo</small><b>'+dur(s.ef)+'</b><div class="sub"><span>Trabajado<br><b>'+dur(s.tr)+'</b></span><span>'+(j.mt==='e'?'Falta efectivo<br><b>'+dur(Math.max(0,j.hp*3600000-s.ef)):'Restante<br><b>'+dur(s.est-Date.now()))+'</b></span></div></div>'+
(op?'<div class="warn"><b>⏸️ '+esc(op.m)+'</b><span>desde '+hm(op.a)+' · '+dur(Date.now()-op.a)+'</span></div>':'')+
'<div class="card">'+kv('🕐 Salida estimada',estTxt(j))+kv('💰 Ingresos',cop(s.ing))+kv('🏍️ Costos operativos',cop(s.co))+kv('📈 Ganancia real',cop(s.gr),s.gr<0?'neg':'pos')+kv('📈 Ganancia/hora',cop(s.h))+'</div>'+jProg(j,s)}
function vJornada(){var j=act();
if(!j){setTimeout(jfPrev,0);return jfHTML()}
var op=j.pa.some(function(p){return !p.b});
return '<div id="live">'+live(j)+'</div>'+jMetaBtn(j)+ccHTML()+mdHTML()+
pxHoyHTML(true)+vjForm()+(j.ca.length?'<h2>Carreras de esta jornada</h2>'+carr(j):'')+
(op?'<h2>⏸️ Pausa activa</h2><button class="btn bad" onclick="endP()">▶️ Terminar pausa</button>':'<h2>⏸️ Pausar · elige el motivo</h2><div class="pz">'+paAll().map(function(p){return '<button onclick="startP(\''+p[1]+'\')"><span>'+p[0]+'</span>'+p[1]+'</button>'}).join('')+'</div><button class="btn out sm" style="margin-top:8px" onclick="paForm()">➕ Nueva categoría</button>')+
(j.pa.length?'<h2>⏸️ Pausas de esta jornada</h2>'+pausaList(j):'')+
'<h2>🏁 Finalizar</h2><div class="card form"><label>Km finales<input id="kf" type="number" inputmode="decimal" min="'+j.ki+'" placeholder="Km iniciales: '+j.ki+'"></label><button class="btn out" onclick="endJ()">🏁 Finalizar jornada</button></div>'}
function carr(j){return j.ca.slice().reverse().map(function(c){return '<div class="li"><span class="ic">🚕</span><div class="g"><b>'+cop(c.v)+'</b>'+(c.p?' <small>+ '+cop(c.p)+' propina</small>':'')+'<br><small>'+hm(c.t)+' · '+vjDet(c,j.id)+'</small></div>'+abtn("CE('"+j.id+"','"+c.id+"')","delC('"+j.id+"','"+c.id+"')",'carrera')+'</div>'}).join('')}
var MI={ingreso:'💰',costo:'🏍️',personal:'👤',transferencia:'🔄'};
function vMov(){var w=wal(),ed=!!EM,em=EM&&S.mv.filter(function(x){return x.id===EM})[0];
var h='<h1>💰 Movimientos</h1><div class="card">'+bilVis(w).map(function(b){return kv(esc(wl(b)),cop(w[b].s),w[b].s<0?'neg':'')}).join('')+'</div><h2>'+(ed?'✏️ Editar movimiento':'Nuevo movimiento')+'</h2><div class="card form"><label>Tipo<select id="mt" onchange="fillC()"><option value="ingreso">💰 Ingreso</option><option value="costo" selected>🏍️ Costo operativo</option><option value="personal">👤 Gasto personal</option><option value="transferencia">🔄 Transferencia</option></select></label><label>Categoría<select id="mc"></select></label><label>Billetera'+bilSel('mb',em&&em.bil)+'</label><label>Billetera destino'+bilSel('mb2',em&&em.bil2||BIL[1]||BIL[0])+'</label><label>Fecha y hora<input id="mf" type="datetime-local"></label><div class="two"><label>Valor<input id="mv" type="number" inputmode="numeric" min="0"></label><label>Nota<input id="mn" maxlength="80"></label></div>'+cpMovHTML()+(ed?'<div class="two"><button class="btn out" onclick="Mcancel()">Cancelar</button><button class="btn" onclick="addM()">Guardar cambios</button></div>':'<button class="btn" onclick="addM()">Guardar movimiento</button>')+'</div><h2>Últimos movimientos</h2>';
h+=S.mv.length?S.mv.slice().sort(function(a,b){return b.t-a.t}).slice(0,40).map(function(m){return movLi(m)}).join(''):'<div class="li"><small>Aún no hay movimientos. Registra el primero arriba.</small></div>';return h}
var HV={m:'dia',sel:Date.now(),ym:new Date(new Date().getFullYear(),new Date().getMonth(),1).getTime(),r1:'',r2:''};
function addD(t,n){var d=new Date(t);d.setDate(d.getDate()+n);return d.getTime()}
function d0(t){var d=new Date(t);d.setHours(0,0,0,0);return d.getTime()}
function iso(t){var d=new Date(t);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}
function pd(x){var p=(x||'').split('-');return p.length===3?new Date(+p[0],+p[1]-1,+p[2]).getTime():NaN}
function fdm(x){var p=x.split('-');return p[2]+'/'+p[1]+'/'+p[0]}
function mname(t){var x=new Date(t).toLocaleDateString('es-CO',{month:'long',year:'numeric'});return x.charAt(0).toUpperCase()+x.slice(1)}
function m1(t){var d=new Date(t);return new Date(d.getFullYear(),d.getMonth(),1).getTime()}
function hper(){var a,b,l,t=d0(HV.sel);
if(HV.m==='dia'){a=t;b=addD(a,1);l=fd(a)+(a===d0(Date.now())?' · Hoy':'')}
else if(HV.m==='semana'){a=addD(t,-((new Date(t).getDay()+6)%7));b=addD(a,7);l=fd(a)+' – '+fd(addD(b,-1))}
else if(HV.m==='mes'){var y=new Date(HV.ym);a=HV.ym;b=new Date(y.getFullYear(),y.getMonth()+1,1).getTime();l=mname(HV.ym)}
else{a=pd(HV.r1);var e=pd(HV.r2);if(isNaN(a)||isNaN(e)||e<a)return{bad:1};b=addD(e,1);l=fdm(HV.r1)+' → '+fdm(HV.r2)}
return{a:a,b:b,l:l}}
function Hmode(m){HV.m=m;if(m==='dia'){HV.sel=Date.now();HV.ym=m1(Date.now())}
if(m==='rango'&&!HV.r1){HV.r1=iso(HV.ym);HV.r2=iso(Date.now())}render()}
function Hsel(t){HV.sel=t;HV.m='dia';render()}
function Hcal(n){var y=new Date(HV.ym);HV.ym=new Date(y.getFullYear(),y.getMonth()+n,1).getTime();render()}
function Hstep(n){if(HV.m==='mes'){Hcal(n);return}HV.sel=addD(HV.sel,HV.m==='semana'?7*n:n);HV.ym=m1(HV.sel);render()}
function Hap(){HV.r1=$('#r1').value;HV.r2=$('#r2').value;render()}
function cal(p){var y=new Date(HV.ym),Y=y.getFullYear(),M=y.getMonth(),first=(new Date(Y,M,1).getDay()+6)%7,days=new Date(Y,M+1,0).getDate(),A={},tdy=d0(Date.now());
S.j.forEach(function(j){A[dk(j.ini)]=1});(S.am||[]).forEach(function(m){if(m.tipo==='premio')A[dk(m.t)]=1});var W=rtGanDias(Y,M);
var h='<div class="card cal"><div class="ch"><button class="cb" aria-label="Mes anterior" onclick="Hcal(-1)">◀</button><b>'+mname(HV.ym)+'</b><button class="cb" aria-label="Mes siguiente" onclick="Hcal(1)">▶</button></div><div class="cg">'+'LMXJVSD'.split('').map(function(c){return '<span class="cw">'+c+'</span>'}).join('');
for(var i=0;i<first;i++)h+='<span></span>';
for(var d=1;d<=days;d++){var t=new Date(Y,M,d).getTime(),c='cd'+(p.a!==undefined&&t>=p.a&&t<p.b?' in':'')+(t===tdy?' td':'')+(HV.m==='dia'&&t===d0(HV.sel)?' sl':'');
h+='<button class="'+c+'" onclick="Hsel('+t+')" aria-label="Día '+d+'">'+d+(A[Y+'-'+M+'-'+d]?'<i></i>':'')+rtBadge(W[Y+'-'+M+'-'+d])+'</button>'}
return h+'</div></div>'}
function vHist(){if(det)return vDet();var p=hper(),h='<h1>📜 Historial</h1><div class="seg">'+[['dia','Hoy'],['semana','Semana'],['mes','Mes'],['rango','📅 Rango']].map(function(x){var on=HV.m===x[0]&&(x[0]!=='dia'||d0(HV.sel)===d0(Date.now()));return '<button class="'+(on?'on':'')+'" onclick="Hmode(\''+x[0]+'\')">'+x[1]+'</button>'}).join('')+'</div>'+cal(p);
if(HV.m==='rango')h+='<div class="card form" style="margin-top:8px"><div class="two"><label>Fecha inicial<input id="r1" type="date" value="'+esc(HV.r1)+'"></label><label>Fecha final<input id="r2" type="date" value="'+esc(HV.r2)+'"></label></div><button class="btn" onclick="Hap()">Aplicar rango</button></div>';
if(p.bad)return h+'<div class="li" style="margin-top:8px"><small>Elige una fecha inicial y una final (la final no puede ser anterior).</small></div>';
h+='<div class="pb'+(HV.m==='rango'?' c':'')+'">'+(HV.m==='rango'?'':'<button class="cb" aria-label="Anterior" onclick="Hstep(-1)">◀</button>')+'<b>'+p.l+'</b>'+(HV.m==='rango'?'':'<button class="cb" aria-label="Siguiente" onclick="Hstep(1)">▶</button>')+'</div>';
var r=S.j.filter(function(j){return j.ini>=p.a&&j.ini<p.b}).sort(function(a,b){return b.ini-a.ini});
if(!r.length)return h+rtCard(p)+prHist(p)+'<div class="li"><small>Sin jornadas en este periodo.</small></div>';
var T={tr:0,ef:0,ing:0,co:0,gp:0,km:0};r.forEach(function(j){var s=js(j);T.tr+=s.tr;T.ef+=s.ef;T.km+=s.km});
/* Ingresos, costos y personales cuentan por la fecha en que se registraron (igual que Inicio), no por la jornada. */
S.j.forEach(function(j){j.ca.forEach(function(c){if(c.t>=p.a&&c.t<p.b){T.ing+=c.v+c.p;T.co+=c.cm||0}})});
S.mv.forEach(function(m){if(m.t<p.a||m.t>=p.b)return;if(m.tipo==='ingreso')T.ing+=m.v;if(m.tipo==='costo')T.co+=m.v;if(m.tipo==='personal')T.gp+=m.v});
var aw=amWin(p.a,p.b-1);T.ing+=aw.ing;T.co+=aw.co;
var gr=T.ing-T.co,dis=gr-T.gp;
h+='<div class="card"><div class="sr"><div><small>📈 Ganancia real</small><b class="big '+(gr<0?'neg':'pos')+'">'+cop(gr)+'</b></div><div class="r"><small>💵 Neto tras gastos</small><b>'+cop(dis)+'</b></div></div>'+
'<div class="sg" style="grid-template-columns:repeat(4,auto)">'+[['🏍️ Jornadas',r.length],['⏱️ Trabajado',dm(T.tr)],['⏱️ Efectivo',dm(T.ef)],['📍 Km',T.km]].map(function(x){return '<div><small>'+x[0]+'</small><b>'+x[1]+'</b></div>'}).join('')+'</div>'+
'<div class="sg" style="grid-template-columns:repeat(3,auto)">'+[['💰 Ingresos',cop(T.ing)],['🏍️ Costos',cop(T.co)],['👤 Personales',cop(T.gp)]].map(function(x){return '<div><small>'+x[0]+'</small><b>'+x[1]+'</b></div>'}).join('')+'</div></div>'+rtCard(p)+prHist(p)+'<h2>Jornadas</h2>';
return h+r.map(function(j){var s=js(j);return '<div class="li hc tap" onclick="det=\''+j.id+'\';render()"><div class="row"><b>'+fd(j.ini)+'</b><small>🕐 '+hm(j.ini)+' → '+(j.fin?hm(j.fin)+(dk(j.fin)!==dk(j.ini)?' (+1)':''):'en curso')+'</small></div><div class="row" style="margin-top:3px"><span>💰 '+cop(s.ing)+'</span><b class="'+(s.gr<0?'neg':'pos')+'">📈 '+cop(s.gr)+'</b></div><small>⏱️ '+dm(s.ef)+' efectivo · 🏍️ '+s.km+' km</small></div>'}).join('')}
function vDet(){var j=S.j.filter(function(x){return x.id===det})[0];if(!j){det=null;return vHist()}var s=js(j);
return '<button class="btn out sm" onclick="det=null;render()">← Volver al historial</button><h1>📅 '+fd(j.ini)+'</h1><div class="hero"><small>📈 Ganancia real</small><b>'+cop(s.gr)+'</b><div class="sub"><span>💵 Neto tras gastos<br><b>'+cop(s.dis)+'</b></span><span>📈 Ganancia/hora<br><b>'+cop(s.h)+'</b></span></div></div>'+
sec('🕐 Horarios',kv('Inicio',hm(j.ini))+kv('Salida',j.fin?hm(j.fin):'en curso')+kv('Salida estimada',estTxt(j)))+
sec('💰 Finanzas',kv('Ingresos',cop(s.ing))+kv('Costos operativos',cop(s.co))+kv('Gastos personales',cop(s.gp))+kv('Ganancia real',cop(s.gr),s.gr<0?'neg':'pos')+kv('Neto después de gastos',cop(s.dis),s.dis<0?'neg':''))+
sec('⏱️ Tiempo',kv('Trabajado',dur(s.tr))+kv('Efectivo',dur(s.ef))+kv('Total de pausas',dur(s.ps))+kv('Cantidad de pausas',j.pa.length)+(j.fin?'':kv('Restante',dur(s.est-Date.now()))))+
prDet(j)+(j.pa.length?'<h2>⏸️ Pausas</h2>'+pausaList(j):'')+
sec('🏍️ Recorrido',kv('Km iniciales',j.ki)+kv('Km finales',j.kf!=null?j.kf:'—')+kv('Km recorridos',s.km+' km'))+
sec('📈 Rendimiento',kv('Ganancia/hora',cop(s.h))+kv('Ganancia/km',cop(s.gk)))+
(j.ca.length?'<h2>🚕 Carreras</h2>'+carr(j):'')+jmovs(j)+'<div style="margin-top:20px"><button class="btn out" style="margin-bottom:8px" onclick="JE(\''+j.id+'\')">✏️ Editar jornada</button><button class="btn bad" onclick="ask(this,function(){delJ(\''+j.id+'\')},\'jornada\')">Eliminar jornada</button></div>'}
