/* Gastos programados con confirmación (fj-v28).
   S.gp = [{id,n,m,k:'p'|'o',cat,bil,fr:{t:'d'|'s'|'m'|'c',ds:[],dm,ca,ref},hr:'HH:MM'|'',pa,cr}]
   S.gl = bitácora [{g,d:'YYYY-MM-DD',e:'ok'|'no',v,mid,t}]
   Nada se registra como gasto real hasta que se confirma. */
var GPC = { cp: null, rf: '' }, GPX = {}, GPED = null;
var GPDN = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
function gpList() { return Array.isArray(S.gp) ? S.gp.filter(function (g) { return g && g.id && g.m > 0 }) : [] }
function gpLog() { return Array.isArray(S.gl) ? S.gl : [] }
function gpById(id) { return gpList().filter(function (g) { return g.id === id })[0] }
function gpAplica(g, t) {
  var d = new Date(t), f = g.fr || { t: 'd' };
  if (f.t === 'd') return true;
  if (f.t === 's') return (f.ds || []).indexOf(d.getDay()) >= 0;
  if (f.t === 'm') { var last = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate(); return d.getDate() === Math.min(f.dm || 1, last) }
  if (f.t === 'c') { var n = Math.round((d0(t) - d0(f.ref || g.cr || t)) / 86400000); return f.ca > 0 && n >= 0 && n % f.ca === 0 }
  return false
}
function gpEst(g, t) { var k = iso(t); return gpLog().filter(function (x) { return x.g === g.id && x.d === k })[0] }
function gpHrMin(g) { var p = (g.hr || '').split(':'); return p.length === 2 && p[0] !== '' ? (+p[0]) * 60 + (+p[1]) : null }
function gpFrTxt(g) {
  var f = g.fr || { t: 'd' };
  return f.t === 'd' ? 'Todos los días' : f.t === 's' ? (f.ds || []).slice().sort(function (a, b) { return ((a + 6) % 7) - ((b + 6) % 7) }).map(function (d) { return GPDN[d] }).join(', ') : f.t === 'm' ? 'Día ' + f.dm + ' de cada mes' : 'Cada ' + f.ca + ' días'
}
function gpTipo(g) { return g.k === 'o' ? 'costo' : 'personal' }
function gpBil(g) { return BILX.indexOf(g.bil) >= 0 ? g.bil : (BIL[0] || 'Efectivo') }
function gpPend() {
  var n = Date.now(), d = new Date(n), min = d.getHours() * 60 + d.getMinutes(), r = [];
  gpList().forEach(function (g) {
    if (g.pa || !gpAplica(g, n) || gpEst(g, n)) return;
    var h = gpHrMin(g); r.push({ g: g, h: h, due: h === null || min >= h })
  });
  r.sort(function (a, b) { return (a.h == null ? 1e4 : a.h) - (b.h == null ? 1e4 : b.h) });
  return r
}
/* ¿ya lo anotó a mano hoy? mismo tipo y categoría, valor parecido (±25 %) y no vinculado a otra confirmación */
function gpPosible(g) {
  var n = Date.now(), usados = {}; gpLog().forEach(function (x) { if (x.mid) usados[x.mid] = 1 });
  var l = S.mv.filter(function (m) { return !usados[m.id] && !m.gp && dk(m.t) === dk(n) && m.tipo === gpTipo(g) && m.cat === (g.cat || 'Otros') && Math.abs(m.v - g.m) <= g.m * 0.25 });
  return l.length ? l[l.length - 1] : null
}
function gpHist(g) { return gpLog().filter(function (x) { return x.g === g.id && x.e === 'ok' && x.v > 0 }).slice(-5) }
function gpSug(g) {
  var h = gpHist(g); if (h.length < 3) return 0;
  var s = 0; h.forEach(function (x) { s += x.v }); var a = Math.round(s / h.length / 100) * 100;
  return Math.abs(a - g.m) >= g.m * 0.1 ? a : 0
}
function gpOmitidos(g) {
  var l = gpLog().filter(function (x) { return x.g === g.id }), c = 0;
  for (var i = l.length - 1; i >= 0; i--) { if (l[i].e === 'no') c++; else break }
  return c
}
/* ---------- confirmar ---------- */
function gpCrear(g, v, bil, nota, cp, rf) {
  if (!Array.isArray(S.gl)) S.gl = [];
  var n = Date.now(), rec = { id: uid(), cr: n, t: n, tipo: gpTipo(g), cat: g.cat || 'Otros', bil: bil, bil2: null, v: v, nota: (nota != null && nota !== '' ? nota : g.n).slice(0, 80), gp: g.id };
  if (cp) rec.cp = cp; if (rf) rec.rf = rf;
  S.mv.push(rec); S.gl.push({ g: g.id, d: iso(n), e: 'ok', v: v, mid: rec.id, t: n }); sv();
  return rec
}
function gpDeshacer(rec) { S.mv = S.mv.filter(function (m) { return m.id !== rec.id }); S.gl = gpLog().filter(function (x) { return x.mid !== rec.id }); cpDel(rec.cp); sv(); render() }
function gpAviso(rec, b) {
  var w = wal(), s = w[b] ? w[b].s : 0;
  toastU('✅ ' + esc(rec.nota) + ' · ' + cop(rec.v) + ' · ' + wl(b) + (s < 0 ? ' (saldo negativo)' : ''), function () { gpDeshacer(rec) })
}
function gpOk(id) {
  var g = gpById(id); if (!g || gpEst(g, Date.now())) return;
  var b = gpBil(g), rec = gpCrear(g, g.m, b); render(); gpAviso(rec, b)
}
function gpTodos() {
  var l = gpPend().filter(function (x) { return x.due && !gpPosible(x.g) }), t = 0; if (!l.length) return;
  l.forEach(function (x) { gpCrear(x.g, x.g.m, gpBil(x.g)); t += x.g.m });
  render(); toast('✅ ' + l.length + ' gastos confirmados · ' + cop(t))
}
function gpEs(id) {
  var g = gpById(id), m = g && gpPosible(g); if (!m) return;
  S.gl.push({ g: g.id, d: iso(Date.now()), e: 'ok', v: m.v, mid: m.id, t: Date.now() }); sv(); render(); toast('Listo: se vinculó con lo que ya anotaste')
}
function gpDist(id) { GPX[id] = 1; render() }
function gpNo(id) {
  var g = gpById(id); if (!g) return; if (!Array.isArray(S.gl)) S.gl = [];
  var e = { g: g.id, d: iso(Date.now()), e: 'no', t: Date.now() }; S.gl.push(e); sv(); render();
  toastU('⏭️ Hoy no: ' + esc(g.n), function () { S.gl = gpLog().filter(function (x) { return x !== e }); sv(); render() })
}
function gpEd(id) {
  var g = gpById(id); if (!g) return; GPED = id; GPC = { cp: null, rf: '' };
  openM('<h3>🧾 ' + esc(g.n) + '</h3><label>¿Cuánto fue?<input id="gev" type="number" inputmode="numeric" min="0" value="' + (gpSug(g) || g.m) + '"></label>' +
    '<label>Billetera' + bilSel('geb', gpBil(g)) + '</label><label>Nota (opcional)<input id="gen" maxlength="80" placeholder="' + esc(g.n) + '"></label>' + gpCpHTML() +
    '<div class="two"><button class="btn out" onclick="gpEdCancel()">Cancelar</button><button class="btn" onclick="gpEdOk()">Confirmar gasto</button></div>')
}
function gpEdCancel() { cpDel(GPC.cp); GPC = { cp: null, rf: '' }; closeM() }
function gpEdOk() {
  var g = gpById(GPED); if (!g) { closeM(); return }
  var v = num('#gev'), b = $('#geb').value; if (!(v > 0)) { toast('Escribe un valor mayor que 0'); return }
  if (gpEst(g, Date.now())) { closeM(); return }
  var rec = gpCrear(g, v, b, ($('#gen').value || '').trim(), GPC.cp, (GPC.rf || '').trim()); GPC = { cp: null, rf: '' }; GPED = null; closeM(); render(); gpAviso(rec, b)
}
function gpCpHTML() {
  return '<div id="gpcp">' + (GPC.cp
    ? '<div class="kv"><span>📎 Comprobante</span><b><button class="mini" onclick="cpVer(GPC.cp)">Ver</button> <button class="mini bad" onclick="gpCpQuitar()">Quitar</button></b></div>' +
    '<label>Referencia (opcional)<input type="text" value="' + esc(GPC.rf || '') + '" oninput="GPC.rf=this.value"></label>'
    : '<small style="display:block;font-weight:600;margin-bottom:4px">📎 Comprobante de transferencia (opcional)</small><div class="two"><button class="btn out sm" onclick="gpCpAdd(1)">📷 Tomar foto</button><button class="btn out sm" onclick="gpCpAdd()">🖼️ Galería</button></div>') + '</div>'
}
function gpCpPaint() { var e = $('#gpcp'); if (e) e.outerHTML = gpCpHTML() }
function gpCpAdd(cam) { cpNueva(cam).then(function (id) { if (!id) return; if (GPC.cp) cpDel(GPC.cp); GPC.cp = id; gpCpPaint() }) }
function gpCpQuitar() { cpDel(GPC.cp); GPC.cp = null; gpCpPaint() }

/* ---------- tarjeta en Inicio ---------- */
function gpHTML() {
  var L = gpList(); if (!L.length) return '';
  var P = gpPend(), n = Date.now(), hoyN = L.filter(function (g) { return !g.pa && gpAplica(g, n) }).length;
  if (!P.length) return hoyN ? '<h2>🧾 Gastos programados</h2><div class="card"><small>✅ Todo confirmado por hoy.</small></div>' : '';
  var due = P.filter(function (x) { return x.due }), later = P.filter(function (x) { return !x.due });
  var h = '<h2>🧾 Por confirmar hoy</h2><div class="card">';
  due.forEach(function (x) {
    var g = x.g, pos = !GPX[g.id] && gpPosible(g), sg = gpSug(g);
    h += '<div style="padding:8px 0;border-bottom:1px solid var(--s2)"><div class="kv"><span>' + (g.k === 'o' ? '🏍️' : '👤') + ' ' + esc(g.n) + (g.hr ? ' <small>' + esc(g.hr) + '</small>' : '') + '</span><b>' + cop(g.m) + '</b></div>';
    if (pos) h += '<small>Parece que ya lo anotaste: <b>' + cop(pos.v) + '</b> a las ' + hm(pos.t) + '</small><div class="two" style="margin-top:6px"><button class="btn sm" onclick="gpEs(\'' + g.id + '\')">Sí, es ese</button><button class="btn out sm" onclick="gpDist(\'' + g.id + '\')">Son distintos</button></div>';
    else h += (sg ? '<small>Últimas veces pagaste ≈ ' + cop(sg) + '</small>' : '') + '<div style="display:flex;gap:6px;margin-top:6px"><button class="btn sm" style="flex:2" onclick="gpOk(\'' + g.id + '\')">✅ Sí, fue eso</button><button class="btn out sm" style="flex:1.3" onclick="gpEd(\'' + g.id + '\')">✏️ Otro</button><button class="btn out sm" style="flex:1.3" onclick="gpNo(\'' + g.id + '\')">⏭️ No</button></div>'
    h += '</div>'
  });
  var ya = due.filter(function (x) { return !gpPosible(x.g) }).length;
  if (ya >= 2) h += '<button class="btn out" style="margin-top:10px" onclick="gpTodos()">Confirmar los ' + ya + ' con su valor</button>';
  if (later.length) h += '<small style="display:block;margin-top:8px">Más tarde: ' + later.map(function (x) { return esc(x.g.n) + ' ' + esc(x.g.hr) + ' (' + cop(x.g.m) + ')' }).join(' · ') + '</small>';
  return h + '</div>'
}
function gpAvisos() {
  var A = [], n = Date.now();
  gpPend().forEach(function (x) { if (x.due && x.h !== null) A.push({ k: 'gp' + x.g.id + '_' + iso(n), sev: 1, ic: '🧾', tx: '¿Pagaste ' + esc(x.g.n) + '? · ' + cop(x.g.m), sub: 'Confírmalo en Inicio con un toque', t: n, hr: 0, go: ['inicio', null, null, null] }) });
  return A
}
/* ---------- configuración (Ajustes) ---------- */
function gpCfgHTML() {
  var L = gpList(), hay = (S.mdc && Array.isArray(S.mdc.gd) && S.mdc.gd.length) && !L.length;
  return '<h2>🧾 Gastos programados</h2><div class="card form"><small>Programa los gastos que repites y la app te pregunta si fue eso. Nada se registra hasta que confirmas.</small>' +
    (L.length ? L.map(function (g) {
      var sg = gpSug(g), om = gpOmitidos(g);
      return '<div style="padding:8px 0;border-top:1px solid var(--s2)"><div class="kv"><span>' + (g.k === 'o' ? '🏍️' : '👤') + ' ' + esc(g.n) + (g.pa ? ' <small>(en pausa)</small>' : '') + '</span><b>' + cop(g.m) + '</b></div>' +
        '<small>' + esc(gpFrTxt(g)) + (g.hr ? ' · ' + esc(g.hr) : '') + ' · ' + esc(wl(gpBil(g))) + '</small>' +
        (sg ? '<br><small>💡 Sueles pagar ≈ ' + cop(sg) + ' <button class="mini" onclick="gpUsar(\'' + g.id + '\',' + sg + ')">Actualizar</button></small>' : '') +
        (om >= 3 && !g.pa ? '<br><small>💡 Lo has omitido ' + om + ' veces seguidas. <button class="mini" onclick="gpPausa(\'' + g.id + '\')">Pausar</button></small>' : '') +
        '<div style="display:flex;gap:6px;margin-top:6px"><button class="btn out sm" onclick="gpForm(\'' + g.id + '\')">✏️ Editar</button><button class="btn out sm" onclick="gpPausa(\'' + g.id + '\')">' + (g.pa ? '▶️ Activar' : '⏸️ Pausar') + '</button><button class="btn out sm" onclick="ask(this,function(){gpDel(\'' + g.id + '\')},\'gasto programado\')">🗑️</button></div></div>'
    }).join('') : '<small>Aún no tienes gastos programados.</small>') +
    '<button class="btn out" onclick="gpForm()">➕ Programar gasto</button>' +
    (hay ? '<button class="btn out" onclick="gpImportar()">📥 Importar mis gastos de un día normal</button>' : '') + '</div>'
}
function gpForm(id) {
  var g = id ? gpById(id) : null, f = g ? (g.fr || { t: 'd' }) : { t: 'd' }, k = g ? g.k : 'p', ds = f.ds || [];
  GPED = id || null;
  openM('<h3>' + (g ? '✏️ Editar gasto programado' : '➕ Programar gasto') + '</h3>' +
    '<label>Nombre<input id="gpn" maxlength="40" value="' + esc(g ? g.n : '') + '" placeholder="Ej. Almuerzo"></label>' +
    '<div class="two"><label>Valor<input id="gpm" type="number" inputmode="numeric" min="0" value="' + (g ? g.m : '') + '"></label>' +
    '<label>Tipo<select id="gpk" onchange="gpCatFill()"><option value="p"' + (k === 'p' ? ' selected' : '') + '>👤 Personal</option><option value="o"' + (k === 'o' ? ' selected' : '') + '>🏍️ Operativo</option></select></label></div>' +
    '<label>Categoría<select id="gpc"></select></label><label>Billetera' + bilSel('gpb', g ? gpBil(g) : (BILX.indexOf('Efectivo') >= 0 ? 'Efectivo' : BIL[0])) + '</label>' +
    '<label>Frecuencia<select id="gpf" onchange="gpFrVer()"><option value="d"' + (f.t === 'd' ? ' selected' : '') + '>Todos los días</option><option value="s"' + (f.t === 's' ? ' selected' : '') + '>Días de la semana</option><option value="m"' + (f.t === 'm' ? ' selected' : '') + '>Un día del mes</option><option value="c"' + (f.t === 'c' ? ' selected' : '') + '>Cada cierto número de días</option></select></label>' +
    '<div id="gps" style="display:none"><div style="display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px">' + [1, 2, 3, 4, 5, 6, 0].map(function (d) { return '<label class="ck" style="margin:0"><input type="checkbox" class="gpd" value="' + d + '"' + (ds.indexOf(d) >= 0 ? ' checked' : '') + '> <span>' + GPDN[d] + '</span></label>' }).join('') + '</div></div>' +
    '<div id="gpmm" style="display:none"><label>Día del mes<input id="gpdm" type="number" min="1" max="31" value="' + (f.dm || '') + '"></label></div>' +
    '<div id="gpcc" style="display:none"><label>Cada cuántos días<input id="gpca" type="number" min="2" max="365" value="' + (f.ca || '') + '"></label></div>' +
    '<label>Hora aproximada (opcional)<input id="gph" type="time" value="' + esc(g ? g.hr || '' : '') + '"></label>' +
    '<div class="two"><button class="btn out" onclick="closeM()">Cancelar</button><button class="btn" onclick="gpSave()">Guardar</button></div>');
  gpCatFill(g ? g.cat : null); gpFrVer()
}
function gpCatFill(sel) {
  var t = $('#gpk').value === 'o' ? 'costo' : 'personal', c = $('#gpc');
  c.innerHTML = ppCats(t).map(function (x) { return '<option' + (x === sel ? ' selected' : '') + '>' + esc(x) + '</option>' }).join('')
}
function gpFrVer() { var t = $('#gpf').value; $('#gps').style.display = t === 's' ? 'block' : 'none'; $('#gpmm').style.display = t === 'm' ? 'block' : 'none'; $('#gpcc').style.display = t === 'c' ? 'block' : 'none' }
function gpSave() {
  var n = ($('#gpn').value || '').trim(), m = Math.round(parseFloat($('#gpm').value)), t = $('#gpf').value, fr = { t: t };
  if (!n) { toast('Escribe el nombre'); return } if (!(m > 0)) { toast('Escribe un valor mayor que 0'); return }
  if (t === 's') { fr.ds = [].slice.call(document.querySelectorAll('.gpd:checked')).map(function (x) { return +x.value }); if (!fr.ds.length) { toast('Elige al menos un día'); return } }
  if (t === 'm') { fr.dm = parseInt($('#gpdm').value, 10); if (!(fr.dm >= 1 && fr.dm <= 31)) { toast('Día del mes entre 1 y 31'); return } }
  if (t === 'c') { fr.ca = parseInt($('#gpca').value, 10); if (!(fr.ca >= 2)) { toast('Escribe cada cuántos días (2 o más)'); return } fr.ref = d0(Date.now()) }
  var rec = { n: n, m: m, k: $('#gpk').value === 'o' ? 'o' : 'p', cat: $('#gpc').value, bil: $('#gpb').value, fr: fr, hr: $('#gph').value || '' };
  if (!Array.isArray(S.gp)) S.gp = [];
  var g = GPED && S.gp.filter(function (x) { return x.id === GPED })[0];
  if (g) { if (g.fr && g.fr.t === 'c' && fr.t === 'c' && g.fr.ca === fr.ca) fr.ref = g.fr.ref || fr.ref; Object.assign(g, rec) } else { rec.id = uid(); rec.cr = Date.now(); rec.pa = false; S.gp.push(rec) }
  GPED = null; sv(); closeM(); render(); toast('✅ Gasto programado guardado')
}
function gpUsar(id, v) { var g = gpById(id); if (g) { g.m = v; sv(); render() } }
function gpPausa(id) { var g = gpById(id); if (g) { g.pa = !g.pa; sv(); render() } }
function gpDel(id) { S.gp = (S.gp || []).filter(function (g) { return g.id !== id }); S.gl = gpLog().filter(function (x) { return x.g !== id || x.mid }); sv(); render() }
function gpImportar() {
  var gd = (S.mdc && S.mdc.gd) || [], n = 0; if (!Array.isArray(S.gp)) S.gp = [];
  gd.forEach(function (x) { if (x && x.m > 0) { S.gp.push({ id: uid(), cr: Date.now(), n: String(x.n || 'Gasto'), m: Math.round(x.m), k: x.t === 'o' ? 'o' : 'p', cat: x.t === 'o' ? 'Otros' : 'Alimentación', bil: 'Efectivo', fr: { t: 'd' }, hr: '', pa: false }); n++ } });
  sv(); render(); toast('📥 Importados ' + n + ' gastos. Ponles hora y categoría en ✏️ Editar')
}
