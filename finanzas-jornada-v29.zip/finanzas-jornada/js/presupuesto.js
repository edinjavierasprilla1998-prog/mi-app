/* Finanzas + Jornada — presupuesto.js: Presupuesto mensual por categoría (Etapa 4).
   Datos: S.pp = límites {id,tipo:'costo'|'personal',cat,lim,ua}. Un límite por categoría; se repite cada mes.
   Lo gastado se calcula de los movimientos (S.mv) del mes elegido; nunca se guarda ni modifica nada de ellos.
   Las categorías son las de Movimientos: CO (costos operativos) y CP (gastos personales). */
var ppMes = m1(Date.now()), ppV = 'mes', ppSem = pstart('semana');
/* Vista: 'mes' (límites mensuales) o 'sem' (límites semanales, semana de lunes a domingo). Cada límite guarda p:'s' si es semanal. */
function ppIni() { return ppV === 'sem' ? ppSem : ppMes }
function ppPer(x) { return (x.p === 's') === (ppV === 'sem') }
function ppSetV(v) { ppV = v; render() }
function ppEt() { return ppV === 'sem' ? fd(ppSem) + ' – ' + fd(ppFin() - 86400000) : mname(ppMes) }
function ppLista() { return S.pp || [] }
function ppGet(tipo, cat) { return ppLista().filter(function (x) { return x.tipo === tipo && x.cat === cat && ppPer(x) })[0] }
/* Categorías: las fijas (CO/CP) + las que crea el usuario (S.cc = {id,tipo,nom,ua}). También aparecen en Movimientos. */
function ppCustom(tipo) { return (S.cc || []).filter(function (x) { return x.tipo === tipo }) }
function ppCats(tipo) { return (tipo === 'costo' ? CO : CP).concat(ppCustom(tipo).map(function (x) { return x.nom })) }
function ppEsCustom(tipo, cat) { return ppCustom(tipo).some(function (x) { return x.nom === cat }) }
function ppValido(b) { return (b.tipo === 'costo' || b.tipo === 'personal') && ppCats(b.tipo).indexOf(b.cat) >= 0 && b.lim > 0 }
function ppFin() {
  if (ppV === 'sem') { var w = new Date(ppSem); return new Date(w.getFullYear(), w.getMonth(), w.getDate() + 7).getTime() }
  var y = new Date(ppMes); return new Date(y.getFullYear(), y.getMonth() + 1, 1).getTime()
}
function ppGasto(tipo, cat) { return ppGastoR(tipo, cat, ppIni(), ppFin()) }
function ppGastoR(tipo, cat, a, b) {
  var s = 0;
  (S.mv || []).forEach(function (m) { if (m.tipo === tipo && (cat == null || m.cat === cat) && m.t >= a && m.t < b) s += m.v });
  /* Pase de 24 h (tipo 'recarga'), comisiones de las apps y comisión por viaje: costos operativos en «Comisión y pase de apps». */
  if (tipo === 'costo' && (cat == null || cat === 'Comisión y pase de apps')) {
    (S.am || []).forEach(function (m) { if (m.t >= a && m.t < b) { if (m.tipo === 'recarga' || m.tipo === 'comision') s += m.v; else if (m.tipo === 'retiro' && m.cr > 0) s += m.cr } });
    (S.j || []).forEach(function (j) { (j.ca || []).forEach(function (c) { if (c.t >= a && c.t < b) s += c.cm || 0 }) })
  }
  return s
}
/* Etapa 8: límites como % de los ingresos, proyección, comparación, detalle y alertas. */
function ppCur() { return ppIni() === (ppV === 'sem' ? pstart('semana') : m1(Date.now())) }
function ppPrevIni() { if (ppV === 'sem') { var w = new Date(ppSem); return new Date(w.getFullYear(), w.getMonth(), w.getDate() - 7).getTime() } var y = new Date(ppMes); return new Date(y.getFullYear(), y.getMonth() - 1, 1).getTime() }
function ppFrac() {
  var n = new Date(); if (ppV === 'sem') return Math.min(7, Math.floor((d0(Date.now()) - ppIni()) / 86400000) + 1) / 7;
  return n.getDate() / new Date(n.getFullYear(), n.getMonth() + 1, 0).getDate()
}
function ppLimR(b, a, e) { return b.pc > 0 ? Math.round(ppIngR(a, e).tot * b.pc / 100) : b.lim }
function ppLim(b) { return ppLimR(b, ppIni(), ppFin()) }
function ppApart(a, b) { var s = 0; (S.fm || []).forEach(function (m) { if (m.tipo === 'aporte' && m.t >= a && m.t < b) s += m.v }); return s }
function ppModo(v) { var a = $('#ppl_l'), b = $('#ppp_l'); if (a) a.style.display = v === 'p' ? 'none' : ''; if (b) b.style.display = v === 'p' ? '' : 'none' }
function ppDetalle(tipo, cat) {
  var a = ppIni(), b = ppFin(), L = [];
  (S.mv || []).forEach(function (m) { if (m.tipo === tipo && m.cat === cat && m.t >= a && m.t < b) L.push({ t: m.t, nm: m.nota || cat, det: m.bil ? wl(m.bil) : '', v: m.v }) });
  if (tipo === 'costo' && cat === 'Comisión y pase de apps') {
    (S.am || []).forEach(function (m) { if (m.t >= a && m.t < b && (m.tipo === 'recarga' || m.tipo === 'comision')) L.push({ t: m.t, nm: (m.tipo === 'recarga' ? '🎟️ Pase 24 h' : '➖ Comisión') + ' · ' + apNom(m.aid), det: m.nota || '', v: m.v }) });
    (S.am || []).forEach(function (m) { if (m.t >= a && m.t < b && m.tipo === 'retiro' && m.cr > 0) L.push({ t: m.t, nm: '💸 Comisión de retiro · ' + apNom(m.aid), det: m.nota || '', v: m.cr }) });
    var D = {}; (S.j || []).forEach(function (j) { (j.ca || []).forEach(function (c) { if (c.t >= a && c.t < b && c.cm) { var k = d0(c.t); D[k] = (D[k] || 0) + c.cm } }) });
    Object.keys(D).forEach(function (k) { L.push({ t: +k + 43200000, nm: '➖ Comisión de viajes del día', det: '', v: D[k] }) })
  }
  L.sort(function (x, y) { return y.t - x.t }); var tot = 0; L.forEach(function (x) { tot += x.v });
  openM('<h3>🔎 ' + esc(cat) + '</h3><p>' + ppEt() + ' · <b>' + cop(tot) + '</b> en ' + L.length + (L.length === 1 ? ' movimiento' : ' movimientos') + '</p>' +
    (L.length ? L.slice(0, 80).map(function (x) { return '<div class="li fh"><div class="wr" style="padding:0"><div class="g"><b>' + esc(x.nm) + '</b><br><small>' + fd(x.t) + ' ' + hm(x.t) + (x.det ? ' · ' + esc(x.det) : '') + '</small></div><b class="big">' + cop(x.v) + '</b></div></div>' }).join('') : '<div class="li"><small>No hay movimientos en este periodo.</small></div>') +
    '<button class="btn out" onclick="closeM()">Cerrar</button>')
}
/* Alertas al 80 % para el panel de avisos (usa el periodo actual de cada límite, sin importar la vista). */
function ppAvisos() {
  var A = [], n = new Date(), mA = m1(Date.now()), mB = new Date(n.getFullYear(), n.getMonth() + 1, 1).getTime(), sA = pstart('semana'), sB = sA + 7 * 86400000;
  (S.pp || []).forEach(function (b) {
    if (!ppValido(b)) return;
    var sem = b.p === 's', a = sem ? sA : mA, e = sem ? sB : mB, g = ppGastoR(b.tipo, b.cat, a, e), L = ppLimR(b, a, e);
    if (!(L > 0) || g / L < 0.8) return;
    A.push({ k: 'pp' + b.id + (sem ? 's' : 'm'), sev: 1, ic: g > L ? '⚠️' : '📊', tx: (g > L ? 'Te pasaste en “' : 'Vas al ' + Math.floor(g / L * 100) + ' % en “') + esc(b.cat) + '”', sub: cop(g) + ' de ' + cop(L) + (sem ? ' esta semana' : ' este mes'), t: Date.now(), go: ['fin', 'presupuesto', null, null] })
  });
  return A
}
function ppNav(n) {
  if (ppV === 'sem') { var w = new Date(ppSem); ppSem = new Date(w.getFullYear(), w.getMonth(), w.getDate() + 7 * n).getTime() }
  else { var y = new Date(ppMes); ppMes = new Date(y.getFullYear(), y.getMonth() + n, 1).getTime() }
  render()
}
function ppHoy() { ppMes = m1(Date.now()); ppSem = pstart('semana'); render() }
function ppBar(p) { return '<div class="pbar' + (p > 100 ? ' over' : p >= 80 ? ' warn' : '') + '"><i style="width:' + Math.min(100, Math.max(0, p)) + '%"></i></div>' }

function ppRow(tipo, cat) {
  var b = ppGet(tipo, cat), g = ppGasto(tipo, cat), on = 'ppForm(\'' + tipo + '\',\'' + cat + '\')', sm = ppV === 'sem',
    det = '<button class="mini" aria-label="Ver movimientos" onclick="event.stopPropagation();ppDetalle(\'' + tipo + '\',\'' + cat + '\')">🔎</button>',
    ant = ppGastoR(tipo, cat, ppPrevIni(), ppIni()), cmp = ant > 0 && g > 0 ? (g > ant ? '▲ ' : g < ant ? '▼ ' : '= ') + Math.round(Math.abs(g - ant) / ant * 100) + ' % vs ' + (sm ? 'semana' : 'mes') + ' anterior' : '';
  if (!b) return '<div class="li tap" onclick="' + on + '"><div class="g"><b>' + esc(cat) + '</b><br><small>Sin límite' + (g ? ' · gastado ' + cop(g) : '') + (cmp ? ' · ' + cmp : '') + '</small></div>' + det + '<span class="chip">➕ Límite</span></div>';
  var L = ppLim(b), p = L > 0 ? g / L * 100 : (g > 0 ? 100 : 0), r = L - g, ex = L > 0 && r < 0, fr = ppCur() ? ppFrac() : 1, proy = g > 0 && fr > 0 && fr < 1 ? g / fr : 0;
  return '<div class="li tap fc" onclick="' + on + '"><div class="row"><b>' + esc(cat) + (b.pc > 0 ? ' <small>' + b.pc + ' %</small>' : '') + '</b><span>' + det + ' <b class="big ' + (ex ? 'neg' : '') + '">' + (L <= 0 ? 'Sin ingresos aún' : ex ? 'Excedido ' + cop(-r) : 'Quedan ' + cop(r)) + '</b></span></div>' + ppBar(p) +
    '<div class="row"><small>' + cop(g) + ' de ' + cop(L) + '</small><small>' + (p >= 100 ? Math.round(p) : Math.floor(p)) + '%' + (ex ? ' ⚠️' : p >= 80 ? ' ⚠️' : '') + '</small></div>' +
    (proy && L > 0 && g <= L ? '<small style="display:block;margin-top:2px">' + (proy > L ? '⚠️ A este ritmo cerrarás en ' + cop(proy) + ' (' + cop(proy - L) + ' sobre tu límite)' : '📈 A este ritmo cerrarás en ' + cop(proy)) + '</small>' : '') +
    (cmp ? '<small style="display:block;margin-top:2px">' + cmp + '</small>' : '') + '</div>'
}
function vPresup() {
  var cur = ppIni() === (ppV === 'sem' ? pstart('semana') : m1(Date.now())), pres = 0, gas = 0, y = new Date(ppMes), sm = ppV === 'sem';
  ppLista().filter(function (b) { return ppValido(b) && ppPer(b) }).forEach(function (b) { pres += ppLim(b); gas += ppGasto(b.tipo, b.cat) });
  var tot = ppGasto('costo') + ppGasto('personal'), sin = Math.max(0, tot - gas), rest = pres - gas;
  var h = '<div class="seg"><button class="' + (sm ? '' : 'on') + '" onclick="ppSetV(\'mes\')">Mensual</button><button class="' + (sm ? 'on' : '') + '" onclick="ppSetV(\'sem\')">Semanal</button></div>' +
    '<div class="pb"><button class="cb" aria-label="Anterior" onclick="ppNav(-1)">◀</button><b>' + ppEt() + '</b><button class="cb" aria-label="Siguiente" onclick="ppNav(1)">▶</button></div>';
  if (!cur) h += '<button class="btn out sm" onclick="ppHoy()">📅 Ir a esta ' + (sm ? 'semana' : 'mes') + '</button>';
  h += '<div class="hero"><small>📊 ' + (rest < 0 ? 'Te pasaste del presupuesto' : 'Te queda del presupuesto') + '</small><b>' + cop(Math.abs(rest)) + '</b><div class="sub"><span>🎯 Presupuestado<br><b>' + cop(pres) + '</b></span><span>💸 Gastado<br><b>' + cop(gas) + '</b></span></div></div>';
  if (pres > 0) {
    var p = gas / pres * 100;
    h += '<div class="card" style="padding:12px 16px">' + ppBar(p) + '<div class="row"><small>' + (p >= 100 ? Math.round(p) : Math.floor(p)) + '% usado</small><small>' + (rest < 0 ? '⚠️ Excedido' : 'Disponible ' + cop(rest)) + '</small></div></div>';
    if (cur && rest > 0) {
      var dias = sm ? 7 - ((new Date().getDay() + 6) % 7) : new Date(y.getFullYear(), y.getMonth() + 1, 0).getDate() - new Date().getDate() + 1;
      if (dias > 0) h += '<div class="card" style="margin-top:8px">' + kv('📅 Días que faltan (con hoy)', dias) + kv('💵 Puedes gastar por día', cop(rest / dias)) + '</div>'
    }
  } else h += '<div class="li"><small>Aún no hay límites. Toca una categoría y ponle un límite ' + (sm ? 'semanal' : 'mensual') + '.</small></div>';
  if (sin > 0) h += '<div class="li" style="margin-top:8px"><small>Gastos en categorías sin límite ' + (sm ? 'esta semana' : 'este mes') + ': <b>' + cop(sin) + '</b></small></div>';
  h += ppIngHTML() + '<h2>🏍️ Costos operativos</h2>' + ppCats('costo').map(function (c) { return ppRow('costo', c) }).join('') +
    '<button class="btn out sm" onclick="ppCatForm(\'costo\')">➕ Nueva categoría</button>' +
    '<h2>👤 Gastos personales</h2>' + ppCats('personal').map(function (c) { return ppRow('personal', c) }).join('') +
    '<button class="btn out sm" onclick="ppCatForm(\'personal\')">➕ Nueva categoría</button>' +
    '<small style="display:block;margin:8px 4px">Los límites ' + (sm ? 'semanales se repiten cada semana' : 'mensuales se repiten cada mes') + '. Solo cuentan costos operativos y gastos personales registrados en Movimientos.</small>';
  return h
}

/* ---------- poner / cambiar / quitar límite ---------- */
function ppForm(tipo, cat) {
  if (ppCats(tipo).indexOf(cat) < 0) return;
  var b = ppGet(tipo, cat), g = ppGasto(tipo, cat), pc = b && b.pc > 0, pl = ppV === 'sem' ? 'semanal' : 'mensual';
  openM('<h3>' + (tipo === 'costo' ? '🏍️' : '👤') + ' ' + esc(cat) + '</h3><p>Límite ' + pl + ' para esta categoría. Se repite cada ' + (ppV === 'sem' ? 'semana' : 'mes') + '.' + (g ? ' ' + (ppV === 'sem' ? 'Esta semana' : 'Este mes') + ' llevas ' + cop(g) + '.' : '') + '</p>' +
    '<label>Tipo de límite<select id="ppm" onchange="ppModo(this.value)"><option value="m"' + (pc ? '' : ' selected') + '>Monto fijo</option><option value="p"' + (pc ? ' selected' : '') + '>% de mis ingresos</option></select></label>' +
    '<label id="ppl_l">Límite ' + pl + '<input id="ppl" type="number" inputmode="numeric" min="0" value="' + (b && !pc ? b.lim : '') + '" placeholder="Ej. 300000"></label>' +
    '<label id="ppp_l" style="display:none">% de tus ingresos ' + (ppV === 'sem' ? 'de la semana' : 'del mes') + '<input id="ppp" type="number" inputmode="decimal" min="0" max="100" step="0.5" value="' + (pc ? b.pc : '') + '" placeholder="Ej. 15"></label>' +
    (b ? '<button class="btn out sm" onclick="ppDel(\'' + tipo + '\',\'' + cat + '\')">🗑️ Quitar límite</button>' : '') +
    (ppEsCustom(tipo, cat) ? '<button class="btn bad sm" onclick="ppCatAsk(\'' + tipo + '\',\'' + cat + '\')">🗑️ Eliminar categoría</button>' : '') + btns("ppSave('" + tipo + "','" + cat + "')"));
  ppModo(pc ? 'p' : 'm')
}
function ppSave(tipo, cat) {
  var modo = $('#ppm').value, v = modo === 'p' ? num('#ppp') : num('#ppl'), lim;
  if (!(v > 0)) { toast(modo === 'p' ? 'Escribe un porcentaje mayor que 0' : 'Escribe un límite mayor que 0'); return }
  if (modo === 'p' && v > 100) { toast('El porcentaje no puede pasar de 100'); return }
  if (ppCats(tipo).indexOf(cat) < 0) { closeM(); return }
  lim = modo === 'p' ? Math.max(1, Math.round(ppIng().tot * v / 100)) : v;
  if (!Array.isArray(S.pp)) S.pp = [];
  var b = ppGet(tipo, cat), n = Date.now();
  if (b) { b.lim = lim; b.ua = n; if (modo === 'p') b.pc = v; else delete b.pc }
  else { b = { id: uid(), tipo: tipo, cat: cat, lim: lim, p: ppV === 'sem' ? 's' : 'm', ua: n }; if (modo === 'p') b.pc = v; S.pp.push(b) }
  sv(); closeM(); render(); toast('✅ Límite guardado')
}
function ppDel(tipo, cat) {
  S.pp = (S.pp || []).filter(function (x) { return !(x.tipo === tipo && x.cat === cat && ppPer(x)) });
  sv(); closeM(); render(); toast('🗑️ Límite quitado')
}

/* ---------- categorías propias ---------- */
function ppCatForm(tipo) {
  openM('<h3>' + (tipo === 'costo' ? '🏍️ Nueva categoría de costos' : '👤 Nueva categoría de gastos personales') + '</h3><p>Aparecerá también al registrar movimientos.</p>' +
    '<label>Nombre<input id="pcn" maxlength="30" placeholder="Ej. Lavada de moto"></label>' +
    '<label>Límite ' + (ppV === 'sem' ? 'semanal' : 'mensual') + ' (opcional)<input id="pcl" type="number" inputmode="numeric" min="0" placeholder="Ej. 50000"></label>' + btns("ppCatSave('" + tipo + "')"))
}
function ppCatSave(tipo) {
  var nom = $('#pcn').value.trim().replace(/\s+/g, ' '), rl = $('#pcl').value, lim = rl === '' ? null : num('#pcl');
  if (!nom) { toast('Escribe un nombre'); return }
  if (/['"<>&\\`]/.test(nom)) { toast('El nombre no puede tener comillas ni los símbolos < > & \\'); return }
  if (rl !== '' && !(lim > 0)) { toast('El límite debe ser mayor que 0, o déjalo vacío'); return }
  if (ppCats(tipo).some(function (x) { return x.toLowerCase() === nom.toLowerCase() })) { toast('Ya existe esa categoría'); return }
  if (!Array.isArray(S.cc)) S.cc = [];
  if (!Array.isArray(S.pp)) S.pp = [];
  var n = Date.now();
  S.cc.push({ id: uid(), tipo: tipo, nom: nom, ua: n });
  if (lim) S.pp.push({ id: uid(), tipo: tipo, cat: nom, lim: lim, p: ppV === 'sem' ? 's' : 'm', ua: n });
  sv(); closeM(); render(); toast('✅ Categoría creada')
}
function ppCatAsk(tipo, cat) {
  openM('<h3>¿Eliminar “' + esc(cat) + '”?</h3><p>Se quita la categoría y su límite. Los movimientos que ya la usan no se borran ni cambian; solo dejarán de contar en el presupuesto.</p>' +
    '<div class="two"><button class="btn out" onclick="closeM()">Cancelar</button><button class="btn bad" onclick="ppCatDel(\'' + tipo + '\',\'' + cat + '\')">Eliminar</button></div>')
}
function ppCatDel(tipo, cat) {
  S.cc = (S.cc || []).filter(function (x) { return !(x.tipo === tipo && x.nom === cat) });
  S.pp = (S.pp || []).filter(function (x) { return !(x.tipo === tipo && x.cat === cat) });
  sv(); closeM(); render(); toast('🗑️ Categoría eliminada')
}

/* ---------- ingresos del mes (Etapa 7) ---------- */
/* Ingresos del mes elegido: viajes (por app), premios de las apps, ingresos de Movimientos y cobros de Por cobrar. */
function ppIng() { return ppIngR(ppIni(), ppFin()) }
function ppIngR(a, b) {
  var r = { tot: 0, apps: {}, otros: 0 };
  function add(k, v) { r.apps[k] = (r.apps[k] || 0) + v; r.tot += v }
  (S.j || []).forEach(function (j) { (j.ca || []).forEach(function (c) { if (c.t >= a && c.t < b) add(c.ap && apById(c.ap) ? c.ap : '_', c.v + c.p) }) });
  (S.am || []).forEach(function (m) { if (m.tipo === 'premio' && m.t >= a && m.t < b) add(apById(m.aid) ? m.aid : '_', m.v) });
  (S.mv || []).forEach(function (m) { if (m.tipo === 'ingreso' && m.t >= a && m.t < b) { r.otros += m.v; r.tot += m.v } });
  (S.xm || []).forEach(function (m) { if (m.tipo === 'cobro' && m.t >= a && m.t < b) { r.otros += m.v; r.tot += m.v } });
  return r
}
function ppIngHTML() {
  var g = ppIng(), meta = ppMetaV(), costos = ppGasto('costo'), pers = ppGasto('personal'), neto = g.tot - costos - pers,
    apps = Object.keys(g.apps).filter(function (k) { return k !== '_' }).sort(function (x, y) { return g.apps[y] - g.apps[x] });
  var h = '<h2>💰 Ingresos ' + (ppV === 'sem' ? 'de la semana' : 'del mes') + '</h2><div class="card">' + kv('Total ingresos', cop(g.tot), 'pos') +
    apps.map(function (k) { return kv('· ' + esc(apNom(k)), cop(g.apps[k])) }).join('') +
    (g.apps._ ? kv('· Viajes sin app', cop(g.apps._)) : '') + (g.otros ? kv('· Otros ingresos y cobros', cop(g.otros)) : '') +
    kv('Costos operativos', '−' + cop(costos)) + kv('Gastos personales', '−' + cop(pers)) + kv(ppV === 'sem' ? 'Neto de la semana' : 'Neto del mes', cop(neto), neto < 0 ? 'neg' : 'pos') +
    kv('📌 Apartado a fondos', '−' + cop(ppApart(ppIni(), ppFin()))) + kv('Libre después de apartar', cop(neto - ppApart(ppIni(), ppFin())), neto - ppApart(ppIni(), ppFin()) < 0 ? 'neg' : 'pos') + '</div>';
  if (meta > 0) {
    var p = g.tot / meta * 100;
    h += '<div class="card" style="padding:12px 16px;margin-top:8px"><div class="row"><b>🎯 Meta ' + (ppV === 'sem' ? 'semanal' : 'mensual') + '</b><small>' + cop(meta) + '</small></div><div class="pbar ok"><i style="width:' + Math.min(100, Math.max(0, p)) + '%"></i></div><div class="row"><small>' + Math.floor(p) + '% de la meta</small><small>' + (g.tot >= meta ? '🎉 Meta cumplida' : 'Faltan ' + cop(meta - g.tot)) + '</small></div></div>'
  }
  return h + '<button class="btn out sm" style="margin-top:8px" onclick="ppMeta()">🎯 ' + (meta > 0 ? 'Cambiar' : 'Poner') + ' meta de ingresos</button>'
}
function ppMetaV() { var v = ppV === 'sem' ? S.metaS : S.meta; return v > 0 ? v : 0 }
function ppMeta() {
  var sm = ppV === 'sem';
  openM('<h3>🎯 Meta de ingresos ' + (sm ? 'de la semana' : 'del mes') + '</h3><p>Se repite cada ' + (sm ? 'semana' : 'mes') + '. Déjala vacía para quitarla.</p><label>Meta ' + (sm ? 'semanal' : 'mensual') + '<input id="pmt" type="number" inputmode="numeric" min="0" value="' + (ppMetaV() || '') + '" placeholder="Ej. 3000000"></label>' + btns('ppMetaOk()'))
}
function ppMetaOk() {
  var r = $('#pmt').value, v = r === '' ? 0 : num('#pmt');
  if (v === null || v < 0) { toast('Revisa la meta'); return }
  if (ppV === 'sem') S.metaS = v > 0 ? v : null; else S.meta = v > 0 ? v : null; sv(); closeM(); render(); toast(v > 0 ? '✅ Meta guardada' : 'Meta quitada')
}
