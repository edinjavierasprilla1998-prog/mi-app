/* Finanzas + Jornada — avisos.js: Recordatorios y seguimiento (Etapa 6).
   Todo se calcula en el celular (sin servidor). Tres capas:
   1) Panel «Pendientes» en Inicio + contador en Finanzas (siempre fiable).
   2) Notificación del celular al abrir la app / mientras está abierta (S.nt evita repetir el mismo aviso el mismo día).
   3) Periodic Background Sync (si Android lo permite, sin garantía de hora) leyendo una copia de los avisos en IndexedDB 'fj-avisos'.
   Además: «Agregar al calendario» (.ics) para alarmas exactas. Config en S.av = {on,dias}. */
var avLast = [];
function avCfg() { var c = S.av || {}; return { on: c.on !== false, dias: c.dias > 0 ? c.dias : 3, dot: c.dot !== false, hora: (c.hora != null && c.hora >= 0 && c.hora <= 23) ? +c.hora : 8, tipos: c.tipos || {} } }
function avTipo(k) { return avCfg().tipos[k] !== false }
function avDia(n) { return n === 1 ? '1 día' : n + ' días' }
function avItems() {
  var n = Date.now(), hoy = d0(n), cfg = avCfg(), A = [], H = cfg.hora * 3600000, DIA = 86400000;
  [['deudas', 'Pagar', '🤝'], ['prestamos', 'Cobrar a', '💵'], ['cobros', 'Cobrar', '⏳']].forEach(function (x) {
    if (!avTipo(x[0])) return;
    var c = CU[x[0]];
    cuLst(c).forEach(function (f) {
      if (f.arch || !f.fv) return;
      var s = cuSaldo(c, f.id); if (s < 0.005) return;
      var lim = f.rd > 0 ? f.rd : cfg.dias;
      var d = Math.round((d0(f.fv) - hoy) / DIA), tx = x[1] + ' “' + esc(f.nom) + '” · ' + cop(s);
      if (d < 0) A.push({ k: x[0] + f.id, sev: 0, ic: '⚠️', tx: tx, sub: 'Vencida hace ' + avDia(-d), t: n, go: ['fin', x[0], 'cdet', f.id] });
      else if (d === 0) A.push({ k: x[0] + f.id, sev: 0, ic: x[2], tx: tx, sub: 'Vence hoy', t: d0(f.fv) + H, go: ['fin', x[0], 'cdet', f.id] });
      else if (d <= lim) A.push({ k: x[0] + f.id, sev: 1, ic: x[2], tx: tx, sub: d === 1 ? 'Vence mañana' : 'Vence en ' + avDia(d), t: d0(f.fv) - DIA + H, go: ['fin', x[0], 'cdet', f.id] })
    })
  });
  if (avTipo('fondos')) (S.fo || []).forEach(function (f) {
    if (f.arch || f.pz || !(f.fr > 0)) return;
    var u = f.ca || 0; fMovs(f.id).forEach(function (m) { if (m.tipo === 'aporte' && m.t > u) u = m.t });
    var d = Math.floor((n - u) / DIA);
    if (d >= f.fr) A.push({ k: 'fo' + f.id, sev: 1, ic: '💰', tx: 'Fondo “' + esc(f.nom) + '”: toca aportar', sub: 'Hace ' + avDia(d) + ' sin aportes', t: n, go: ['fin', 'fondos', 'fdet', f.id] })
  });
  if (avTipo('fijos')) (S.fo || []).forEach(function (f) {
    if (f.tp !== 'fijo' || f.arch || f.pz || !f.pv) return;
    var d = Math.round((d0(f.pv) - hoy) / DIA), s = fSaldo(f.id), falta = Math.max(0, (f.mo || 0) - s), lim = f.rd > 0 ? f.rd : cfg.dias,
      tx = (f.ic || '📌') + ' “' + esc(f.nom) + '” · ' + (falta > 0.5 ? 'faltan ' + cop(falta) : 'listo para pagar');
    if (d < 0) A.push({ k: 'fx' + f.id, sev: 0, ic: '⚠️', tx: tx, sub: 'Pago vencido hace ' + avDia(-d), t: n, go: ['fin', 'fondos', 'fdet', f.id] });
    else if (d <= lim) A.push({ k: 'fx' + f.id, sev: d === 0 ? 0 : 1, ic: '📌', tx: tx, sub: d === 0 ? 'Se paga hoy' : d === 1 ? 'Se paga mañana' : 'Se paga en ' + avDia(d), t: d0(f.pv) - d * DIA + H, go: ['fin', 'fondos', 'fdet', f.id] })
  });
  if (avTipo('retiros')) (S.am || []).forEach(function (m) {
    if (m.tipo === 'retiro' && m.est === 'camino' && n - m.t > 2 * DIA) A.push({ k: 'ret' + m.id, sev: 1, ic: '🚚', tx: 'Retiro de ' + esc(apNom(m.aid)) + ' · ' + cop(m.v), sub: 'En camino hace ' + avDia(Math.floor((n - m.t) / DIA)), t: n, go: ['fin', 'apps', 'adet', m.aid] })
  });
  if (avTipo('pase')) apList().forEach(function (a) {
    var p = apPaseAct(a.id); if (!p) return;
    var r = p.t + DIA - n;
    if (r < 2 * 3600000) A.push({ k: 'pase' + p.id, sev: 2, ic: '🎟️', tx: 'Pase de ' + esc(a.nom) + ' por vencer', sub: 'Vence a las ' + hm(p.t + DIA), t: n, go: ['fin', 'apps', 'adet', a.id] })
  });
  if (avTipo('promos') && typeof pxAvisos === 'function') pxAvisos().forEach(function (x) { A.push(x) });
  if (avTipo('jornada') && typeof jAvisos === 'function') jAvisos().forEach(function (x) { A.push(x) });
  if (avTipo('cc') && typeof ccAvisos === 'function') ccAvisos().forEach(function (x) { A.push(x) });
  if (avTipo('gp') && typeof gpAvisos === 'function') gpAvisos().forEach(function (x) { A.push(x) });
  if (avTipo('copia') && typeof bkAvisos === 'function') bkAvisos().forEach(function (x) { A.push(x) });
  if (avTipo('presupuesto') && typeof ppAvisos === 'function') ppAvisos().forEach(function (x) { A.push(x) });
  if (typeof apHoyItem === 'function') { var ah = apHoyItem(); if (ah) A.push(ah) }
  return A.sort(function (a, b) { return a.sev - b.sev || a.t - b.t })
}
function avN() { return avItems().filter(function (x) { return x.sev <= 1 }).length }
function avIr(i) {
  var x = avLast[i]; if (!x) return;
  tab = x.go[0]; fsub = x.go[1]; fdet = null; cdet = null; adet = null;
  if (x.go[2] === 'cdet') cdet = x.go[3]; else if (x.go[2] === 'fdet') fdet = x.go[3]; else if (x.go[2] === 'adet') adet = x.go[3];
  render(); window.scrollTo(0, 0)
}
function avPanel() {
  avLast = avItems(); if (!avLast.length) return '';
  return '<h2>🔔 Pendientes (' + avLast.length + ')</h2><div class="card av">' + avLast.slice(0, 6).map(function (x, i) {
    return '<div class="avr sev' + x.sev + ' tap" onclick="avIr(' + i + ')"><span class="avi">' + x.ic + '</span><div class="g"><b>' + x.tx + '</b><br><small>' + x.sub + '</small></div><span class="chev">›</span></div>'
  }).join('') + (avLast.length > 6 ? '<small style="display:block;padding:6px 4px">y ' + (avLast.length - 6) + ' más en Finanzas</small>' : '') + '</div>'
}
/* Resumen de deudas / préstamos / por cobrar para Inicio. */
function cuInicio() {
  var t = {}, h = '';
  ['deudas', 'prestamos', 'cobros'].forEach(function (k) { var c = CU[k], s = 0; cuLst(c).forEach(function (f) { if (!f.arch) s += Math.max(0, cuSaldo(c, f.id)) }); t[k] = s });
  if (!t.deudas && !t.prestamos && !t.cobros) return '';
  return '<h2>🧾 Deudas y cobros</h2><div class="card">' + (t.deudas ? kv('🤝 Debes', cop(t.deudas), 'neg') : '') + (t.prestamos ? kv('💵 Te deben (préstamos)', cop(t.prestamos)) : '') + (t.cobros ? kv('⏳ Por cobrar', cop(t.cobros)) : '') + '</div>'
}

/* ---------- calendario (.ics) ---------- */
function avIcsTxt(titulo, fv, desc) {
  var d = new Date(fv), p = function (x) { return String(x).padStart(2, '0') }, f = d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()),
    e = new Date(fv + 86400000), fe = e.getFullYear() + p(e.getMonth() + 1) + p(e.getDate()), u = 'fj-' + fv + '-' + Math.random().toString(36).slice(2, 8) + '@finanzas-jornada';
  function L(s) { return String(s).replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n') }
  return ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Finanzas Jornada//ES', 'BEGIN:VEVENT', 'UID:' + u, 'DTSTAMP:' + new Date().toISOString().replace(/[-:]/g, '').slice(0, 15) + 'Z', 'DTSTART;VALUE=DATE:' + f, 'DTEND;VALUE=DATE:' + fe,
    'SUMMARY:' + L(titulo), 'DESCRIPTION:' + L(desc || ''), 'BEGIN:VALARM', 'ACTION:DISPLAY', 'DESCRIPTION:' + L(titulo), 'TRIGGER:-PT15H', 'END:VALARM', 'BEGIN:VALARM', 'ACTION:DISPLAY', 'DESCRIPTION:' + L(titulo), 'TRIGGER:PT8H', 'END:VALARM', 'END:VEVENT', 'END:VCALENDAR'].join('\r\n')
}
function avBajar(nombre, texto) {
  var b = new Blob([texto], { type: 'text/calendar' }), u = URL.createObjectURL(b), a = document.createElement('a');
  a.href = u; a.download = nombre; a.style.display = 'none'; document.body.appendChild(a); a.click();
  setTimeout(function () { document.body.removeChild(a); URL.revokeObjectURL(u) }, 4000)
}
function avIcsCu(k, id) {
  var c = CU[k], f = cuById(c, id); if (!f || !f.fv) { toast('Ponle una fecha límite primero'); return }
  var t = ({ deudas: 'Pagar deuda: ', prestamos: 'Cobrar préstamo: ', cobros: 'Cobrar: ' })[k] + f.nom;
  avBajar('recordatorio-' + iso(f.fv) + '.ics', avIcsTxt(t, f.fv, 'Saldo pendiente: ' + cop(cuSaldo(c, id)) + '. Registrado en Finanzas + Jornada.'));
  toast('📅 Abre el archivo para agregarlo a tu calendario')
}

/* ---------- notificaciones ---------- */
function avPerm() { return ('Notification' in window) ? Notification.permission : 'no' }
function avMostrar(x) {
  var o = { body: x.sub, tag: x.k, icon: 'icons/icon-192.png', badge: 'icons/favicon-32.png' };
  if ('serviceWorker' in navigator) navigator.serviceWorker.ready.then(function (r) { r.showNotification(x.ic + ' ' + x.tx, o) }).catch(function () { try { new Notification(x.tx, o) } catch (e) { } });
  else try { new Notification(x.tx, o) } catch (e) { }
}
function avNotificar() {
  var cfg = avCfg(); if (!cfg.on || avPerm() !== 'granted') return;
  var hoy = dk(Date.now()), nt = S.nt || {}, nuevo = false;
  /* No se muestran notificaciones antes de la hora elegida; el panel «Pendientes» sí está siempre. */
  /* Los avisos de registro de promociones llevan su propia hora (x.hr); el resto espera a la hora general. */
  avItems().filter(function (x) { return x.sev <= 1 }).forEach(function (x) { if (x.hr == null && new Date().getHours() < cfg.hora) return; if (nt[x.k] !== hoy) { avMostrar(x); nt[x.k] = hoy; nuevo = true } });
  if (nuevo) { S.nt = nt; sv() }
  avIDB()
}
/* Copia de los avisos para el Service Worker (Periodic Background Sync). */
function avIDB() {
  try {
    var hoy = dk(Date.now()), l = avItems().filter(function (x) { return x.sev <= 1 }).map(function (x) { return { k: x.k + '|' + hoy, t: x.t, title: x.ic + ' ' + x.tx, body: x.sub } });
    var r = indexedDB.open('fj-avisos', 1);
    r.onupgradeneeded = function () { r.result.createObjectStore('a') };
    r.onsuccess = function () { try { var tx = r.result.transaction('a', 'readwrite'); tx.objectStore('a').put(l, 'items'); tx.oncomplete = function () { r.result.close() } } catch (e) { } }
  } catch (e) { }
}
function avPermiso() {
  if (!('Notification' in window)) { toast('Este navegador no permite notificaciones'); return }
  Notification.requestPermission().then(function (p) {
    if (p === 'granted') {
      S.av = Object.assign({}, S.av, { on: true }); sv();
      try { navigator.serviceWorker.ready.then(function (r) { if (r.periodicSync) r.periodicSync.register('fj-avisos', { minInterval: 12 * 3600000 }).catch(function () { }) }) } catch (e) { }
      avNotificar(); toast('🔔 Notificaciones activadas')
    } else toast('No se dieron permisos de notificación');
    render()
  })
}
function avSet(on) { S.av = Object.assign({}, S.av, { on: !!on }); sv(); render() }
function avDias(n) { S.av = Object.assign({}, S.av, { dias: +n }); sv(); render() }
function avDot(on) { S.av = Object.assign({}, S.av, { dot: !!on }); sv(); render() }
function avHora(h) { S.av = Object.assign({}, S.av, { hora: +h }); sv(); render(); avIDB() }
function avTipoSet(k, on) { var t = Object.assign({}, (S.av || {}).tipos); t[k] = !!on; S.av = Object.assign({}, S.av, { tipos: t }); sv(); render() }
function avCfgHTML() {
  var c = avCfg(), p = avPerm(), dl = [1, 2, 3, 5, 7, 10, 15], hs = [];
  if (dl.indexOf(c.dias) < 0) { dl.push(c.dias); dl.sort(function (a, b) { return a - b }) }
  for (var i = 5; i <= 22; i++) hs.push(i);
  var T = [['deudas', '🤝 Deudas'], ['prestamos', '💵 Préstamos'], ['cobros', '⏳ Por cobrar'], ['fijos', '📌 Gastos fijos (fondos)'], ['fondos', '💰 Aportar a fondos'], ['presupuesto', '📊 Presupuesto al 80 %'], ['promos', '🎯 Promociones e incentivos'], ['jornada', '🏍️ Meta de la jornada y pausas'], ['gp', '🧾 Gastos programados por confirmar'], ['cc', '✂️ Cortes de saldos'], ['copia', '☁️ Copia de seguridad'], ['retiros', '🚚 Retiros en camino'], ['pase', '🎟️ Pase por vencer']];
  return '<h2>🔔 Avisos y recordatorios</h2><div class="card form"><label class="ck"><input type="checkbox" ' + (c.on ? 'checked' : '') + ' onchange="avSet(this.checked)"> <span>Mostrar pendientes y avisos</span></label>' +
    '<label class="ck"><input type="checkbox" ' + (c.dot ? 'checked' : '') + ' onchange="avDot(this.checked)"> <span>Punto rojo en el menú de Finanzas</span></label>' +
    '<label>Avisar con anticipación<select onchange="avDias(this.value)">' + dl.map(function (n) { return '<option value="' + n + '"' + (c.dias === n ? ' selected' : '') + '>' + avDia(n) + '</option>' }).join('') + '</select></label>' +
    '<label>Hora del aviso<select onchange="avHora(this.value)">' + hs.map(function (h) { return '<option value="' + h + '"' + (c.hora === h ? ' selected' : '') + '>' + (h % 12 || 12) + ':00 ' + (h < 12 ? 'a. m.' : 'p. m.') + '</option>' }).join('') + '</select></label>' +
    '<small style="display:block;margin:-4px 0 10px">Cada deuda, préstamo o gasto fijo puede tener su propio aviso al editarlo. Si no lo tiene, usa estos días.</small>' +
    '<b style="font-size:13px">Qué quieres que te avise</b><div style="height:6px"></div>' +
    T.map(function (x) { return '<label class="ck"><input type="checkbox" ' + (avTipo(x[0]) ? 'checked' : '') + ' onchange="avTipoSet(\'' + x[0] + '\',this.checked)"> <span>' + x[1] + '</span></label>' }).join('') +
    '<div style="height:8px"></div>' +
    (p === 'granted' ? '<small>✅ Notificaciones del celular activadas. Te aviso al abrir la app (desde la hora elegida) y, si Android lo permite, también en segundo plano (la hora no es exacta). Para una alarma exacta usa “Agregar al calendario” en cada deuda o cobro.</small>' :
      p === 'denied' ? '<small>Las notificaciones están bloqueadas en el navegador. Actívalas en los permisos del sitio.</small>' :
        '<button class="btn out" onclick="avPermiso()">🔔 Activar notificaciones del celular</button><div style="height:8px"></div><small>Sin permiso igual verás el panel “Pendientes” en Inicio.</small>') + '</div>' +
    '<h2>⏸️ Categorías de pausa</h2><div class="card form"><div class="two"><button class="btn out" onclick="paForm()">➕ Nueva categoría</button><button class="btn out" onclick="paGest()">✏️ Gestionar</button></div></div>' + (typeof pxCfgHTML === 'function' ? pxCfgHTML() : '') + (typeof jcCfgHTML === 'function' ? jcCfgHTML() : '')
}
function avInit() { avNotificar(); setInterval(avNotificar, 15 * 60000); document.addEventListener('visibilitychange', function () { if (!document.hidden) avNotificar() }) }
