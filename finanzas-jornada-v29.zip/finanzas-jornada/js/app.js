/* Finanzas + Jornada — app.js: render, navegación, arranque y service worker. Separado de index.html en la Etapa 1, sin cambios de lógica. */
function render(){
bilRefresh();
document.documentElement.setAttribute('data-theme',S.tema==='claro'?'light':S.tema==='oscuro'?'dark':'');
var V={inicio:vInicio,jornada:vJornada,mov:vMov,hist:vHist,fin:vFin,cfg:vCfg};$('#app').innerHTML=V[tab]();icoPass();lblPass();if(tab==='mov'){fillC();fillEdit()}
var N=[['inicio','home','Inicio'],['jornada','moto','Jornada'],['mov','swap','Movimientos'],['hist','history','Historial'],['fin','wallet','Finanzas'],['cfg','gear','Ajustes']],bn_=avCfg().on?avN():0;
$('#nav').innerHTML=N.map(function(n){return '<button class="'+(tab===n[0]?'on':'')+'" onclick="go(\''+n[0]+'\')"><span>'+ico(n[1],23)+(n[0]==='fin'&&bn_&&avCfg().dot?'<i class="bd" role="img" aria-label="'+bn_+(bn_===1?' pendiente':' pendientes')+'"></i>':'')+'</span>'+n[2]+'</button>'}).join('')}
setInterval(function(){var j=act(),l=$('#live');if(tab==='jornada'&&j&&l)l.innerHTML=live(j)},1000);
render();
fjArranque(r0);
avInit();
if('serviceWorker' in navigator){window.addEventListener('load',function(){navigator.serviceWorker.register('service-worker.js').catch(function(){})})}

