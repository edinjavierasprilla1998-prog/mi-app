/* Finanzas + Jornada — ETAPA 0: seguridad y respaldo.
   Módulo AÑADIDO. No cambia cálculos ni funciones existentes: solo lee S (y usa wal() tal cual).
   - Copias internas en IndexedDB (base 'fj-seguridad'), separadas de localStorage 'fj1'.
   - Normalización aditiva (solo completa campos que faltan, nunca cambia valores).
   - Importar / restaurar con vista previa, copia previa y verificación de conteos y totales.
   - Verificación de datos (solo lectura). */

var FJ_ESQ = 1;                                   // versión del esquema de datos (campo S.esq)
var FJ_AUTO_MS = 24 * 3600 * 1000;                // copia automática como máximo cada 24 h
var FJ_CAP = { auto: 7, manual: 10, 'pre-restauracion': 5 };   // 'original' y 'corrupto' nunca se podan
var FJ_TIPOS = {
  original: '🔒 Original (primera copia)',
  auto: '🕒 Automática',
  manual: '💾 Manual',
  'pre-restauracion': '↩️ Antes de restaurar',
  corrupto: '⚠️ Datos ilegibles',
  'pre-borrado': '🗑️ Antes de borrar todo'
};
var fjLastTs = 0;                                 // garantiza orden estricto de las copias aunque dos se creen en el mismo milisegundo
var fjSnaps = [];                                 // metadatos de copias internas (sin el texto completo)
var fjSeg = { idb: null, err: null, norm: null, pend: null, listo: false, persist: null };

/* ---------- utilidades ---------- */
function fjNum(x) { return typeof x === 'number' && isFinite(x) }
function fjOpc(x) { return x == null || fjNum(x) }
function fjObj(x) { return !!x && typeof x === 'object' && !Array.isArray(x) }
function fjFecha(t) { return new Date(t).toLocaleString('es-CO', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false }) }
function fjKB(n) { return (n / 1024).toFixed(n < 10240 ? 1 : 0) + ' KB' }
function fjHash(s) { var h = 5381, i; for (i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(16) + '-' + s.length }
function fjDup(a) { var s = {}, n = 0; a.forEach(function (o) { if (o && o.id != null) { if (s[o.id]) n++; s[o.id] = 1 } }); return n }
function fjConteos(d) {
  var J = Array.isArray(d.j) ? d.j : [], c = { jornadas: J.length, carreras: 0, pausas: 0, movimientos: Array.isArray(d.mv) ? d.mv.length : 0 };
  J.forEach(function (j) { if (j) { c.carreras += Array.isArray(j.ca) ? j.ca.length : 0; c.pausas += Array.isArray(j.pa) ? j.pa.length : 0 } });
  return c
}
function fjBajar(nombre, texto) {
  var blob = new Blob([texto], { type: 'application/json' }), u = URL.createObjectURL(blob), a = document.createElement('a');
  a.href = u; a.download = nombre; a.style.display = 'none'; document.body.appendChild(a); a.click();
  setTimeout(function () { document.body.removeChild(a); URL.revokeObjectURL(u) }, 4000)
}

/* ---------- normalización (aditiva) ----------
   Solo completa lo que falta: listas vacías, ids, tema. NO cambia ningún valor existente.
   Si algo tiene un tipo inesperado, lanza error en vez de sobrescribir. */
function fjNormalizar(st) {
  if (!fjObj(st)) throw new Error('El contenido no es un objeto de datos.');
  var fx = { ids: 0, listas: 0, tema: 0 }, used = {};
  function lista(o, k, nom) {
    if (o[k] == null) { o[k] = []; fx.listas++ }
    else if (!Array.isArray(o[k])) throw new Error(nom + ' no es una lista.');
  }
  lista(st, 'j', 'La lista de jornadas'); lista(st, 'mv', 'La lista de movimientos');
  function reg(o, nom) { if (!fjObj(o)) throw new Error(nom + ' no es un registro válido.') }
  st.j.forEach(function (j, i) {
    reg(j, 'Jornada ' + (i + 1)); lista(j, 'pa', 'Las pausas de la jornada ' + (i + 1)); lista(j, 'ca', 'Las carreras de la jornada ' + (i + 1));
    j.pa.forEach(function (p) { reg(p, 'Una pausa') }); j.ca.forEach(function (c) { reg(c, 'Una carrera') })
  });
  st.mv.forEach(function (m, i) { reg(m, 'Movimiento ' + (i + 1)) });
  /* Fondos (Etapa 2): se crean vacíos en memoria sin contarlos como corrección, para no reescribir fj1 al abrir. */
  var NL = { fo: 'fondos', fm: 'movimientos de fondos', de: 'deudas', dm: 'movimientos de deudas', pr: 'préstamos', pm: 'movimientos de préstamos', pp: 'límites del presupuesto', cc: 'categorías propias', bw: 'billeteras', ap: 'apps', am: 'movimientos de apps', xc: 'cobros pendientes', xm: 'movimientos de cobros', px: 'promociones' };
  /* Billeteras flexibles y apps (Etapa 5): si faltan, se crean por defecto solo en memoria (equivalen a las billeteras de siempre). */
  if (st.bw == null) st.bw = bwDef(); if (st.ap == null) st.ap = apDef();
  /* Deudas, préstamos y presupuesto (Etapas 3 y 4): igual que fondos, listas vacías solo en memoria. */
  Object.keys(NL).forEach(function (k) { if (st[k] == null) st[k] = []; else if (!Array.isArray(st[k])) throw new Error('La lista de ' + NL[k] + ' no es una lista.') });
  Object.keys(NL).forEach(function (k) { st[k].forEach(function (o, i) { reg(o, 'Registro ' + (i + 1) + ' de ' + NL[k]) }) });
  var todos = [].concat(st.j, st.mv, st.fo, st.fm, st.de, st.dm, st.pr, st.pm, st.pp, st.cc, st.bw, st.ap, st.am, st.xc, st.xm, st.px);
  st.j.forEach(function (j) { todos = todos.concat(j.pa, j.ca) });
  todos.forEach(function (o) { if (o.id != null && o.id !== '') used[o.id] = 1 });
  todos.forEach(function (o) {
    if (o.id == null || o.id === '') { var n; do { n = uid() } while (used[n]); used[n] = 1; o.id = n; fx.ids++ }
  });
  if (st.tema == null) { st.tema = 'sistema'; fx.tema++ }
  st.esq = FJ_ESQ;
  fx.total = fx.ids + fx.listas + fx.tema;
  return fx
}
/* Se llama justo después de leer fj1 al arrancar. Mantiene la app viva si el contenido es inusable. */
function fjCargar() {
  try { fjSeg.norm = fjNormalizar(S) }
  catch (e) {
    fjSeg.norm = { error: String(e && e.message || e), total: 0 };
    if (!fjObj(S)) S = { j: [], mv: [], tema: 'sistema' }
  }
}

/* ---------- resumen: conteos y totales (usa wal() sin modificarla) ---------- */
function fjResumen(st) {
  var r = { jornadas: 0, carreras: 0, pausas: 0, movimientos: 0, carrerasValor: 0, propinas: 0, ingresos: 0, costos: 0, personales: 0, transferencias: 0, activas: 0, fondos: 0, fondoMovs: 0, fondosTotal: 0, deudas: 0, deudaMovs: 0, deudasTotal: 0, prestamos: 0, prestamoMovs: 0, prestamosTotal: 0, presupuestos: 0, categorias: 0, billeteras: 0, apps: 0, appsTotal: 0, cobros: 0, cobrosTotal: 0, saldos: {} };
  (st.j || []).forEach(function (j) {
    r.jornadas++; if (!j.fin) r.activas++;
    (j.ca || []).forEach(function (c) { r.carreras++; r.carrerasValor += c.v; r.propinas += c.p });
    r.pausas += (j.pa || []).length
  });
  (st.mv || []).forEach(function (m) {
    r.movimientos++;
    if (m.tipo === 'ingreso') r.ingresos += m.v; else if (m.tipo === 'costo') r.costos += m.v;
    else if (m.tipo === 'personal') r.personales += m.v; else if (m.tipo === 'transferencia') r.transferencias += m.v
  });
  (st.fo || []).forEach(function () { r.fondos++ });
  (st.fm || []).forEach(function (m) { r.fondoMovs++; r.fondosTotal += (m.tipo === 'retiro' ? -m.v : m.v) });
  (st.de || []).forEach(function () { r.deudas++ });
  (st.dm || []).forEach(function (m) { r.deudaMovs++; r.deudasTotal += (m.tipo === 'pago' ? -m.v : m.v) });
  (st.pr || []).forEach(function () { r.prestamos++ });
  (st.pm || []).forEach(function (m) { r.prestamoMovs++; r.prestamosTotal += (m.tipo === 'cobro' ? -m.v : m.v) });
  (st.pp || []).forEach(function (b) { r.presupuestos += fjNum(b.lim) ? b.lim : 0 });
  (st.cc || []).forEach(function () { r.categorias++ });
  (st.bw || []).forEach(function () { r.billeteras++ });
  (st.xc || []).forEach(function () { r.cobros++ });
  (st.xm || []).forEach(function (m) { r.cobrosTotal += (m.tipo === 'cobro' ? -m.v : m.v) });
  (st.ap || []).forEach(function () { r.apps++ });
  var old = S;
  try { S = st; bilRefresh(st); var w = wal(); BILX.forEach(function (b) { r.saldos[b] = w[b].s }); (st.ap || []).forEach(function (a) { r.appsTotal += apSaldo(a.id) }) } finally { S = old; bilRefresh() }
  return r
}
/* Billeteras a mostrar en resúmenes: las vigentes + las archivadas u otras que tengan saldo en algún resumen. */
function fjBilVis() { var l = [].slice.call(arguments), ks = BILX.slice(); l.forEach(function (x) { if (x && x.saldos) Object.keys(x.saldos).forEach(function (k) { if (ks.indexOf(k) < 0) ks.push(k) }) }); return ks.filter(function (b) { return BIL.indexOf(b) >= 0 || l.some(function (x) { return x && x.saldos && Math.abs(x.saldos[b] || 0) > 0.005 }) }) }
function fjResumenRaw(raw) { try { var d = JSON.parse(raw); fjNormalizar(d); return fjResumen(d) } catch (e) { return null } }
/* Lista de diferencias entre dos resúmenes (vacía = coinciden). */
function fjDifs(a, b) {
  var d = [], ks = ['jornadas', 'carreras', 'pausas', 'movimientos', 'carrerasValor', 'propinas', 'ingresos', 'costos', 'personales', 'transferencias', 'activas', 'fondos', 'fondoMovs', 'fondosTotal', 'deudas', 'deudaMovs', 'deudasTotal', 'prestamos', 'prestamoMovs', 'prestamosTotal', 'presupuestos', 'categorias', 'billeteras', 'apps', 'appsTotal', 'cobros', 'cobrosTotal'];
  if (!a || !b) return ['no se pudo calcular'];
  ks.forEach(function (k) { if (Math.abs(a[k] - b[k]) > 0.005) d.push(k) });
  Object.keys(Object.assign({}, a.saldos, b.saldos)).forEach(function (x) { if (Math.abs((a.saldos[x] || 0) - (b.saldos[x] || 0)) > 0.005) d.push('saldo ' + bn(x)) });
  return d
}

/* Claves de billetera válidas en un archivo: las de d.bw, o las 4 de siempre si es una copia anterior a las billeteras flexibles. */
function fjKeys(d) {
  var k = ['Dinero digital', 'Propinas', 'Efectivo', 'Daviplata'];
  if (fjObj(d) && Array.isArray(d.bw)) { k = ['Dinero digital', 'Propinas']; d.bw.forEach(function (w) { if (w && typeof w.k === 'string' && k.indexOf(w.k) < 0) k.push(w.k) }) }
  return k
}

/* Valida una lista de cuentas (deudas o préstamos) y sus movimientos. */
function fjValCuentas(d, L, M, tipos, menos, nombre, E, W) {
  if (E.length) return;
  var KK = fjKeys(d), IDOK = /^[A-Za-z0-9_-]+$/, ids = {}, sal = {};
  (d[L] || []).forEach(function (f, i) {
    var n = nombre + ' ' + (i + 1) + ': ';
    if (!fjObj(f)) { E.push(n + 'no es un registro válido.'); return }
    if (typeof f.id !== 'string' || !IDOK.test(f.id)) E.push(n + 'id inválido.'); else { ids[f.id] = f.nom; sal[f.id] = 0 }
    if (typeof f.nom !== 'string' || !f.nom.trim()) E.push(n + 'nombre inválido.');
    if (!fjOpc(f.fv)) E.push(n + 'fecha límite inválida.')
  });
  (d[M] || []).forEach(function (m, i) {
    var n = 'Movimiento de ' + nombre.toLowerCase() + ' ' + (i + 1) + ': ';
    if (!fjObj(m)) { E.push(n + 'no es un registro válido.'); return }
    if (typeof m.id !== 'string' || !IDOK.test(m.id)) E.push(n + 'id inválido.');
    if (typeof m.cid !== 'string' || !Object.prototype.hasOwnProperty.call(ids, m.cid)) E.push(n + 'pertenece a un registro que no existe.');
    if (!fjNum(m.t)) E.push(n + 'fecha inválida.');
    if (!fjNum(m.v) || m.v < 0) E.push(n + 'valor inválido.');
    if (tipos.concat(['inicial']).indexOf(m.tipo) < 0) E.push(n + 'tipo desconocido.');
    if (m.bil != null && m.bil !== '' && KK.indexOf(m.bil) < 0) E.push(n + 'billetera desconocida.');
    if (fjNum(m.v) && typeof m.cid === 'string' && Object.prototype.hasOwnProperty.call(sal, m.cid)) sal[m.cid] += (m.tipo === menos ? -m.v : m.v)
  });
  if (!E.length) {
    var dd = fjDup(d[L] || []) + fjDup(d[M] || []);
    if (dd) W.push('Hay ids repetidos en ' + nombre.toLowerCase() + 's (' + dd + '). Se restauran tal cual.');
    Object.keys(sal).forEach(function (k) { if (sal[k] < 0) W.push(nombre + ' “' + ids[k] + '” queda con saldo negativo.') })
  }
}

/* ---------- validación de un archivo a importar (solo lectura) ---------- */
function fjValidar(d) {
  var E = [], W = [], TI = ['ingreso', 'costo', 'personal', 'transferencia', 'ajuste'], KK = fjKeys(d);
  if (!fjObj(d)) { E.push('El contenido no es un objeto de datos válido.'); return { err: E, warn: W } }
  if (d.j == null && d.mv == null) { E.push('No contiene jornadas ni movimientos.'); return { err: E, warn: W } }
  if (d.j != null && !Array.isArray(d.j)) E.push('Las jornadas no son una lista.');
  if (d.mv != null && !Array.isArray(d.mv)) E.push('Los movimientos no son una lista.');
  if (E.length) return { err: E, warn: W };
  (d.j || []).forEach(function (j, i) {
    var n = 'Jornada ' + (i + 1) + ': ';
    if (!fjObj(j)) { E.push(n + 'no es un registro válido.'); return }
    if (!fjNum(j.ini)) E.push(n + 'inicio inválido.');
    if (!fjNum(j.hp)) E.push(n + 'horas programadas inválidas.');
    if (j.mt != null && j.mt !== 'e' && j.mt !== 't') E.push(n + 'tipo de meta inválido.');
    if (j.pv != null && !Array.isArray(j.pv)) E.push(n + 'las pausas previstas no son una lista.');
    if (!fjNum(j.ki)) E.push(n + 'km iniciales inválidos.');
    if (!fjOpc(j.fin)) E.push(n + 'hora de salida inválida.');
    if (!fjOpc(j.kf)) E.push(n + 'km finales inválidos.');
    if (j.pa != null && !Array.isArray(j.pa)) E.push(n + 'las pausas no son una lista.');
    if (j.ca != null && !Array.isArray(j.ca)) E.push(n + 'las carreras no son una lista.');
    (Array.isArray(j.pa) ? j.pa : []).forEach(function (p, k) { if (!fjObj(p) || !fjNum(p.a) || !fjOpc(p.b)) E.push(n + 'pausa ' + (k + 1) + ' inválida.') });
    (Array.isArray(j.ca) ? j.ca : []).forEach(function (c, k) { if (!fjObj(c) || !fjNum(c.t) || !fjNum(c.v) || !fjNum(c.p)) E.push(n + 'carrera ' + (k + 1) + ' inválida.'); else if (c.pg != null && (!Array.isArray(c.pg) || c.pg.some(function (l) { return !fjObj(l) || ['a', 'b'].indexOf(l.k) < 0 || !fjNum(l.v) || l.v < 0 || (l.k === 'b' && KK.indexOf(l.b) < 0) }))) E.push(n + 'carrera ' + (k + 1) + ' con pagos inválidos.') })
  });
  (d.mv || []).forEach(function (m, i) {
    var n = 'Movimiento ' + (i + 1) + ': ';
    if (!fjObj(m)) { E.push(n + 'no es un registro válido.'); return }
    if (!fjNum(m.t)) E.push(n + 'fecha inválida.');
    if (!fjNum(m.v)) E.push(n + 'valor inválido.');
    if (TI.indexOf(m.tipo) < 0) E.push(n + 'tipo desconocido.');
    if (m.tipo === 'ajuste' && m.sg !== 1 && m.sg !== -1) E.push(n + 'ajuste sin signo válido.');
    if (KK.indexOf(m.bil) < 0) E.push(n + 'billetera desconocida.');
    if (m.tipo === 'transferencia' && KK.indexOf(m.bil2) < 0) E.push(n + 'billetera destino desconocida.')
  });
  if (d.fo != null && !Array.isArray(d.fo)) E.push('Los fondos no son una lista.');
  if (d.fm != null && !Array.isArray(d.fm)) E.push('Los movimientos de fondos no son una lista.');
  [['bw', 'las billeteras'], ['ap', 'las apps'], ['am', 'los movimientos de apps'], ['xc', 'los cobros pendientes'], ['xm', 'los movimientos de cobros'], ['de', 'las deudas'], ['dm', 'los movimientos de deudas'], ['pr', 'los préstamos'], ['pm', 'los movimientos de préstamos'], ['pp', 'los límites del presupuesto'], ['cc', 'las categorías propias'], ['px', 'las promociones']].forEach(function (x) {
    if (d[x[0]] != null && !Array.isArray(d[x[0]])) E.push(x[1].charAt(0).toUpperCase() + x[1].slice(1) + ' no son una lista.')
  });
  if (!E.length) {
    var IDOK = /^[A-Za-z0-9_-]+$/, fid = {}, sal = {};
    (d.fo || []).forEach(function (f, i) {
      var n = 'Fondo ' + (i + 1) + ': ';
      if (!fjObj(f)) { E.push(n + 'no es un registro válido.'); return }
      if (typeof f.id !== 'string' || !IDOK.test(f.id)) E.push(n + 'id inválido.'); else { fid[f.id] = f.nom; sal[f.id] = 0 }
      if (typeof f.nom !== 'string' || !f.nom.trim()) E.push(n + 'nombre inválido.');
      if (!fjOpc(f.obj) || (f.obj != null && f.obj < 0)) E.push(n + 'objetivo inválido.')
    });
    (d.fm || []).forEach(function (m, i) {
      var n = 'Movimiento de fondo ' + (i + 1) + ': ';
      if (!fjObj(m)) { E.push(n + 'no es un registro válido.'); return }
      if (typeof m.id !== 'string' || !IDOK.test(m.id)) E.push(n + 'id inválido.');
      if (typeof m.fid !== 'string' || !Object.prototype.hasOwnProperty.call(fid, m.fid)) E.push(n + 'pertenece a un fondo que no existe.');
      if (!fjNum(m.t)) E.push(n + 'fecha inválida.');
      if (!fjNum(m.v) || m.v < 0) E.push(n + 'valor inválido.');
      if (['aporte', 'retiro', 'inicial'].indexOf(m.tipo) < 0) E.push(n + 'tipo desconocido.');
      if (m.bil != null && m.bil !== '' && KK.indexOf(m.bil) < 0) E.push(n + 'billetera desconocida.');
      if (fjNum(m.v) && typeof m.fid === 'string' && Object.prototype.hasOwnProperty.call(sal, m.fid)) sal[m.fid] += (m.tipo === 'retiro' ? -m.v : m.v)
    });
    (d.bw || []).forEach(function (w, i) {
      var n = 'Billetera ' + (i + 1) + ': ';
      if (!fjObj(w)) { E.push(n + 'no es un registro válido.'); return }
      if (typeof w.k !== 'string' || !w.k) E.push(n + 'clave inválida.');
      if (typeof w.nom !== 'string' || !w.nom.trim()) E.push(n + 'nombre inválido.')
    });
    var AID = {};
    (d.ap || []).forEach(function (a, i) {
      var n = 'App ' + (i + 1) + ': ';
      if (!fjObj(a)) { E.push(n + 'no es un registro válido.'); return }
      if (typeof a.id !== 'string' || !IDOK.test(a.id)) E.push(n + 'id inválido.'); else AID[a.id] = 1;
      if (typeof a.nom !== 'string' || !a.nom.trim()) E.push(n + 'nombre inválido.')
    });
    (d.am || []).forEach(function (m, i) {
      var n = 'Movimiento de app ' + (i + 1) + ': ';
      if (!fjObj(m)) { E.push(n + 'no es un registro válido.'); return }
      if (typeof m.id !== 'string' || !IDOK.test(m.id)) E.push(n + 'id inválido.');
      if (typeof m.aid !== 'string' || !AID[m.aid]) E.push(n + 'pertenece a una app que no existe.');
      if (!fjNum(m.t)) E.push(n + 'fecha inválida.');
      if (!fjNum(m.v) || m.v < 0) E.push(n + 'valor inválido.');
      if (['premio', 'comision', 'recarga', 'ajuste', 'retiro'].indexOf(m.tipo) < 0) E.push(n + 'tipo desconocido.');
      if (m.bil != null && m.bil !== '' && KK.indexOf(m.bil) < 0) E.push(n + 'billetera desconocida.');
      if (m.tipo === 'retiro' && ['ok', 'camino'].indexOf(m.est) < 0) E.push(n + 'estado de retiro inválido.');
      if (m.cr != null && (!fjNum(m.cr) || m.cr < 0)) E.push(n + 'comisión de retiro inválida.')
    });
    fjValCuentas(d, 'de', 'dm', ['pago', 'cargo'], 'pago', 'Deuda', E, W);
    fjValCuentas(d, 'xc', 'xm', ['cobro', 'extra'], 'cobro', 'Cobro pendiente', E, W);
    fjValCuentas(d, 'pr', 'pm', ['cobro', 'prestamo'], 'cobro', 'Préstamo', E, W);
    (d.cc || []).forEach(function (b, i) {
      var n = 'Categoría propia ' + (i + 1) + ': ';
      if (!fjObj(b)) { E.push(n + 'no es un registro válido.'); return }
      if (typeof b.id !== 'string' || !IDOK.test(b.id)) E.push(n + 'id inválido.');
      if (['costo', 'personal'].indexOf(b.tipo) < 0) E.push(n + 'tipo desconocido.');
      if (typeof b.nom !== 'string' || !b.nom.trim() || /['"<>&\\`]/.test(b.nom)) E.push(n + 'nombre inválido.')
    });
    (d.px || []).forEach(function (p, i) {
      var n = 'Promoción ' + (i + 1) + ': ';
      if (!fjObj(p)) { E.push(n + 'no es un registro válido.'); return }
      if (typeof p.id !== 'string' || !IDOK.test(p.id)) E.push(n + 'id inválido.');
      if (typeof p.aid !== 'string' || !AID[p.aid]) E.push(n + 'pertenece a una app que no existe.');
      if (['meta', 'bono'].indexOf(p.tp) < 0) E.push(n + 'tipo desconocido.');
      if (!fjNum(p.d)) E.push(n + 'fecha inválida.')
    });
    (d.pp || []).forEach(function (b, i) {
      var n = 'Límite de presupuesto ' + (i + 1) + ': ';
      if (!fjObj(b)) { E.push(n + 'no es un registro válido.'); return }
      if (typeof b.id !== 'string' || !IDOK.test(b.id)) E.push(n + 'id inválido.');
      if (['costo', 'personal'].indexOf(b.tipo) < 0) E.push(n + 'tipo desconocido.');
      if (typeof b.cat !== 'string' || !b.cat) E.push(n + 'categoría inválida.');
      if (!fjNum(b.lim) || b.lim < 0) E.push(n + 'límite inválido.');
      if (b.p != null && ['m', 's'].indexOf(b.p) < 0) E.push(n + 'periodo desconocido.')
    });
    if (!E.length) {
      var df = fjDup(d.fo || []) + fjDup(d.fm || []);
      if (df) W.push('Hay ids repetidos en fondos (' + df + '). Se restauran tal cual.');
      Object.keys(sal).forEach(function (k) { if (sal[k] < 0) W.push('El fondo “' + fid[k] + '” queda con saldo negativo.') })
    }
  }
  if (!E.length) {
    var J = d.j || [], dj = fjDup(J), dm = fjDup(d.mv || []), dp = 0, dc = 0, pa = [], ca = [];
    J.forEach(function (j) { pa = pa.concat(j.pa || []); ca = ca.concat(j.ca || []) });
    dp = fjDup(pa); dc = fjDup(ca);
    if (dj + dm + dp + dc) W.push('Hay ids repetidos (jornadas ' + dj + ', movimientos ' + dm + ', pausas ' + dp + ', carreras ' + dc + '). Se restauran tal cual.');
    if (J.filter(function (j) { return !j.fin }).length > 1) W.push('Hay más de una jornada activa en la copia.')
  }
  return { err: E, warn: W }
}
function fjExtraer(obj) {
  if (fjObj(obj) && obj.tipo === 'copia-de-seguridad' && fjObj(obj.datos)) return { datos: obj.datos, meta: obj };
  if (fjObj(obj) && (obj.j != null || obj.mv != null)) return { datos: obj, meta: null };
  return null
}
/* Avisos de coherencia sobre los datos actuales (no modifican nada). */
function fjAnomalias(st) {
  var A = [], pa = [], ca = [], act = 0, pab = 0, fi = 0, kk = 0;
  st.j.forEach(function (j) {
    pa = pa.concat(j.pa || []); ca = ca.concat(j.ca || []);
    if (!j.fin) act++; if (j.fin && (j.pa || []).some(function (p) { return !p.b })) pab++;
    if (j.fin && j.fin <= j.ini) fi++; if (j.fin && j.kf != null && j.kf < j.ki) kk++
  });
  var dj = fjDup(st.j), dm = fjDup(st.mv), dp = fjDup(pa), dc = fjDup(ca);
  if (dj + dm + dp + dc) A.push('Ids repetidos: jornadas ' + dj + ', movimientos ' + dm + ', pausas ' + dp + ', carreras ' + dc + '.');
  if (act > 1) A.push('Hay ' + act + ' jornadas activas (debería haber una).');
  if (pab) A.push(pab + ' jornada(s) cerrada(s) con una pausa sin hora de fin.');
  if (fi) A.push(fi + ' jornada(s) con salida anterior o igual al inicio.');
  if (kk) A.push(kk + ' jornada(s) con km finales menores que los iniciales.');
  var fi = {}, orf = 0, fnm = {}; (st.fo || []).forEach(function (f) { fi[f.id] = 0; fnm[f.id] = f.nom });
  (st.fm || []).forEach(function (m) { if (Object.prototype.hasOwnProperty.call(fi, m.fid)) fi[m.fid] += (m.tipo === 'retiro' ? -m.v : m.v); else orf++ });
  if (orf) A.push(orf + ' movimiento(s) de fondos sin fondo asociado.');
  Object.keys(fi).forEach(function (k) { if (fi[k] < 0) A.push('El fondo “' + fnm[k] + '” tiene saldo negativo.') });
  var dfo = fjDup(st.fo || []) + fjDup(st.fm || []); if (dfo) A.push('Ids repetidos en fondos: ' + dfo + '.');
  [['de', 'dm', 'pago', 'Deuda', 'deudas'], ['pr', 'pm', 'cobro', 'Préstamo', 'préstamos']].forEach(function (x) {
    var si = {}, nm = {}, o = 0; (st[x[0]] || []).forEach(function (f) { si[f.id] = 0; nm[f.id] = f.nom });
    (st[x[1]] || []).forEach(function (m) { if (Object.prototype.hasOwnProperty.call(si, m.cid)) si[m.cid] += (m.tipo === x[2] ? -m.v : m.v); else o++ });
    if (o) A.push(o + ' movimiento(s) de ' + x[4] + ' sin registro asociado.');
    Object.keys(si).forEach(function (k) { if (si[k] < 0) A.push(x[3] + ' “' + nm[k] + '” tiene saldo negativo.') });
    var dx = fjDup(st[x[0]] || []) + fjDup(st[x[1]] || []); if (dx) A.push('Ids repetidos en ' + x[4] + ': ' + dx + '.')
  });
  var dpp = fjDup(st.pp || []); if (dpp) A.push('Ids repetidos en el presupuesto: ' + dpp + '.');
  return A
}

/* ---------- copias internas (IndexedDB) ---------- */
function fjDB() {
  if (fjSeg.idb) return fjSeg.idb;
  fjSeg.idb = new Promise(function (res, rej) {
    try {
      if (!window.indexedDB) throw new Error('IndexedDB no disponible en este navegador.');
      var q = indexedDB.open('fj-seguridad', 1);
      q.onupgradeneeded = function () { var d = q.result; if (!d.objectStoreNames.contains('snaps')) d.createObjectStore('snaps', { keyPath: 'id' }) };
      q.onsuccess = function () { res(q.result) };
      q.onerror = function () { rej(q.error || new Error('No se pudo abrir IndexedDB.')) };
      q.onblocked = function () { rej(new Error('IndexedDB bloqueada por otra pestaña.')) }
    } catch (e) { rej(e) }
  });
  return fjSeg.idb
}
function fjTx(modo, fn) {
  return fjDB().then(function (db) {
    return new Promise(function (res, rej) {
      var t = db.transaction('snaps', modo), rq = fn(t.objectStore('snaps'));
      t.oncomplete = function () { res(rq ? rq.result : undefined) };
      t.onerror = t.onabort = function () { rej(t.error || new Error('Error de IndexedDB.')) }
    })
  })
}
function fjAll() { return fjTx('readonly', function (s) { return s.getAll() }) }
function fjGet(id) { return fjTx('readonly', function (s) { return s.get(id) }) }
function fjPut(r) { return fjTx('readwrite', function (s) { return s.put(r) }) }
function fjDel(id) { return fjTx('readwrite', function (s) { return s.delete(id) }) }
function fjMeta(r) { return { id: r.id, ts: r.ts, tipo: r.tipo, nota: r.nota || '', bytes: r.bytes, h: r.h, res: r.res } }
function fjRefrescar() {
  return fjAll().then(function (l) { l.sort(function (a, b) { return b.ts - a.ts }); fjSnaps = l.map(fjMeta); return l })
    .catch(function (e) { fjSeg.err = String(e && e.message || e); return [] })
}
function fjPoda(tipo) {
  var cap = FJ_CAP[tipo];
  if (!cap) return Promise.resolve();
  return fjAll().then(function (l) {
    var m = l.filter(function (r) { return r.tipo === tipo }).sort(function (a, b) { return b.ts - a.ts }).slice(cap);
    return Promise.all(m.map(function (r) { return fjDel(r.id) }))
  })
}
/* Guarda una copia y la verifica leyéndola de nuevo. Rechaza si no coincide. */
function fjCrearSnap(tipo, raw, nota) {
  fjLastTs = Math.max(Date.now(), fjLastTs + 1);
  var r = { id: 's' + fjLastTs.toString(36) + Math.random().toString(36).slice(2, 6), ts: fjLastTs, tipo: tipo, nota: nota || '', raw: raw, bytes: raw.length, h: fjHash(raw), res: fjResumenRaw(raw) };
  return fjPut(r).then(function () { return fjGet(r.id) }).then(function (x) {
    if (!x || x.raw !== raw) throw new Error('La copia interna no coincide al verificarla.');
    return fjPoda(tipo)
  }).then(fjRefrescar).then(function () { return r.id })
}
/* Arranque: copia 'original' (una sola vez), 'corrupto' si fj1 no se puede leer, 'auto' cada 24 h. */
function fjArranque(raw) {
  try { if (navigator.storage && navigator.storage.persist) navigator.storage.persist().then(function (v) { fjSeg.persist = v }).catch(function () { }) } catch (e) { }
  var fin = function () { fjSeg.listo = true; if (typeof tab !== 'undefined' && tab === 'cfg') render() };
  if (raw == null) { return fjRefrescar().then(fin) }
  var ilegible = false; try { JSON.parse(raw) } catch (e) { ilegible = true }
  return fjAll().then(function (l) {
    l.sort(function (a, b) { return b.ts - a.ts });
    var ori = l.filter(function (r) { return r.tipo === 'original' })[0], ult = l[0],
      ta = l.filter(function (r) { return r.tipo === 'auto' || r.tipo === 'original' })[0],
      nota = ilegible ? 'fj1 no se pudo leer como JSON' : '';
    if (!ori) return fjCrearSnap('original', raw, nota);
    if (ilegible && !l.some(function (r) { return r.raw === raw })) return fjCrearSnap('corrupto', raw, nota);
    if (ult.raw !== raw && Date.now() - ta.ts > FJ_AUTO_MS) return fjCrearSnap('auto', raw, '')
  }).then(function () {
    /* Si al normalizar se completaron campos que faltaban, se guardan para que los ids sean estables.
       Solo después de tener la copia verificada y solo si fj1 no cambió mientras tanto. */
    var n = fjSeg.norm;
    if (n && !n.error && n.total > 0 && !ilegible) { try { if (localStorage.getItem(K) === raw) sv() } catch (e) { } }
  }).catch(function (e) {
    fjSeg.err = String(e && e.message || e);
    toast('⚠️ No se pudo crear la copia interna');
  }).then(fjRefrescar).then(fin)
}

/* ---------- ventanas de aviso ---------- */
function fjErrM(msg, lista) {
  var l = lista && lista.length ? lista.slice(0, 8).map(function (x) { return '<div class="li"><small>' + esc(x) + '</small></div>' }).join('') + (lista.length > 8 ? '<small>…y ' + (lista.length - 8) + ' más.</small><div style="height:10px"></div>' : '') : '';
  openM('<h3>⚠️ No se pudo</h3><p>' + esc(msg) + '</p>' + l + '<button class="btn out" onclick="closeM()">Cerrar</button>')
}
function fjFila(l, a, b, f) { f = f || function (x) { return String(x) }; return kv(l, (a == null ? '—' : f(a)) + ' → ' + f(b)) }

/* ---------- sección en Ajustes ---------- */
function fjSegHTML() {
  var h = '<h2>🛡️ Seguridad de datos</h2><div class="card form">' +
    '<button class="btn out" onclick="fjVerificar()">🔍 Verificar datos</button><div style="height:8px"></div>' +
    '<button class="btn out" onclick="fjManual()">💾 Crear copia interna ahora</button><div style="height:8px"></div>' +
    '<button class="btn out" onclick="$(\'#fjfile\').click()">📥 Importar / restaurar (.json)</button>' +
    '<input id="fjfile" type="file" accept=".json,application/json" style="display:none" onchange="fjArchivo(this)">' +
    '<div style="height:8px"></div><small>Las copias internas se guardan en este teléfono, aparte de tus datos. Antes de restaurar se crea una copia automática.</small></div>' +
    '<h2>🗂️ Copias internas' + (fjSnaps.length ? ' (' + fjSnaps.length + ')' : '') + '</h2>';
  if (fjSeg.err) h += '<div class="warn"><span>⚠️ ' + esc(fjSeg.err) + '</span></div>';
  if (!fjSnaps.length) return h + '<div class="li"><small>' + (fjSeg.listo ? 'Aún no hay copias internas.' : 'Preparando copias…') + '</small></div>';
  return h + fjSnaps.slice(0, 12).map(function (s) {
    var r = s.res;
    return '<div class="li"><div class="g"><b>' + (FJ_TIPOS[s.tipo] || esc(s.tipo)) + '</b><br><small>' + fjFecha(s.ts) + (r ? ' · ' + r.jornadas + ' jornadas · ' + r.movimientos + ' mov.' : '') + ' · ' + fjKB(s.bytes) + '</small>' + (s.nota ? '<br><small>' + esc(s.nota) + '</small>' : '') + '</div>' +
      '<div class="ab"><button class="ed" onclick="fjRestSnap(\'' + s.id + '\')">↩️ Restaurar</button><button class="ed" onclick="fjDescSnap(\'' + s.id + '\')">⬇️ Descargar</button></div></div>'
  }).join('') + (fjSnaps.length > 12 ? '<small>Se muestran las 12 más recientes de ' + fjSnaps.length + '.</small>' : '')
}

/* ---------- acciones ---------- */
function fjManual() {
  var raw; try { raw = localStorage.getItem(K) } catch (e) { }
  if (raw == null) raw = JSON.stringify(S);
  fjCrearSnap('manual', raw, '').then(function () { fjSeg.err = null; toast('✅ Copia interna creada y verificada'); render() })
    .catch(function (e) { toast('No se pudo crear la copia: ' + (e && e.message || e)) })
}
function fjPaquete(raw) {
  var d = JSON.parse(raw), c = fjConteos(d);
  return { app: 'Finanzas + Jornada', tipo: 'copia-de-seguridad', version: 1, exportado: new Date().toISOString(), claveLocal: K, origen: 'copia-interna', resumen: c, datos: d }
}
function fjDescSnap(id) {
  fjGet(id).then(function (r) {
    if (!r) throw new Error('Copia no encontrada.');
    fjBajar('finanzas-jornada-copia-interna-' + iso(r.ts) + '.json', JSON.stringify(fjPaquete(r.raw), null, 2)); toast('✅ Copia descargada')
  }).catch(function (e) { toast('No se pudo descargar: ' + (e && e.message || e)) })
}
function fjRestSnap(id) {
  fjGet(id).then(function (r) {
    if (!r) throw new Error('Copia no encontrada.');
    fjPrepararRestauro(r.raw, 'copia interna del ' + fjFecha(r.ts))
  }).catch(function (e) { fjErrM(String(e && e.message || e)) })
}
function fjArchivo(inp) {
  var f = inp.files && inp.files[0];
  if (!f) return;
  if (f.size > 15 * 1024 * 1024) { inp.value = ''; return fjErrM('El archivo es demasiado grande para ser una copia de la app.') }
  var r = new FileReader();
  r.onload = function () { fjPrepararRestauro(String(r.result), 'archivo ' + f.name) };
  r.onerror = function () { fjErrM('No se pudo leer el archivo.') };
  r.readAsText(f); inp.value = ''
}
/* Paso 1: leer, validar, normalizar y mostrar vista previa. No cambia nada todavía. */
function fjPrepararRestauro(texto, origen) {
  var obj, x;
  try { obj = JSON.parse(texto) } catch (e) { return fjErrM('El archivo no es un JSON válido. Tus datos actuales no se tocaron.') }
  x = fjExtraer(obj);
  if (!x) return fjErrM('No parece una copia de Finanzas + Jornada. Tus datos actuales no se tocaron.');
  var v = fjValidar(x.datos), meta = x.meta;
  if (meta && meta.app && meta.app !== 'Finanzas + Jornada') v.err.push('El archivo es de otra aplicación (' + meta.app + ').');
  if (meta && meta.version > 1) v.warn.push('La copia es de una versión más nueva de la app (' + meta.version + ').');
  if (!v.err.length && meta && fjObj(meta.resumen)) {
    var c = fjConteos(x.datos);
    ['jornadas', 'carreras', 'pausas', 'movimientos'].forEach(function (k) {
      if (meta.resumen[k] != null && meta.resumen[k] !== c[k]) v.err.push('El resumen del archivo dice ' + meta.resumen[k] + ' ' + k + ' pero contiene ' + c[k] + ' (archivo incompleto o alterado).')
    })
  }
  if (v.err.length) return fjErrM('No se puede restaurar este archivo. Tus datos actuales no se tocaron.', v.err);
  var fx, res, act = null;
  try { fx = fjNormalizar(x.datos) } catch (e) { return fjErrM('Datos con formato inesperado: ' + (e.message || e)) }
  try { res = fjResumen(x.datos) } catch (e) { return fjErrM('No se pudieron calcular los totales de la copia.') }
  try { act = fjResumen(S) } catch (e) { }
  fjSeg.pend = { datos: x.datos, origen: origen, res: res };
  var igual = act && !fjDifs(act, res).length, ad = v.warn.slice();
  if (fx.total) ad.push('Se completaron ' + fx.total + ' campo(s) que faltaban (ids/listas vacías). No se cambió ningún valor.');
  var h = '<h3>↩️ Restaurar copia</h3><p>' + esc(origen) + (meta && meta.exportado ? ' · exportada ' + fjFecha(Date.parse(meta.exportado) || 0) : '') + '</p>' +
    '<h2>Actual → Copia</h2><div class="card">' +
    fjFila('Jornadas', act && act.jornadas, res.jornadas) + fjFila('Carreras', act && act.carreras, res.carreras) +
    fjFila('Pausas', act && act.pausas, res.pausas) + fjFila('Movimientos', act && act.movimientos, res.movimientos) +
    fjFila('Fondos', act && act.fondos, res.fondos) + fjFila('Mov. de fondos', act && act.fondoMovs, res.fondoMovs) + fjFila('Total en fondos', act && act.fondosTotal, res.fondosTotal, cop) +
    fjFila('Deudas', act && act.deudas, res.deudas) + fjFila('Saldo de deudas', act && act.deudasTotal, res.deudasTotal, cop) +
    fjFila('Préstamos', act && act.prestamos, res.prestamos) + fjFila('Por cobrar', act && act.prestamosTotal, res.prestamosTotal, cop) +
    fjFila('Límites (suma)', act && act.presupuestos, res.presupuestos, cop) + fjFila('Categorías propias', act && act.categorias, res.categorias) +
    fjFila('Billeteras', act && act.billeteras, res.billeteras) + fjFila('Saldo en apps', act && act.appsTotal, res.appsTotal, cop) + fjFila('Por cobrar', act && act.cobrosTotal, res.cobrosTotal, cop) +
    fjBilVis(act, res).map(function (b) { return fjFila(wl(b), act && act.saldos[b], res.saldos[b], cop) }).join('') + '</div>';
  if (igual) h += '<div class="warn" style="margin-top:10px"><span>Esta copia es igual a tus datos actuales.</span></div>';
  ad.forEach(function (a) { h += '<div class="warn" style="margin-top:10px"><span>⚠️ ' + esc(a) + '</span></div>' });
  h += '<p style="margin-top:12px">Esto <b>reemplaza</b> tus datos actuales. Antes se guarda una copia interna y al final se verifican conteos y totales.</p>' +
    '<div class="two"><button class="btn out" onclick="fjSeg.pend=null;closeM()">Cancelar</button><button class="btn" onclick="fjConfirmar()">Restaurar</button></div>';
  openM(h)
}
/* Paso 2: copia previa verificada → escribir → releer → comparar conteos y totales → (si falla) volver atrás. */
function fjConfirmar() {
  var p = fjSeg.pend; if (!p) return;
  fjSeg.pend = null; closeM();
  var antes = null; try { antes = localStorage.getItem(K) } catch (e) { }
  var paso = antes != null ? fjCrearSnap('pre-restauracion', antes, 'Antes de restaurar: ' + p.origen) : Promise.resolve();
  paso.then(function () {
    var txt = JSON.stringify(p.datos), leido, chk, d;
    try {
      localStorage.setItem(K, txt); leido = localStorage.getItem(K);
      chk = fjResumenRaw(leido); d = fjDifs(chk, p.res);
      if (leido !== txt || d.length) throw new Error('La verificación no coincidió' + (d.length ? ' (' + d.join(', ') + ')' : '') + '.')
    } catch (e) {
      try { if (antes != null) localStorage.setItem(K, antes); else localStorage.removeItem(K) } catch (e2) { }
      throw e
    }
    S = p.datos; det = null; EM = null; RET = null; render();
    var r = p.res;
    openM('<h3>✅ Restauración verificada</h3><div class="card">' +
      kv('Copia interna previa', antes != null ? 'Creada y verificada' : 'No había datos') + kv('Datos escritos y releídos', 'Coinciden') +
      kv('Conteos', r.jornadas + ' jornadas · ' + r.carreras + ' carreras · ' + r.pausas + ' pausas · ' + r.movimientos + ' mov.') +
      kv('Fondos', r.fondos + ' fondo(s) · ' + r.fondoMovs + ' mov. · ' + cop(r.fondosTotal)) +
      kv('Deudas', r.deudas + ' · ' + r.deudaMovs + ' mov. · ' + cop(r.deudasTotal)) +
      kv('Préstamos', r.prestamos + ' · ' + r.prestamoMovs + ' mov. · ' + cop(r.prestamosTotal)) +
      kv('Presupuesto', cop(r.presupuestos) + ' en límites') +
      kv('Billeteras y apps', r.billeteras + ' billeteras · ' + r.apps + ' apps · ' + cop(r.appsTotal) + ' en apps') +
      fjBilVis(r).map(function (b) { return kv(wl(b), cop(r.saldos[b])) }).join('') + '</div>' +
      '<p style="margin-top:12px">Si algo no es lo esperado, puedes volver atrás desde “Copias internas” (↩️ Antes de restaurar).</p><button class="btn" onclick="closeM()">Listo</button>')
  }).catch(function (e) {
    fjErrM('No se restauró nada: ' + (e && e.message || e) + ' Tus datos actuales siguen como estaban.')
  })
}
/* Verificación (solo lectura). */
function fjVerificar() {
  var rm = null, raw = null, dk = null, w = [];
  try { rm = fjResumen(S) } catch (e) { w.push('No se pudieron calcular los totales actuales: ' + (e.message || e)) }
  try { raw = localStorage.getItem(K) } catch (e) { w.push('No se puede leer el almacenamiento local.') }
  if (raw != null) dk = fjResumenRaw(raw);
  var disco = raw == null ? 'Aún no hay datos guardados' : !dk ? '⚠️ No se pudo leer fj1' : (rm && !fjDifs(rm, dk).length) ? '✅ Coincide con lo que ves' : '⚠️ Difiere de lo que ves';
  if (raw != null && !dk) w.push('El contenido guardado en fj1 no es legible.');
  else if (rm && dk && fjDifs(rm, dk).length) w.push('Lo guardado difiere de lo mostrado en: ' + fjDifs(rm, dk).join(', ') + '.');
  var hs = raw != null ? fjHash(raw) : null, ig = hs && fjSnaps.filter(function (s) { return s.h === hs })[0];
  try { fjAnomalias(S).forEach(function (a) { w.push(a) }) } catch (e) { }
  if (fjSeg.norm && fjSeg.norm.error) w.push('Al abrir: ' + fjSeg.norm.error);
  else if (fjSeg.norm && fjSeg.norm.total) w.push('Al abrir se completaron ' + fjSeg.norm.total + ' campo(s) que faltaban. No se cambió ningún valor.');
  if (fjSeg.err) w.push('Copias internas: ' + fjSeg.err);
  if (rm) BILX.forEach(function (b) { if (rm.saldos[b] < 0) w.push('La billetera ' + b + ' tiene saldo negativo (' + cop(rm.saldos[b]) + ').') });
  var h = '<h3>🔍 Verificación de datos</h3>';
  if (rm) h += sec('📦 Datos actuales', kv('Jornadas', rm.jornadas) + kv('Carreras', rm.carreras) + kv('Pausas', rm.pausas) + kv('Movimientos', rm.movimientos) +
    kv('Ingresos por carreras', cop(rm.carrerasValor)) + kv('Propinas', cop(rm.propinas)) +
    kv('Fondos', rm.fondos) + kv('Movimientos de fondos', rm.fondoMovs) + kv('Total en fondos', cop(rm.fondosTotal)) +
    kv('Deudas', rm.deudas) + kv('Saldo de deudas', cop(rm.deudasTotal)) + kv('Préstamos', rm.prestamos) + kv('Por cobrar', cop(rm.prestamosTotal)) + kv('Límites de presupuesto', cop(rm.presupuestos)) + kv('Billeteras', rm.billeteras) + kv('Saldo en apps', cop(rm.appsTotal)) + kv('Por cobrar', cop(rm.cobrosTotal)) +
    fjBilVis(rm).map(function (b) { return kv(wl(b), cop(rm.saldos[b]), rm.saldos[b] < 0 ? 'neg' : '') }).join(''));
  h += sec('💽 Guardado en el teléfono', kv('Clave fj1', disco) + kv('Tamaño', raw != null ? fjKB(raw.length) : '—') +
    kv('Almacenamiento protegido', fjSeg.persist === true ? 'Sí' : fjSeg.persist === false ? 'No concedido' : 'Sin dato'));
  h += sec('🗂️ Copias internas', kv('Cantidad', fjSnaps.length) + kv('Última', fjSnaps.length ? fjFecha(fjSnaps[0].ts) : '—') +
    kv('Copia igual a los datos actuales', raw == null ? '—' : ig ? '✅ Sí (' + fjFecha(ig.ts) + ')' : 'No (hay cambios posteriores)'));
  h += w.length ? '<h2>Avisos</h2>' + w.map(function (a) { return '<div class="warn" style="margin-bottom:8px"><span>⚠️ ' + esc(a) + '</span></div>' }).join('') : '<div class="li" style="margin-top:10px"><small>✅ Sin avisos.</small></div>';
  openM(h + '<div style="height:8px"></div><button class="btn" onclick="closeM()">Cerrar</button>')
}
