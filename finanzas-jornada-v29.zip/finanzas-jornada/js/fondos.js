/* Finanzas + Jornada — fondos.js: Fondos y metas (Etapa 2).
   Datos: S.fo = fondos {id,nom,obj,fr,arch,ca,ua}  (fr = recordatorio de aporte cada N días)
          S.fm = movimientos de fondo {id,fid,t,tipo:'inicial'|'aporte'|'retiro',v,bil,nota,ua}
   El saldo de un fondo se calcula (nunca se guarda). Si un movimiento tiene billetera (bil),
   wal() lo refleja: aporte = sale de la billetera, retiro = entra a la billetera. */
var fLastBil = '';
function fEns() { if (!Array.isArray(S.fo)) S.fo = []; if (!Array.isArray(S.fm)) S.fm = [] }
function fFondos() { return S.fo || [] }
function fById(id) { return fFondos().filter(function (f) { return f.id === id })[0] }
function fMovs(id) { return (S.fm || []).filter(function (m) { return m.fid === id }) }
function fMById(id) { return (S.fm || []).filter(function (m) { return m.id === id })[0] }
function fSig(m) { return m.tipo === 'retiro' ? -m.v : m.v }
function fSaldo(id) { var s = 0; fMovs(id).forEach(function (m) { s += fSig(m) }); return s }
function fIni(id) { return fMovs(id).filter(function (m) { return m.tipo === 'inicial' })[0] }
function fPct(f, s) { return f.obj > 0 ? Math.max(0, s / f.obj * 100) : null }
function fp(p) { return (p >= 100 ? Math.round(p) : Math.floor(p)) + '%' }
function fBar(p) { return '<div class="pbar' + (p >= 100 ? ' ok' : '') + '"><i style="width:' + Math.min(100, p) + '%"></i></div>' }

/* ---------- lista de fondos ---------- */
function fCard(f) {
  var s = fSaldo(f.id), p = fPct(f, s), tp = f.tp || 'libre', ic = f.ic || (tp === 'fijo' ? '📌' : tp === 'ahorro' ? '🎯' : '💰'),
    sub = tp === 'fijo' ? fxFijoTxt(f) : tp === 'ahorro' ? fxAhorroTxt(f) : '', ok = tp === 'fijo' ? '✅ Listo para pagar' : '🎉 Meta alcanzada';
  return '<div class="li tap fc" onclick="fdet=\'' + f.id + '\';render()"><div class="row"><b>' + esc(ic) + ' ' + esc(f.nom) + (f.arch ? ' 📦' : '') + (f.pz ? ' ⏸️' : '') + '</b><b class="big ' + (s < 0 ? 'neg' : '') + '">' + cop(s) + '</b></div>' +
    (p === null ? '<small>Sin objetivo definido</small>' : fBar(p) + '<div class="row"><small>' + fp(p) + ' de ' + cop(f.obj) + '</small><small>' + (s >= f.obj ? ok : 'Faltan ' + cop(f.obj - s)) + '</small></div>') +
    (sub ? '<small style="display:block;margin-top:3px">' + sub + '</small>' : '') + '</div>'
}
function vFondos() {
  var act = fFondos().filter(function (f) { return !f.arch }), arc = fFondos().filter(function (f) { return f.arch }), tot = 0;
  act.forEach(function (f) { tot += fSaldo(f.id) });
  var fj = act.filter(function (f) { return f.tp === 'fijo' }).sort(function (a, b) { return (a.pv || Infinity) - (b.pv || Infinity) }),
    ah = act.filter(function (f) { return f.tp === 'ahorro' }).sort(function (a, b) { return (a.pr || 5) - (b.pr || 5) }),
    li = act.filter(function (f) { return f.tp !== 'fijo' && f.tp !== 'ahorro' });
  var h = '<div class="tiles">' + st('Total en fondos', cop(tot)) + st('Fondos activos', act.length) + '</div>' + fxHoyHTML() +
    '<button class="btn" style="margin-top:12px" onclick="fForm()">➕ Nuevo fondo</button>';
  if (!act.length) h += '<h2>🎯 Mis fondos</h2><div class="li"><small>Aún no tienes fondos. Crea uno de gasto fijo (casa, celular…) o de ahorro para una meta, como una moto.</small></div>';
  if (fj.length) h += '<h2>📌 Gastos fijos</h2>' + fj.map(fCard).join('');
  if (ah.length) h += '<h2>🎯 Ahorros</h2>' + ah.map(fCard).join('');
  if (li.length) h += '<h2>💰 Otros fondos</h2>' + li.map(fCard).join('');
  if (arc.length) {
    h += '<button class="btn out sm" onclick="fArch=!fArch;render()">' + (fArch ? '🔽' : '▶️') + ' 📦 Archivados (' + arc.length + ')</button>';
    if (fArch) h += arc.map(fCard).join('')
  }
  return h
}
/* ---------- detalle de un fondo ---------- */
function fMovLi(f, m) {
  var ic = m.tipo === 'aporte' ? '➕' : m.tipo === 'retiro' ? '➖' : '🏁', nm = m.tipo === 'aporte' ? 'Aporte' : m.tipo === 'retiro' ? 'Retiro' : 'Saldo inicial';
  var det = fd(m.t) + ' ' + hm(m.t) + ' · ' + (m.bil ? (m.tipo === 'retiro' ? 'a ' : 'de ') + esc(wl(m.bil)) : 'sin afectar billetera') + (m.nota && m.tipo !== 'inicial' ? ' · ' + esc(m.nota) : '');
  var acc = f.arch ? '' : m.tipo === 'inicial' ? '<div class="ab"><button class="ed" onclick="fForm(\'' + f.id + '\')">✏️ Editar</button></div>' : abtn("fMov('" + f.id + "','" + m.tipo + "','" + m.id + "')", "fMDel('" + m.id + "')", 'movimiento');
  return '<div class="li fh"><div class="wr" style="padding:0"><span class="ic">' + ic + '</span><div class="g"><b>' + nm + '</b><br><small>' + det + '</small></div><b class="big ' + (m.tipo === 'retiro' ? 'neg' : 'pos') + '">' + (m.tipo === 'retiro' ? '−' : '+') + cop(m.v) + '</b></div>' + acc + '</div>'
}
function vFondoDet() {
  var f = fById(fdet), s = fSaldo(f.id), p = fPct(f, s), ms = fMovs(f.id).sort(function (a, b) { return b.t - a.t || b.ua - a.ua }), tp = f.tp || 'libre',
    ic = f.ic || (tp === 'fijo' ? '📌' : tp === 'ahorro' ? '🎯' : '💰'), ok = tp === 'fijo' ? '✅ Listo para pagar' : '🎉 Meta alcanzada';
  var h = '<button class="btn out sm" onclick="fdet=null;render()">← Volver a fondos</button><h1>' + esc(ic) + ' ' + esc(f.nom) + (f.arch ? ' <span class="chip pause">📦 Archivado</span>' : '') + (f.pz ? ' <span class="chip pause">⏸️ Pausado</span>' : '') + '</h1>' +
    '<div class="hero"><small>Saldo actual</small><b>' + cop(s) + '</b><div class="sub"><span>🎯 ' + (tp === 'fijo' ? 'A pagar' : 'Objetivo') + '<br><b>' + (f.obj > 0 ? cop(f.obj) : 'Sin objetivo') + '</b></span><span>📊 Progreso<br><b>' + (p === null ? '—' : fp(p)) + '</b></span></div></div>';
  if (p !== null) h += '<div class="card" style="padding:12px 16px">' + fBar(p) + '<div class="row"><small>' + fp(p) + ' completado</small><small>' + (s >= f.obj ? ok : 'Faltan ' + cop(f.obj - s)) + '</small></div></div>';
  h += fxInfo(f);
  if (f.arch) h += '<div class="warn" style="margin-top:10px"><span>Este fondo está archivado. Desarchívalo para registrar aportes o retiros.</span></div>';
  else {
    h += '<div class="two" style="margin-top:12px"><button class="btn" onclick="fMov(\'' + f.id + '\',\'aporte\')">➕ Aportar</button><button class="btn out" onclick="fMov(\'' + f.id + '\',\'retiro\')">➖ Retirar</button></div>';
    if (tp === 'fijo') h += '<button class="btn" style="margin-top:8px" onclick="fxPagar(\'' + f.id + '\')">✅ Pagar ahora</button>';
    if (tp !== 'libre') h += '<button class="btn out sm" style="margin-top:8px" onclick="fxPausar(\'' + f.id + '\')">' + (f.pz ? '▶️ Reanudar' : '⏸️ Pausar') + ' este fondo</button>'
  }
  h += '<div class="two" style="margin-top:12px"><button class="btn out sm" onclick="fForm(\'' + f.id + '\')">✏️ Editar</button><button class="btn out sm" onclick="fArchivar(\'' + f.id + '\')">' + (f.arch ? '📤 Desarchivar' : '📦 Archivar') + '</button></div>' +
    '<button class="btn bad sm" onclick="fDelAsk(\'' + f.id + '\')">🗑️ Eliminar fondo</button>' +
    '<h2>📜 Historial (' + ms.length + ')</h2>';
  return h + (ms.length ? ms.map(function (m) { return fMovLi(f, m) }).join('') : '<div class="li"><small>Todavía no hay movimientos.</small></div>')
}
/* ---------- crear / editar fondo ---------- */
function fForm(id, tp0) {
  var f = id ? fById(id) : null, m = f ? fIni(id) : null;
  if (id && !f) return;
  var tp = f ? (f.tp || 'libre') : (tp0 || 'ahorro'), w = wal();
  var FQ = [['m', 'Cada mes'], ['q', 'Cada 15 días'], ['s', 'Cada semana'], ['a', 'Cada año'], ['u', 'Una sola vez']];
  openM('<h3>' + (f ? '✏️ Editar fondo' : '➕ Nuevo fondo') + '</h3>' +
    '<label>Tipo<select id="ftp" onchange="fxFormTipo(this.value)"><option value="ahorro"' + (tp === 'ahorro' ? ' selected' : '') + '>🎯 Ahorro con meta (moto, colchón…)</option><option value="fijo"' + (tp === 'fijo' ? ' selected' : '') + '>📌 Gasto fijo (casa, celular, cuota…)</option><option value="libre"' + (tp === 'libre' ? ' selected' : '') + '>💰 Fondo libre</option></select></label>' +
    '<label>Nombre<input id="fn" maxlength="40" value="' + esc(f ? f.nom : '') + '" placeholder="Ej. Moto nueva"></label>' +
    '<label>Emoji<input id="fic" maxlength="4" value="' + esc(f && f.ic ? f.ic : '') + '" placeholder="Opcional"></label>' +
    '<div id="fxF"><label>Monto a pagar<input id="fmo" type="number" inputmode="numeric" min="0" value="' + (f && f.mo > 0 ? f.mo : '') + '" placeholder="Ej. 99000"></label>' +
    '<label>Cada cuánto<select id="ffq">' + FQ.map(function (x) { return '<option value="' + x[0] + '"' + ((f && f.fq || 'm') === x[0] ? ' selected' : '') + '>' + x[1] + '</option>' }).join('') + '</select></label>' +
    '<label>📅 Próximo pago<input id="fpv" type="date" value="' + (f && f.pv ? iso(f.pv) : '') + '"></label>' +
    '<label>🔔 Avisarme antes (días, opcional)<input id="frd" type="number" inputmode="numeric" min="1" value="' + (f && f.rd > 0 ? f.rd : '') + '" placeholder="Usa el aviso general"></label></div>' +
    '<div id="fxO"><label>Objetivo (opcional)<input id="fo" type="number" inputmode="numeric" min="0" value="' + (tp !== 'fijo' && f && f.obj > 0 ? f.obj : '') + '" placeholder="Ej. 5000000"></label>' +
    '<label>Recordarme aportar cada (días, opcional)<input id="ff" type="number" inputmode="numeric" min="0" value="' + (f && f.fr > 0 ? f.fr : '') + '" placeholder="Ej. 7"></label></div>' +
    '<div id="fxA"><label>Cómo apartas<select id="fam"><option value="d"' + (!(f && f.ap > 0) ? ' selected' : '') + '>Monto fijo por día</option><option value="p"' + (f && f.ap > 0 ? ' selected' : '') + '>% de lo que gano en el día</option></select></label>' +
    '<label>Monto por día, o % (déjalo vacío si prefieres decidir cada vez)<input id="fav" type="number" inputmode="decimal" min="0" value="' + (f && f.ap > 0 ? f.ap : f && f.ad > 0 ? f.ad : '') + '" placeholder="Ej. 10000 o 10"></label>' +
    '<label>📅 Fecha meta (opcional)<input id="ffl" type="date" value="' + (f && f.fl ? iso(f.fl) : '') + '"></label></div>' +
    '<label>' + (f ? 'Saldo inicial' : 'Saldo actual') + '<input id="fs" type="number" inputmode="numeric" min="0" value="' + (m ? m.v : '') + '" placeholder="0"></label>' +
    '<small style="display:block;margin:-4px 0 12px">' + (f ? 'Los aportes y retiros se registran aparte, en el historial.' : 'Lo que ya tienes guardado en este fondo. No cambia tus billeteras.') + '</small>' +
    '<div id="fxP"><label>Prioridad al apartar (1 = primero)<input id="fpr" type="number" inputmode="numeric" min="1" max="9" value="' + (f && f.pr ? f.pr : 5) + '"></label>' +
    '<label>Billetera de donde apartas<select id="fbl"><option value="">Preguntar cada vez</option>' + bilOpts([f && f.bl || '']).map(function (b) { return '<option value="' + esc(b) + '"' + (f && f.bl === b ? ' selected' : '') + '>' + esc(wl(b)) + '</option>' }).join('') + '</select></label></div>' +
    btns("fSave('" + (id || '') + "')"));
  fxFormTipo(tp)
}
function fSave(id) {
  var tp = $('#ftp').value, nom = $('#fn').value.trim(), rs = $('#fs').value, ini = rs === '' ? 0 : num('#fs'), ic = ($('#fic').value || '').trim().slice(0, 4);
  if (!nom) { toast('Escribe un nombre para el fondo'); return }
  if (nom.length > 40) { toast('El nombre es muy largo (máximo 40)'); return }
  if (ini === null || ini < 0) { toast('Revisa el saldo'); return }
  var o = { tp: tp === 'libre' ? null : tp, ic: ic || null, obj: null, fr: null, mo: null, fq: null, pv: null, dp: null, rd: null, ad: null, ap: null, fl: null };
  if (tp === 'fijo') {
    var rmo = $('#fmo').value, mo = rmo === '' ? null : num('#fmo'), rpv = $('#fpv').value, pv = rpv ? pd(rpv) : null, rrd = $('#frd').value, rd = rrd === '' ? null : num('#frd');
    if (rmo !== '' && !(mo > 0)) { toast('El monto a pagar debe ser mayor que 0, o déjalo vacío'); return }
    if (rpv && isNaN(pv)) { toast('Revisa la fecha del próximo pago'); return }
    if (rrd !== '' && !(rd >= 1)) { toast('Los días de aviso deben ser 1 o más, o déjalo vacío'); return }
    o.mo = mo; o.obj = mo; o.fq = $('#ffq').value; o.pv = pv; o.dp = pv ? new Date(pv).getDate() : null; o.rd = rd
  } else {
    var ro = $('#fo').value, obj = ro === '' ? null : num('#fo'), rfr = $('#ff').value, fr = rfr === '' ? null : num('#ff');
    if (ro !== '' && !(obj > 0)) { toast('El objetivo debe ser mayor que 0, o déjalo vacío'); return }
    if (rfr !== '' && !(fr > 0)) { toast('Los días del recordatorio deben ser mayores que 0, o déjalo vacío'); return }
    o.obj = obj; o.fr = fr;
    if (tp === 'ahorro') {
      var rv = $('#fav').value, v = rv === '' ? null : num('#fav'), rfl = $('#ffl').value, fl = rfl ? pd(rfl) : null;
      if (rv !== '' && !(v > 0)) { toast('El monto o el % por día debe ser mayor que 0, o déjalo vacío'); return }
      if ($('#fam').value === 'p' && v > 100) { toast('El porcentaje no puede pasar de 100'); return }
      if (rfl && isNaN(fl)) { toast('Revisa la fecha meta'); return }
      if ($('#fam').value === 'p') o.ap = v; else o.ad = v;
      o.fl = fl
    }
  }
  var rpr = $('#fpr').value, pr = rpr === '' ? 5 : num('#fpr'), bl = $('#fbl').value;
  if (!(pr >= 1 && pr <= 9)) { toast('La prioridad va de 1 a 9'); return }
  if (BILX.indexOf(bl) < 0) bl = '';
  if (fFondos().some(function (x) { return x.id !== id && x.nom.toLowerCase() === nom.toLowerCase() })) { toast('Ya existe un fondo con ese nombre'); return }
  fEns(); var n = Date.now(), f = id ? fById(id) : null;
  if (id && !f) { closeM(); return }
  function poner(f) { Object.keys(o).forEach(function (k) { if (o[k] == null) delete f[k]; else f[k] = o[k] }); f.pr = pr; if (bl) f.bl = bl; else delete f.bl }
  if (!f) {
    f = { id: uid(), nom: nom, arch: false, ca: n, ua: n }; poner(f); S.fo.push(f);
    if (ini > 0) S.fm.push({ id: uid(), fid: f.id, t: n, tipo: 'inicial', v: ini, bil: null, nota: 'Saldo inicial', ua: n })
  } else {
    var m = fIni(id), base = fSaldo(id) - (m ? m.v : 0);
    if (base + ini < 0) { toast('Con ese saldo inicial el fondo quedaría en negativo'); return }
    f.nom = nom; f.ua = n; poner(f);
    if (m && ini > 0) { m.v = ini; m.ua = n }
    else if (m) S.fm = S.fm.filter(function (x) { return x.id !== m.id })
    else if (ini > 0) S.fm.push({ id: uid(), fid: id, t: f.ca || n, tipo: 'inicial', v: ini, bil: null, nota: 'Saldo inicial', ua: n })
  }
  sv(); closeM(); render(); toast(id ? '✅ Fondo actualizado' : '✅ Fondo creado')
}
/* ---------- aportes y retiros ---------- */
function fMov(fid, tipo, mid) {
  var f = fById(fid), m = mid ? fMById(mid) : null;
  if (!f || (mid && !m) || f.arch) return;
  var w = wal(), ap = tipo === 'aporte', b0 = m ? (m.bil || '') : fLastBil;
  openM('<h3>' + (m ? '✏️ Editar ' : ap ? '➕ Aportar a ' : '➖ Retirar de ') + (m ? (ap ? 'aporte' : 'retiro') : esc(f.nom)) + '</h3>' +
    '<label>Valor<input id="fv" type="number" inputmode="numeric" min="0" value="' + (m ? m.v : '') + '" placeholder="0"></label>' +
    '<label>' + (ap ? '¿De qué billetera sale el dinero?' : '¿A qué billetera entra el dinero?') + '<select id="fb"><option value=""' + (b0 === '' ? ' selected' : '') + '>Sin afectar billetera</option>' +
    bilOpts([b0]).map(function (b) { return '<option value="' + b + '"' + (b0 === b ? ' selected' : '') + '>' + esc(wl(b)) + ' (' + cop(w[b].s) + ')</option>' }).join('') + '</select></label>' +
    '<small style="display:block;margin:-4px 0 12px">' + (ap ? 'Si eliges una billetera, el valor se descuenta de ella.' : 'Si eliges una billetera, el valor se suma a ella.') + ' Con “Sin afectar billetera” solo se registra en el fondo.</small>' +
    '<label>Fecha y hora<input id="ft" type="datetime-local" value="' + ldt(m ? m.t : Date.now()) + '"></label>' +
    '<label>Nota (opcional)<input id="fnt" maxlength="80" value="' + esc(m ? m.nota : '') + '"></label>' + btns("fMovSave('" + fid + "','" + tipo + "','" + (mid || '') + "')"))
}
function fMovSave(fid, tipo, mid) {
  var f = fById(fid), m = mid ? fMById(mid) : null;
  if (!f || (mid && !m)) { closeM(); return }
  var v = num('#fv'), t = pdt($('#ft').value), bil = $('#fb').value, nota = $('#fnt').value.trim().slice(0, 80);
  if (!(v > 0) || t === null) { toast('Revisa el valor y la fecha'); return }
  if (BILX.indexOf(bil) < 0) bil = '';
  var sg = tipo === 'retiro' ? -1 : 1, base = fSaldo(fid) - (m ? fSig(m) : 0);
  if (base + sg * v < 0) { toast(tipo === 'retiro' ? 'El retiro supera el saldo del fondo (' + cop(base) + ')' : 'Con ese valor el fondo quedaría en negativo'); return }
  var n = Date.now();
  if (m) { m.v = v; m.t = t; m.bil = bil || null; m.nota = nota; m.ua = n }
  else {
    var l = fMovs(fid).sort(function (a, b) { return b.ua - a.ua })[0];
    if (l && l.tipo === tipo && l.v === v && (l.bil || '') === bil && n - l.ua < 3000) { toast('Movimiento repetido, ignorado'); return }
    fEns(); S.fm.push({ id: uid(), fid: fid, t: t, tipo: tipo, v: v, bil: bil || null, nota: nota, ua: n })
  }
  f.ua = n; fLastBil = bil; sv(); closeM(); render();
  var neg = bil && wal()[bil].s < 0;
  toast(neg ? '⚠️ Guardado. ' + bil + ' quedó en ' + cop(wal()[bil].s) : '✅ Guardado')
}
function fMDel(mid) {
  var m = fMById(mid); if (!m) return;
  if (m.tipo !== 'retiro' && fSaldo(m.fid) - m.v < 0) { toast('No se puede eliminar: el fondo quedaría en negativo'); return }
  S.fm = S.fm.filter(function (x) { return x.id !== mid }); var f = fById(m.fid); if (f) f.ua = Date.now();
  sv(); render()
}

/* ---------- archivar y eliminar ---------- */
function fArchivar(id) {
  var f = fById(id); if (!f) return;
  f.arch = !f.arch; f.ua = Date.now(); sv();
  if (f.arch) fdet = null;
  render(); toast(f.arch ? '📦 Fondo archivado' : '📤 Fondo desarchivado')
}
function fDelAsk(id) {
  var f = fById(id); if (!f) return;
  var ms = fMovs(id), cb = ms.filter(function (m) { return m.bil }).length;
  openM('<h3>¿Eliminar “' + esc(f.nom) + '”?</h3><p>Se borrará el fondo y sus ' + ms.length + ' movimiento(s) del historial.' +
    (cb ? ' <b>' + cb + ' de ellos afectaron billeteras: esas billeteras volverán al saldo que tendrían sin esos movimientos.</b>' : '') +
    ' Esta acción no se puede deshacer.</p><p><small>Si solo quieres ocultarlo, usa “Archivar”.</small></p>' +
    '<div class="two"><button class="btn out" onclick="closeM()">Cancelar</button><button class="btn bad" onclick="fDel(\'' + id + '\')">Eliminar</button></div>')
}
function fDel(id) {
  S.fm = (S.fm || []).filter(function (m) { return m.fid !== id }); S.fo = (S.fo || []).filter(function (f) { return f.id !== id });
  fdet = null; sv(); closeM(); render(); toast('🗑️ Fondo eliminado')
}
