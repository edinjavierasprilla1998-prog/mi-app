/* Finanzas + Jornada — ajustes.js: exportar copia (exportBackup) y vista de Ajustes. Separado de index.html en la Etapa 1, sin cambios de lógica. */
function exportBackup(){try{
var raw=null;try{raw=localStorage.getItem(K)}catch(e){}
var data=raw?JSON.parse(raw):S,otras={};
try{for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);if(k!==K)otras[k]=localStorage.getItem(k)}}catch(e){}
var pk={app:'Finanzas + Jornada',tipo:'copia-de-seguridad',version:1,exportado:new Date().toISOString(),claveLocal:K,
resumen:{jornadas:(data.j||[]).length,carreras:(data.j||[]).reduce(function(a,j){return a+(j.ca||[]).length},0),pausas:(data.j||[]).reduce(function(a,j){return a+(j.pa||[]).length},0),movimientos:(data.mv||[]).length},
datos:data,otrasClavesLocalStorage:otras};
var blob=new Blob([JSON.stringify(pk,null,2)],{type:'application/json'}),u=URL.createObjectURL(blob),a=document.createElement('a');
a.href=u;a.download='finanzas-jornada-backup-'+iso(Date.now())+'.json';a.style.display='none';document.body.appendChild(a);a.click();
setTimeout(function(){document.body.removeChild(a);URL.revokeObjectURL(u)},4000);
bkMarca();toast('✅ Copia de seguridad creada correctamente')}catch(e){toast('No se pudo crear la copia de seguridad')}}
function vCfg(){return '<h1>⚙️ Configuración</h1><div class="card form"><label>Tema<select onchange="setTema(this.value)">'+['sistema','claro','oscuro'].map(function(t){return '<option'+(S.tema===t?' selected':'')+'>'+t+'</option>'}).join('')+'</select></label><label>Moneda<select disabled><option>COP ($)</option></select></label><small>Los datos se guardan solo en este navegador, sin cuenta ni nube.</small></div>'+avCfgHTML()+ctlHTML()+gpCfgHTML()+ccCfgHTML()+bkHTML()+cpCfgHTML()+'<h2>Datos y respaldo</h2><div class="card form"><button class="btn out" onclick="exportBackup()">☁️ Exportar copia de seguridad</button><div style="height:8px"></div><small>Descarga un archivo con todos tus datos. No modifica ni borra nada de la app.</small></div>'+fjSegHTML()+borrarHTML()}
