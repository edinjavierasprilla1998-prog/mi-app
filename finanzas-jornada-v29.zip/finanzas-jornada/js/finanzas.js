/* Finanzas + Jornada — finanzas.js: pestaña 💰 Finanzas con sus subpestañas.
   Fondos (Etapa 2) · Deudas y Préstamos (Etapa 3, cuentas.js) · Presupuesto (Etapa 4, presupuesto.js). */
var fsub = 'billeteras', fdet = null, fArch = false;
var FSUB = [['billeteras', '👛', 'Billeteras'], ['apps', '📲', 'Apps'], ['fondos', '🎯', 'Fondos'], ['deudas', '🤝', 'Deudas'], ['cobros', '⏳', 'Por cobrar'], ['presupuesto', '📊', 'Presupuesto']];
function fsel(s) { fsub = s; fdet = null; cdet = null; adet = null; render() }
function vFin() {
  if (fsub === 'fondos' && fdet && fById(fdet)) return vFondoDet();
  fdet = null;
  if ((fsub === 'deudas' || fsub === 'prestamos' || fsub === 'cobros') && cdet && cuById(CU[fsub], cdet)) return vCuentaDet(fsub);
  cdet = null;
  if (fsub === 'prestamos') fsub = 'cobros';
  if (fsub === 'apps' && adet && apById(adet)) return vApDet(apById(adet));
  adet = null;
  var h = '<h1>💰 Finanzas</h1><div class="seg s4 s6">' + FSUB.map(function (x) {
    return '<button class="' + (fsub === x[0] ? 'on' : '') + '" onclick="fsel(\'' + x[0] + '\')"><span>' + icoE(x[1]) + '</span>' + x[2] + '</button>'
  }).join('') + '</div>';
  if (fsub === 'billeteras') return h + vBil();
  if (fsub === 'apps') return h + vApps();
  if (fsub === 'fondos') return h + vFondos();
  if (fsub === 'deudas' || fsub === 'prestamos' || fsub === 'cobros') return h + vCuentas(fsub);
  return h + vPresup()
}
