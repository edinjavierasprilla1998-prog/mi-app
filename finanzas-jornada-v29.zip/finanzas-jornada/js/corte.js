/* Corte y cierre con saldos (fj-v29).
   S.sn = fotos de saldo [{id,t,w:{billetera:real},a:{appId:real}}]; S.cc = ajustes {um,mn,be}; S.cd = días cerrados ['YYYY-MM-DD'].
   Escribes lo que tienes de verdad; la diferencia con lo que calcula la app se explica (carreras, gasto olvidado, pase, comisión…)
   y SOLO al guardar se registra. Cada corte deja los saldos cuadrados: el siguiente solo ve lo que pasó desde entonces. */
var CT = null;
var CCL = { car: '🚕 Carreras', ing: '💰 Otro ingreso', aj: '⚖️ Ajuste', gas: '🧾 Gasto olvidado', gp: '🧾', prem: '🎁 Premio', pase: '🎟️ Pase 24 h', com: '➖ Comisión' };
function ccCfg() { var c = S.cc || {}; return { um: c.um > 0 ? +c.um : 50000, mn: c.mn === 0 ? 0 : (c.mn > 0 ? +c.mn : 120), be: c.be > 0 ? +c.be : 0 } }
function ccSet(k, v) { var n = parseFloat(v); S.cc = Object.assign({}, S.cc); S.cc[k] = n >= 0 ? Math.round(n) : 0; sv(); render() }
function ccSnaps() { return Array.isArray(S.sn) ? S.sn : [] }
function ccLast() { var l = ccSnaps(); return l.length ? l[l.length - 1] : null }
function ccRound(x) { return Math.round(x * 100) / 100 }
function ccFilas() {
  var w = wal(), r = [];
  bilVis(w).forEach(function (b) { r.push({ k: 'w', id: b, nom: wl(b), calc: ccRound(w[b].s), real: '', acts: [] }) });
  apList().filter(function (a) { return !a.arch }).forEach(function (a) { r.push({ k: 'a', id: a.id, nom: a.nom, calc: ccRound(apSaldo(a.id)), real: '', acts: [] }) });
  return r
}
function ccReal(r) { if (r.real === '' || r.real == null || isNaN(r.real)) return null; var v = +r.real; if (r.k === 'w' && r.id === 'Efectivo') v -= ccCfg().be; return v }
function ccRem(r) { var rl = ccReal(r); if (rl === null) return null; var s = 0; r.acts.forEach(function (a) { s += a.sg * a.v }); return ccRound(rl - r.calc - s) }
function ccDiaDef() {
  var l = ccLast(), n = Date.now(); if (!l || dk(l.t) === dk(n)) return 'hoy';
  var hoy = S.j.some(function (j) { return dk(j.ini) === dk(n) }) || S.mv.some(function (m) { return dk(m.t) === dk(n) });
  return hoy ? 'hoy' : 'ayer'
}
function ccAyerTs() {
  var n = Date.now(), lim = d0(n) - 1000, t = 0;
  S.j.forEach(function (j) { if (j.ini < d0(n)) { var e = j.fin || j.ini; j.ca.forEach(function (c) { if (c.t > e) e = c.t }); if (e > t) t = e } });
  return t ? Math.min(t, lim) : d0(n) - 3600000
}
/* ---------- ventana del corte ---------- */
function ccAbrir(dia) { CT = { rows: ccFilas(), dia: dia || ccDiaDef(), cierra: false }; ccDraw() }
function ccDraw() {
  var l = ccLast(), n = Date.now(), c = ccCfg();
  var h = '<h3>✂️ Corte de saldos</h3><small>Escribe lo que tienes <b>de verdad</b> ahora. Lo que no escribas se deja igual. No se guarda nada hasta que toques Guardar corte.</small>';
  if (l && dk(l.t) !== dk(n)) h += '<div style="margin:8px 0"><small style="display:block;font-weight:600">Las diferencias son de:</small><div class="seg"><button class="' + (CT.dia === 'ayer' ? 'on' : '') + '" onclick="ccDia(\'ayer\')">Ayer</button><button class="' + (CT.dia === 'hoy' ? 'on' : '') + '" onclick="ccDia(\'hoy\')">Hoy</button></div></div>';
  h += CT.rows.map(function (r, i) {
    var ef = r.k === 'w' && r.id === 'Efectivo' && c.be > 0;
    return '<div style="padding:8px 0;border-top:1px solid var(--s2)"><div class="kv"><span>' + (r.k === 'a' ? '💳 ' : '') + esc(r.nom) + '</span><small>La app calcula ' + cop(ef ? r.calc + c.be : r.calc) + '</small></div>' +
      '<input id="ccv' + i + '" type="number" inputmode="decimal" placeholder="' + (ef ? 'Efectivo en mano (con tu base de ' + cop(c.be) + ')' : 'Lo que tienes ahora') + '" value="' + esc(r.real) + '" oninput="ccIn(' + i + ',this.value)"><div id="ccx' + i + '"></div></div>'
  }).join('');
  h += '<label class="ck" style="margin-top:8px"><input type="checkbox" ' + (CT.cierra ? 'checked' : '') + ' onchange="CT.cierra=this.checked"> <span>Este corte cierra el día</span></label>' +
    '<div class="two"><button class="btn out" onclick="CT=null;closeM()">Cancelar</button><button class="btn" onclick="ccGuardar()">Guardar corte</button></div>';
  openM(h); CT.rows.forEach(function (r, i) { ccPaint(i) })
}
function ccDia(d) { CT.dia = d; ccDraw() }
function ccIn(i, v) { CT.rows[i].real = v; ccPaint(i) }
function ccPaint(i) {
  var r = CT.rows[i], e = $('#ccx' + i); if (!e) return; var rem = ccRem(r);
  if (rem === null) { e.innerHTML = ''; return }
  var h = r.acts.map(function (a, j) { return ccActHTML(r, i, a, j) }).join('');
  if (Math.abs(rem) < 0.5) h += '<small>✅ Cuadra</small>';
  else {
    var pos = rem > 0;
    h += '<small class="' + (pos ? 'pos' : 'neg') + '" style="display:block;margin:4px 0">' + (pos ? 'Tienes ' + cop(rem) + ' más' : 'Tienes ' + cop(-rem) + ' menos') + ' de lo que calcula la app. ¿Qué fue?</small><div style="display:flex;gap:6px;flex-wrap:wrap">';
    var ch = r.k === 'w' ? (pos ? ['car', 'ing', 'aj'] : ['gas', 'aj']) : (pos ? ['car', 'prem', 'aj'] : ['pase', 'com', 'aj']);
    h += ch.map(function (t) { return '<button class="btn out sm" style="width:auto;padding:6px 10px" onclick="ccAdd(' + i + ',\'' + t + '\')">' + CCL[t] + '</button>' }).join('');
    if (r.k === 'w' && !pos && CT.dia === 'hoy') {
      var P = gpPend().filter(function (x) { return x.due }).sort(function (a, b) { return (gpBil(b.g) === r.id) - (gpBil(a.g) === r.id) }).slice(0, 3);
      h += P.map(function (x) { return '<button class="btn out sm" style="width:auto;padding:6px 10px" onclick="ccAdd(' + i + ',\'gp\',\'' + x.g.id + '\')">¿Fue ' + esc(x.g.n) + '? ' + cop(x.g.m) + '</button>' }).join('')
    }
    h += '</div>'
  }
  e.innerHTML = h
}
function ccActHTML(r, i, a, j) {
  var g = a.t === 'gp' ? gpById(a.gid) : null, lb = a.t === 'gp' ? '🧾 ' + esc(g ? g.n : 'Gasto') : CCL[a.t], x = '';
  if (a.t === 'car' && r.k === 'w') x = '<select onchange="ccAct(' + i + ',' + j + ',\'ap\',this.value)">' + vjApps().map(function (p) { return '<option value="' + p.id + '"' + (p.id === a.ap ? ' selected' : '') + '>' + esc(p.nom) + '</option>' }).join('') + '</select>';
  if (a.t === 'gas') x = '<div class="two"><select onchange="ccAct(' + i + ',' + j + ',\'k\',this.value);ccPaint(' + i + ')"><option value="p"' + (a.k === 'p' ? ' selected' : '') + '>👤 Personal</option><option value="o"' + (a.k === 'o' ? ' selected' : '') + '>🏍️ Operativo</option></select><select onchange="ccAct(' + i + ',' + j + ',\'cat\',this.value)">' + ppCats(a.k === 'o' ? 'costo' : 'personal').map(function (c) { return '<option' + (c === a.cat ? ' selected' : '') + '>' + esc(c) + '</option>' }).join('') + '</select></div>';
  if (a.t === 'com' && r.k === 'a' && apPaseAct(r.id)) x = '<small class="neg">⚠️ Tienes pase activo: esto es un cobro fuera de tu pase.</small>';
  return '<div style="margin:6px 0;padding:6px;border-radius:10px;background:var(--s2)"><div class="kv"><span>' + lb + '</span><b><input type="number" inputmode="decimal" style="width:110px" value="' + a.v + '" onchange="ccActV(' + i + ',' + j + ',this.value)"> <button class="mini bad" onclick="ccDel(' + i + ',' + j + ')">✕</button></b></div>' + x + '</div>'
}
function ccAdd(i, t, gid) {
  var r = CT.rows[i], rem = ccRem(r); if (rem === null || Math.abs(rem) < 0.5) return;
  var a = { t: t, v: Math.abs(rem), sg: rem > 0 ? 1 : -1 };
  if (t === 'gp') { var g = gpById(gid); if (!g) return; a.gid = gid; a.v = Math.min(g.m, Math.abs(rem)); a.sg = -1 }
  if (t === 'car' && r.k === 'w') a.ap = vjApSel();
  if (t === 'gas') { a.k = 'p'; a.cat = ppCats('personal')[0] }
  r.acts.push(a); ccPaint(i)
}
function ccAct(i, j, k, v) { var a = CT.rows[i].acts[j]; if (!a) return; a[k] = v; if (k === 'k') a.cat = ppCats(v === 'o' ? 'costo' : 'personal')[0] }
function ccActV(i, j, v) { var a = CT.rows[i].acts[j], n = Math.abs(parseFloat(v)); if (!a) return; if (!(n > 0)) CT.rows[i].acts.splice(j, 1); else a.v = ccRound(n); ccPaint(i) }
function ccDel(i, j) { CT.rows[i].acts.splice(j, 1); ccPaint(i) }
/* ---------- aplicar ---------- */
function ccJornada(ts, hoy) {
  var a = act(); if (a && hoy) return a;
  var l = S.j.filter(function (j) { return dk(j.ini) === dk(ts) }); if (l.length) return l[l.length - 1];
  var j = { id: uid(), ini: ts, fin: ts + 1, hp: 1, mt: 't', pv: [], ki: 0, kf: 0, fin_: 0, pa: [], ca: [], man: 1 }; delete j.fin_; S.j.push(j); return j
}
function ccBloque(ts, hoy, ap, lines, v) { ccJornada(ts, hoy).ca.push({ id: uid(), t: ts, v: v, p: 0, ap: ap, pg: lines, tf: v, cm: 0, pb: null, bl: 1 }) }
function ccGuardar() {
  var any = false, bad = null;
  CT.rows.forEach(function (r) { var rem = ccRem(r); if (rem === null) return; any = true; if (Math.abs(rem) >= 0.5 && !bad) bad = r.nom + ': falta explicar ' + cop(Math.abs(rem)) });
  if (!any) { toast('Escribe al menos un saldo'); return }
  if (bad) { toast(bad); return }
  var n = Date.now(), hoy = CT.dia === 'hoy', ts = hoy ? n : ccAyerTs(), snap = { id: uid(), t: n, w: {}, a: {} }, nb = 0;
  if (!Array.isArray(S.am)) S.am = [];
  CT.rows.forEach(function (r) {
    var rl = ccReal(r); if (rl === null) return;
    (r.k === 'w' ? snap.w : snap.a)[r.id] = ccRound(rl);
    r.acts.forEach(function (a) {
      nb++;
      if (r.k === 'w') {
        if (a.t === 'car') ccBloque(ts, hoy, a.ap || vjApSel(), [{ k: 'b', b: r.id, v: a.v }], a.v);
        else if (a.t === 'ing') S.mv.push({ id: uid(), cr: n, t: ts, tipo: 'ingreso', cat: 'Ingreso', bil: r.id, bil2: null, v: a.v, nota: 'Corte de saldos' });
        else if (a.t === 'aj') S.mv.push({ id: uid(), cr: n, t: ts, tipo: 'ajuste', cat: 'Ajuste', bil: r.id, bil2: null, sg: a.sg, v: a.v, nota: 'Corte de saldos' });
        else if (a.t === 'gas') S.mv.push({ id: uid(), cr: n, t: ts, tipo: a.k === 'o' ? 'costo' : 'personal', cat: a.cat || 'Otros', bil: r.id, bil2: null, v: a.v, nota: 'Gasto olvidado (corte)' });
        else if (a.t === 'gp') { var g = gpById(a.gid); if (g && !gpEst(g, n)) gpCrear(g, a.v, r.id, null) }
      } else {
        if (a.t === 'car') ccBloque(ts, hoy, r.id, [{ k: 'a', v: a.v }], a.v);
        else {
          var tipo = a.t === 'prem' ? 'premio' : a.t === 'pase' ? 'recarga' : a.t === 'com' ? 'comision' : 'ajuste';
          var m = { id: uid(), aid: r.id, t: ts, tipo: tipo, v: a.v, sg: a.sg, bil: null, nota: 'Corte de saldos', ua: n };
          if ((a.t === 'com' || a.t === 'pase') && apPaseAct(r.id)) m.ex = 1;
          S.am.push(m)
        }
      }
    })
  });
  if (!Array.isArray(S.sn)) S.sn = []; S.sn.push(snap); if (S.sn.length > 60) S.sn = S.sn.slice(-60);
  if (CT.cierra) { if (!Array.isArray(S.cd)) S.cd = []; var dkk = iso(hoy ? n : ts); if (S.cd.indexOf(dkk) < 0) S.cd.push(dkk) }
  CT = null; sv(); closeM(); render(); toast('✂️ Corte guardado' + (nb ? ' · ' + nb + ' ajuste' + (nb === 1 ? '' : 's') : ' · todo cuadraba'))
}
/* ---------- arranque de un toque ---------- */
function ccIgual() {
  var l = ccLast(), n = Date.now(), s = { id: uid(), t: n, w: {}, a: {} }, w = wal();
  Object.keys(l.w || {}).forEach(function (b) { if (w[b]) s.w[b] = ccRound(w[b].s) });
  Object.keys(l.a || {}).forEach(function (a) { if (apById(a)) s.a[a] = ccRound(apSaldo(a)) });
  if (!Array.isArray(S.sn)) S.sn = []; S.sn.push(s); sv(); render(); toast('☀️ Listo: saldos confirmados')
}
function ccArranque() {
  var l = ccLast(), n = Date.now(); if (!l || dk(l.t) === dk(n)) return '';
  var w = wal(), p = [];
  Object.keys(l.w || {}).forEach(function (b) { if (w[b]) p.push(esc(wl(b)) + ' ' + cop(w[b].s)) });
  Object.keys(l.a || {}).forEach(function (a) { if (apById(a)) p.push(esc(apNom(a)) + ' ' + cop(apSaldo(a))) });
  return '<div style="padding-bottom:10px;border-bottom:1px solid var(--s2);margin-bottom:10px"><b>☀️ Arranque del día</b><br><small>Saldos de ayer: ' + p.join(' · ') + '</small><div class="two" style="margin-top:6px"><button class="btn sm" onclick="ccIgual()">✅ Siguen igual</button><button class="btn out sm" onclick="ccAbrir(\'ayer\')">✏️ Corregir</button></div></div>'
}
function ccExtra(dias) {
  var a = Date.now() - dias * 86400000, o = {}, t = 0;
  (S.am || []).forEach(function (m) { if (m.ex === 1 && m.t >= a) { o[m.aid] = (o[m.aid] || 0) + m.v; t += m.v } });
  return { t: t, o: o }
}
function ccHTML() {
  var l = ccLast(), n = Date.now(), c = ccCfg(), ex = ccExtra(30), h = '<h2>✂️ Corte de saldos</h2><div class="card">' + ccArranque();
  h += '<small>' + (l ? 'Último corte: ' + (dk(l.t) === dk(n) ? 'hoy ' : fd(l.t) + ' ') + hm(l.t) : 'Aún no has hecho un corte. Escribe lo que tienes en cada billetera y app, y la app deduce las carreras por forma de pago.') + '</small>';
  if (l && l.a) {
    var s = Object.keys(l.a).filter(function (a) { return apById(a) }).map(function (a) { return esc(apNom(a)) + ' ≈ ' + cop(l.a[a] + c.um) });
    if (s.length) h += '<br><small>Siguiente corte sugerido cuando el saldo pase de: ' + s.join(' · ') + '</small>'
  }
  if (S.cd && S.cd.indexOf(iso(n)) >= 0) h += '<br><small>✅ Día cerrado</small>';
  if (ex.t > 0) h += '<br><small class="neg">⚠️ Cobros fuera del pase (30 días): ' + Object.keys(ex.o).map(function (a) { return esc(apNom(a)) + ' ' + cop(ex.o[a]) }).join(' · ') + '</small>';
  return h + '<button class="btn" style="margin-top:10px" onclick="ccAbrir()">✂️ Hacer corte</button></div>'
}
function ccAvisos() {
  var A = [], j = act(), n = Date.now(), c = ccCfg(); if (!j) return A;
  var l = ccLast(), ref = l && l.t > j.ini ? l.t : j.ini, ab = j.pa.filter(function (p) { return !p.b })[0];
  if (ab) { if (n - ref >= 20 * 60000) A.push({ k: 'ccp' + ab.id, sev: 1, ic: '✂️', tx: 'Aprovecha la pausa para hacer un corte', sub: 'Son 30 segundos: escribes lo que tienes y la app deduce las carreras.', t: n, hr: 0, go: ['jornada', null, null, null] }); return A }
  if (c.mn > 0 && n - ref >= c.mn * 60000) A.push({ k: 'cc' + j.id + '_' + ref, sev: 1, ic: '✂️', tx: 'Toca hacer un corte de saldos', sub: 'Llevas ' + dm(n - ref) + ' desde el ' + (l && l.t > j.ini ? 'último corte' : 'inicio') + '.', t: n, hr: 0, go: ['jornada', null, null, null] });
  return A
}
function ccCfgHTML() {
  var c = ccCfg();
  return '<h2>✂️ Cortes de saldos</h2><div class="card form"><label>Sugerir el siguiente corte cuando una app suba (pesos)<input type="number" inputmode="numeric" min="0" value="' + c.um + '" onchange="ccSet(\'um\',this.value)"></label>' +
    '<label>Avisar si pasan estos minutos sin corte (0 = no avisar)<input type="number" inputmode="numeric" min="0" value="' + c.mn + '" onchange="ccSet(\'mn\',this.value)"></label>' +
    '<label>Base de efectivo (cambio que siempre llevas, no cuenta como ganancia)<input type="number" inputmode="numeric" min="0" value="' + (c.be || '') + '" onchange="ccSet(\'be\',this.value)"></label></div>'
}
