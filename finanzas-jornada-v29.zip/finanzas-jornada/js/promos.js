/* Finanzas + Jornada — promos.js (Etapa 9): promociones e incentivos de las apps (DiDi, Uber…).
   Todo es aditivo: no cambia ni borra datos existentes. Campos nuevos en S: px (promociones), pxc (config de avisos), pxr (revisado hoy).
   S.px[i] = { id, aid, nom, tp:'meta'|'bono', d (día, 00:00), h1,h2 (minutos del día),
     meta:  tr:[{n,v}]  → al llegar a n viajes el premio total es v
     bono:  bf:'f'|'p' (monto fijo por viaje | % de la tarifa), bv, mn (viajes que no cuentan al inicio)
     registro previo: rq (hay que registrarse/activarla), rl (fecha límite), rk (cuándo marcaste «ya me registré»), rh (horas de aviso propias)
     aj (ajuste manual del conteo), pe:'esp' + pv (premio esperado), pid (id del premio ya registrado en S.am), x (sin premio / descartada) }
   El conteo y el premio estimado se CALCULAN de los viajes registrados; nunca se guardan. El premio recibido es un movimiento «premio» normal de la app. */
var PXHS = [18, 19, 21], pxOld = false;
function pxCfg() {
  var c = S.pxc || {}, hs = Array.isArray(c.hs) ? c.hs.filter(function (h) { return h === Math.floor(h) && h >= 0 && h <= 23 }) : PXHS.slice();
  hs = hs.filter(function (h, i) { return hs.indexOf(h) === i }).sort(function (a, b) { return a - b });
  return { hs: hs, cerca: c.cerca > 0 ? Math.floor(c.cerca) : 3 }
}
function pxList(aid) { return (S.px || []).filter(function (p) { return p && (!aid || p.aid === aid) }) }
function pxById(id) { return (S.px || []).filter(function (p) { return p.id === id })[0] }
function pxNom(p) { return p.nom || (p.tp === 'meta' ? 'Meta de viajes' : 'Bono por viaje') }
function pxMin(s) { var m = /^(\d{1,2}):(\d{2})$/.exec(s || ''); if (!m) return null; var h = +m[1], n = +m[2]; return h <= 23 && n <= 59 ? h * 60 + n : null }
function pxHHMM(min) { return String(Math.floor(min / 60)).padStart(2, '0') + ':' + String(min % 60).padStart(2, '0') }
function pxHora(h) { return (h % 12 || 12) + ':00 ' + (h < 12 ? 'a. m.' : 'p. m.') }
function pxWin(p) { return [p.d + (p.h1 || 0) * 60000, p.d + (p.h2 == null ? 1439 : p.h2) * 60000 + 59999] }
/* Conteo de viajes de la app dentro del horario + estimado del premio. Solo lectura. */
function pxEst(p) {
  var w = pxWin(p), n = 0, F = [];
  apTrips(p.aid, function (c) { if (c.t >= w[0] && c.t <= w[1]) { n++; F.push(c) } });
  n = Math.max(0, n + (p.aj || 0));
  var r = { n: n, prem: 0, next: null, reach: null, last: null };
  if (p.tp === 'meta') {
    var tr = (p.tr || []).slice().sort(function (a, b) { return a.n - b.n });
    tr.forEach(function (t) { if (n >= t.n) r.reach = t; else if (!r.next) r.next = t });
    r.last = tr[tr.length - 1] || null; r.prem = r.reach ? r.reach.v : 0
  } else {
    var mn = p.mn || 0;
    if (p.bf === 'p') { F.sort(function (a, b) { return a.t - b.t }); F.slice(mn).forEach(function (c) { r.prem += (c.tf || c.v || 0) * p.bv / 100 }) }
    else r.prem = Math.max(0, n - mn) * (p.bv || 0);
    r.prem = Math.round(r.prem)
  }
  return r
}
function pxPidOk(p) { return !!p.pid && (S.am || []).some(function (m) { return m.id === p.pid }) }
/* cob = premio ya registrado · desc = sin premio · esp = premio esperado · prox / act / fin = según el horario */
function pxEstado(p) {
  var n = Date.now(), w = pxWin(p);
  if (pxPidOk(p)) return 'cob'; if (p.x) return 'desc'; if (p.pe === 'esp') return 'esp';
  return n < w[0] ? 'prox' : n <= w[1] ? 'act' : 'fin'
}
var PXE = { prox: 'Próxima', act: 'En curso', fin: 'Terminó', esp: 'Premio esperado', cob: 'Cobrada', desc: 'Sin premio' };

/* ================= tarjeta ================= */
function pxCard(p, corta) {
  var e = pxEst(p), es = pxEstado(p), w = pxWin(p), n = Date.now(), h = '', rg = '';
  var ic = p.tp === 'meta' ? '🎯' : '💸', abierta = es === 'prox' || es === 'act' || es === 'fin' || es === 'esp';
  if (p.tp === 'meta') {
    var tg = e.next || e.last, pct = tg ? Math.min(100, e.n / tg.n * 100) : 0;
    if (e.reach && !e.next) h = '<div class="pbar ok"><i style="width:100%"></i></div><small>🎉 Meta máxima alcanzada · premio <b>' + cop(e.prem) + '</b> (' + e.n + ' viajes)</small>';
    else h = '<div class="pbar' + (pct >= 80 ? ' warn' : '') + '"><i style="width:' + pct + '%"></i></div><small>Llevas <b>' + e.n + '</b> de ' + (tg ? tg.n : '—') + (e.next ? ' · te ' + (e.next.n - e.n === 1 ? 'falta <b>1</b> viaje' : 'faltan <b>' + (e.next.n - e.n) + '</b> viajes') + ' para ' + cop(e.next.v) : '') + (e.reach ? ' · ya aseguras <b>' + cop(e.reach.v) + '</b>' : '') + '</small>';
    h += '<small style="display:block;margin-top:2px">' + (p.tr || []).slice().sort(function (a, b) { return a.n - b.n }).map(function (t) { return t.n + ' viajes → ' + cop(t.v) }).join(' · ') + '</small>'
  } else {
    h = '<small>' + e.n + (e.n === 1 ? ' viaje' : ' viajes') + ' · bono ' + (p.bf === 'p' ? p.bv + ' % por viaje' : cop(p.bv) + ' por viaje') + (p.mn ? ' (desde el viaje ' + (p.mn + 1) + ')' : '') + ' · <b>estimado ' + cop(e.prem) + '</b></small>'
  }
  if (p.rq) {
    rg = p.rk ? '<small style="display:block;margin-top:2px">✅ Registrada ' + fd(p.rk) + ' ' + hm(p.rk) + '</small>' :
      p.rl && n < p.rl ? '<small style="display:block;margin-top:2px;color:var(--amb);font-weight:700">⏰ Regístrala antes de ' + hm(p.rl) + (dk(p.rl) === dk(n) ? ' de hoy' : ' · ' + fd(p.rl)) + '</small>' :
        es === 'prox' ? '<small style="display:block;margin-top:2px;color:var(--neg);font-weight:700">⚠️ Se pasó el plazo de registro</small>' : ''
  }
  var b = '';
  if (!corta) {
    if (p.rq && !p.rk && p.rl && n < p.rl && abierta) b += '<button class="mini" onclick="event.stopPropagation();pxRegistrada(\'' + p.id + '\')">✅ Ya me registré</button>';
    if (abierta && es !== 'esp') b += '<button class="mini" onclick="event.stopPropagation();pxAj(\'' + p.id + '\',-1)">−1</button><button class="mini" onclick="event.stopPropagation();pxAj(\'' + p.id + '\',1)">+1</button>';
    if (es === 'esp') b += '<button class="mini" onclick="event.stopPropagation();pxPremio(\'' + p.id + '\',\'ya\')">✅ Ya llegó</button>';
    else if (abierta) b += '<button class="mini" onclick="event.stopPropagation();pxPremio(\'' + p.id + '\')">🎁 Registrar premio</button>';
    b += '<button class="mini" onclick="event.stopPropagation();pxForm(\'' + p.aid + '\',\'' + p.id + '\')">✏️</button><button class="mini bad" onclick="event.stopPropagation();pxDelAsk(\'' + p.id + '\')">🗑️</button>'
  }
  return '<div class="li fc"><div class="row"><b>' + ic + ' ' + esc(pxNom(p)) + ' <small>· ' + esc(apNom(p.aid)) + '</small></b><span class="chip' + (es === 'act' ? '' : es === 'fin' || es === 'esp' ? ' pause' : '') + '">' + PXE[es] + '</span></div>' +
    '<small style="display:block;margin:2px 0 6px">' + fd(p.d) + ' · ' + hm(w[0]) + ' – ' + hm(w[1]) + '</small>' + h + rg +
    (p.aj ? '<small style="display:block;margin-top:2px">Ajuste manual del conteo: ' + (p.aj > 0 ? '+' : '') + p.aj + '</small>' : '') +
    (b ? '<div class="hg" style="margin-top:8px">' + b + '</div>' : '') + '</div>'
}
function pxAj(id, d) { var p = pxById(id); if (!p) return; p.aj = (p.aj || 0) + d; if (!p.aj) delete p.aj; p.ua = Date.now(); sv(); render() }
function pxRegistrada(id) { var p = pxById(id); if (!p) return; p.rk = Date.now(); p.ua = p.rk; sv(); render(); toast('✅ Registro anotado. Ya no te aviso de esta') }

/* ================= sección dentro de cada app ================= */
function pxApHTML(a) {
  var l = pxList(a.id).sort(function (x, y) { return y.d - x.d || (y.ua || 0) - (x.ua || 0) }), ab = [], ol = [];
  l.forEach(function (p) { var e = pxEstado(p); if (e === 'cob' || e === 'desc' || (e === 'fin' && p.d < d0(Date.now()) - 7 * 86400000)) ol.push(p); else ab.push(p) });
  return '<h2>🎯 Promociones e incentivos</h2><div class="two"><button class="btn" onclick="pxForm(\'' + a.id + '\')">➕ Promoción</button>' +
    (l.length ? '<button class="btn out" onclick="pxForm(\'' + a.id + '\',\'\',\'' + l[0].id + '\')">📋 Copiar la última</button>' : '<button class="btn out" onclick="avPromoAyuda()">❔ Cómo funciona</button>') + '</div>' +
    (ab.length ? ab.map(function (p) { return pxCard(p) }).join('') : '<div class="li"><small>No hay promociones abiertas. Anota la de hoy o la que tienes que registrar para mañana.</small></div>') +
    (ol.length ? '<button class="btn out sm" onclick="pxOld=!pxOld;render()">' + (pxOld ? '🔽' : '▶️') + ' Anteriores (' + ol.length + ')</button>' + (pxOld ? ol.slice(0, 20).map(function (p) { return pxCard(p, true) }).join('') : '') : '')
}
function avPromoAyuda() {
  openM('<h3>🎯 Promociones</h3><p>Anota la promoción una vez (meta por viajes con tramos, o bono por viaje). La app cuenta los viajes de esa app dentro del horario y te dice cuánto llevas.</p><p>Si hay que registrarse antes (como en Uber), marca <b>“Necesita registrarme antes”</b> y pon la hora límite: te aviso a las horas que elijas en Ajustes.</p><p>No puedo leer DiDi ni Uber: si su conteo es distinto, corrígelo con −1 / +1.</p><button class="btn" onclick="closeM()">Entendido</button>')
}

/* ================= formulario ================= */
function pxFormTipo(v) { var m = $('#pxM'), b = $('#pxB'); if (m) m.style.display = v === 'meta' ? '' : 'none'; if (b) b.style.display = v === 'bono' ? '' : 'none' }
function pxFormRq(on) { var r = $('#pxR'); if (r) r.style.display = on ? '' : 'none' }
function pxForm(aid, id, src) {
  var a = apById(aid); if (!a) return;
  var p = id ? pxById(id) : null; if (id && !p) return;
  var b = p || (src ? pxById(src) : null), uber = /uber/i.test(a.nom), hoy = d0(Date.now()), cfg = pxCfg();
  var tp = b ? b.tp : (uber ? 'bono' : 'meta'), d = p ? p.d : hoy;
  if (!p && b && b.d >= hoy) d = addD(b.d, 1);
  var h1 = b && b.h1 != null ? b.h1 : 0, h2 = b && b.h2 != null ? b.h2 : 1439, tr = (b && b.tr) || [], rq = b ? !!b.rq : uber;
  var rl = p ? p.rl : (b && b.rq && b.rl ? d0(d) - 60000 : (rq ? d0(d) - 60000 : null)), hs = b && b.rh && b.rh.length ? b.rh : cfg.hs, hrs = [];
  for (var h = 12; h <= 23; h++) hrs.push(h);
  var ti = [0, 1, 2].map(function (i) {
    return '<div class="two"><label>Viajes (meta ' + (i + 1) + ')<input id="pxN' + i + '" type="number" inputmode="numeric" min="1" value="' + (tr[i] ? tr[i].n : '') + '" placeholder="Ej. ' + [45, 70, ''][i] + '"></label><label>Premio total<input id="pxV' + i + '" type="number" inputmode="numeric" min="1" value="' + (tr[i] ? tr[i].v : '') + '" placeholder="Ej. ' + [30000, 50000, ''][i] + '"></label></div>'
  }).join('');
  openM('<h3>' + (p ? '✏️ Editar promoción' : '➕ Promoción') + ' · ' + esc(a.nom) + '</h3>' +
    (!p && !src && pxList(aid).length ? '<button class="btn out sm" style="margin-bottom:10px" onclick="pxForm(\'' + aid + '\',\'\',\'' + pxList(aid).sort(function (x, y) { return y.d - x.d || (y.ua || 0) - (x.ua || 0) })[0].id + '\')">📋 Copiar la última y cambiar lo que varía</button>' : '') +
    '<label>Tipo<select id="pxT" onchange="pxFormTipo(this.value)"><option value="meta"' + (tp === 'meta' ? ' selected' : '') + '>🎯 Meta por viajes (premio por tramos)</option><option value="bono"' + (tp === 'bono' ? ' selected' : '') + '>💸 Bono por viaje</option></select></label>' +
    '<label>Nombre (opcional)<input id="pxNm" maxlength="40" value="' + esc(b ? b.nom || '' : '') + '" placeholder="Ej. Meta 45 rentas"></label>' +
    '<label>📅 Día<input id="pxD" type="date" value="' + iso(d) + '"></label>' +
    '<div class="two"><label>Desde<input id="pxH1" type="time" value="' + pxHHMM(h1) + '"></label><label>Hasta<input id="pxH2" type="time" value="' + pxHHMM(h2) + '"></label></div>' +
    '<div id="pxM"><small style="display:block;margin-bottom:6px">Pon cada meta y su premio total. Deja vacías las que no uses.</small>' + ti + '</div>' +
    '<div id="pxB"><label>El bono es…<select id="pxBF"><option value="f"' + (!b || b.bf !== 'p' ? ' selected' : '') + '>Monto fijo por viaje</option><option value="p"' + (b && b.bf === 'p' ? ' selected' : '') + '>% de la tarifa de cada viaje</option></select></label>' +
    '<div class="two"><label>Valor (monto o %)<input id="pxBV" type="number" inputmode="decimal" min="0" step="0.5" value="' + (b && b.bv ? b.bv : '') + '" placeholder="Ej. 500"></label><label>Viajes que no cuentan<input id="pxMN" type="number" inputmode="numeric" min="0" value="' + (b && b.mn ? b.mn : '') + '" placeholder="0"></label></div></div>' +
    '<label class="ck" style="margin-top:6px"><input id="pxQ" type="checkbox" ' + (rq ? 'checked' : '') + ' onchange="pxFormRq(this.checked)"> <span>Necesita registrarme / activarla antes</span></label>' +
    '<div id="pxR"><label>⏰ Registrarme antes de<input id="pxL" type="datetime-local" value="' + (rl ? ldt(rl) : ldt(d0(d) - 60000)) + '"></label>' +
    '<small style="display:block;margin:-4px 0 6px">Te aviso a estas horas del día del plazo (si no cambias nada, usa las de Ajustes → Avisos):</small><div class="hg">' +
    hrs.map(function (x) { return '<label><input type="checkbox" class="pxhc" value="' + x + '"' + (hs.indexOf(x) >= 0 ? ' checked' : '') + '> ' + pxHora(x).replace(':00', '') + '</label>' }).join('') + '</div></div>' +
    btns("pxSave('" + aid + "','" + (id || '') + "')"));
  pxFormTipo(tp); pxFormRq(rq)
}
function pxSave(aid, id) {
  var a = apById(aid); if (!a) { closeM(); return }
  var tp = $('#pxT').value, nm = $('#pxNm').value.trim().replace(/\s+/g, ' ').slice(0, 40), d = pd($('#pxD').value), h1 = pxMin($('#pxH1').value), h2 = pxMin($('#pxH2').value);
  if (isNaN(d)) { toast('Revisa el día'); return }
  if (h1 === null || h2 === null) { toast('Revisa las horas'); return }
  if (h2 <= h1) { toast('La hora final debe ser posterior a la inicial'); return }
  var o = { aid: aid, nom: nm, tp: tp === 'bono' ? 'bono' : 'meta', d: d, h1: h1, h2: h2 };
  if (o.tp === 'meta') {
    var tr = [], i, bad = false;
    for (i = 0; i < 3; i++) {
      var rn = $('#pxN' + i).value, rv = $('#pxV' + i).value; if (rn === '' && rv === '') continue;
      var n = num('#pxN' + i), v = num('#pxV' + i);
      if (!(n >= 1) || n !== Math.floor(n) || !(v >= 1)) { bad = true; break }
      tr.push({ n: n, v: Math.round(v) })
    }
    if (bad) { toast('En cada meta pon los viajes (entero) y el premio'); return }
    if (!tr.length) { toast('Pon al menos una meta con su premio'); return }
    tr.sort(function (x, y) { return x.n - y.n });
    for (i = 1; i < tr.length; i++) if (tr[i].n === tr[i - 1].n) { toast('Dos metas tienen los mismos viajes'); return }
    o.tr = tr
  } else {
    var bf = $('#pxBF').value === 'p' ? 'p' : 'f', bv = num('#pxBV'), mn = $('#pxMN').value === '' ? 0 : num('#pxMN');
    if (!(bv > 0)) { toast('Pon el valor del bono'); return }
    if (bf === 'p' && bv > 100) { toast('El porcentaje no puede pasar de 100'); return }
    if (!(mn >= 0) || mn !== Math.floor(mn)) { toast('Los viajes que no cuentan deben ser un número entero'); return }
    o.bf = bf; o.bv = bv; o.mn = mn
  }
  var rq = $('#pxQ').checked;
  if (rq) {
    var rl = pdt($('#pxL').value); if (rl === null) { toast('Revisa la hora límite del registro'); return }
    o.rq = true; o.rl = rl;
    var hs = [].slice.call(document.querySelectorAll('.pxhc')).filter(function (x) { return x.checked }).map(function (x) { return +x.value }).sort(function (x, y) { return x - y }), g = pxCfg().hs;
    if (JSON.stringify(hs) !== JSON.stringify(g.filter(function (h) { return h >= 12 }))) o.rh = hs
  }
  if (!Array.isArray(S.px)) S.px = [];
  var n2 = Date.now(), p = id ? pxById(id) : null;
  if (id && !p) { closeM(); return }
  if (p) {
    var keep = { rk: p.rk, aj: p.aj, pe: p.pe, pv: p.pv, pid: p.pid, x: p.x, id: p.id, ca: p.ca };
    Object.keys(p).forEach(function (k) { delete p[k] }); Object.keys(o).forEach(function (k) { p[k] = o[k] });
    Object.keys(keep).forEach(function (k) { if (keep[k] != null) p[k] = keep[k] });
    if (!o.rq) { delete p.rk }
    p.ua = n2
  } else { o.id = uid(); o.ca = n2; o.ua = n2; S.px.push(o) }
  sv(); closeM(); render(); toast(p ? '✅ Promoción actualizada' : '🎯 Promoción guardada')
}
function pxDelAsk(id) {
  var p = pxById(id); if (!p) return;
  openM('<h3>¿Eliminar “' + esc(pxNom(p)) + '”?</h3><p>Se borra la promoción. Si ya registraste su premio, ese premio se queda en el historial.</p><div class="two"><button class="btn out" onclick="closeM()">Cancelar</button><button class="btn bad" onclick="pxDel(\'' + id + '\')">Eliminar</button></div>')
}
function pxDel(id) { S.px = (S.px || []).filter(function (p) { return p.id !== id }); sv(); closeM(); render(); toast('🗑️ Promoción eliminada') }

/* ================= premio: ya llegó · esperado · sin premio ================= */
function pxPremio(id, modo) {
  var p = pxById(id); if (!p) return; var e = pxEst(p), v = p.pe === 'esp' && p.pv > 0 ? p.pv : e.prem;
  openM('<h3>🎁 Premio · ' + esc(pxNom(p)) + '</h3><p>Estimado con tus viajes: <b>' + cop(e.prem) + '</b> (' + e.n + (e.n === 1 ? ' viaje' : ' viajes') + '). Escribe lo que de verdad te dieron o te darán.</p>' +
    '<label>Monto del premio<input id="pxPv" type="number" inputmode="numeric" min="0" value="' + (v > 0 ? v : '') + '" placeholder="0"></label>' +
    '<label>¿Ya lo recibiste?<select id="pxPm" onchange="var f=$(\'#pxPf\');if(f)f.style.display=this.value===\'ya\'?\'\':\'none\'"><option value="ya"' + (modo === 'ya' ? ' selected' : '') + '>Sí, ya está en la app</option><option value="esp"' + (modo === 'ya' ? '' : ' selected') + '>Todavía no, lo esperan</option></select></label>' +
    '<div id="pxPf"' + (modo === 'ya' ? '' : ' style="display:none"') + '><label>Fecha y hora en que llegó<input id="pxPt" type="datetime-local" value="' + ldt(Date.now()) + '"></label></div>' +
    btns("pxPremioOk('" + id + "')") + '<button class="btn out sm" style="margin-top:8px" onclick="pxSinPremio(\'' + id + '\')">No hubo premio</button>')
}
function pxPremioOk(id) {
  var p = pxById(id); if (!p) { closeM(); return }
  var v = num('#pxPv'), m = $('#pxPm').value; if (!(v > 0)) { toast('Escribe un monto mayor que 0'); return }
  var n = Date.now();
  if (m === 'esp') { p.pe = 'esp'; p.pv = Math.round(v); delete p.x; p.ua = n; sv(); closeM(); render(); toast('⏳ Anotado como premio esperado'); return }
  var t = pdt($('#pxPt').value); if (t === null) { toast('Revisa la fecha'); return }
  if (!Array.isArray(S.am)) S.am = [];
  var pm = { id: uid(), aid: p.aid, t: t, tipo: 'premio', pt: p.tp === 'meta' ? 'meta' : 'bono', v: Math.round(v), bil: null, nota: pxNom(p).slice(0, 60), px: p.id, ua: n };
  S.am.push(pm); p.pid = pm.id; delete p.pe; delete p.pv; delete p.x; p.ua = n;
  sv(); closeM(); render(); toast('🎁 Premio registrado en ' + apNom(p.aid))
}
function pxSinPremio(id) { var p = pxById(id); if (!p) return; p.x = 1; delete p.pe; delete p.pv; p.ua = Date.now(); sv(); closeM(); render(); toast('Listo, sin premio') }

/* ================= Inicio y Jornada: promos de hoy ================= */
function pxRevisado(aid) { return (S.pxr || {})[aid] === dk(Date.now()) }
function pxRev(aid) { if (!S.pxr || typeof S.pxr !== 'object') S.pxr = {}; S.pxr[aid] = dk(Date.now()); sv(); render() }
function pxHoyLista() {
  var n = Date.now(), hoy = d0(n), r = [];
  pxList().forEach(function (p) {
    if (!apById(p.aid)) return; var es = pxEstado(p), pr = null;
    if (p.rq && !p.rk && p.rl && n < p.rl && (es === 'prox' || es === 'act')) pr = 0;
    else if (es === 'act') pr = 1;
    else if (es === 'esp') pr = 2;
    else if (es === 'fin' && p.d >= hoy - 86400000) pr = 3;
    else if (es === 'prox' && p.d <= hoy + 86400000) pr = 4;
    if (pr !== null) r.push({ p: p, pr: pr })
  });
  return r.sort(function (a, b) { return a.pr - b.pr || a.p.d - b.p.d }).slice(0, 5)
}
function pxHoyHTML(full) {
  var l = pxHoyLista(), rev = [], hoy = d0(Date.now());
  if (full && act()) apList().filter(function (a) { return !a.arch }).forEach(function (a) {
    if (!pxList(a.id).some(function (p) { return p.d === hoy }) && !pxRevisado(a.id)) rev.push(a)
  });
  if (!l.length && !rev.length) return '';
  return '<h2>🎯 Promos de hoy</h2><div class="card">' + l.map(function (x) {
    var p = x.p, e = pxEst(p), es = pxEstado(p), txt;
    if (p.tp === 'meta') txt = e.next ? e.n + ' de ' + e.next.n + ' · faltan ' + (e.next.n - e.n) + ' para ' + cop(e.next.v) : e.reach ? '🎉 ' + e.n + ' viajes · premio ' + cop(e.prem) : e.n + ' viajes';
    else txt = e.n + ' viajes · estimado ' + cop(e.prem);
    if (es === 'esp') txt = '⏳ Premio esperado ' + cop(p.pv || e.prem) + ' · ¿ya llegó?';
    else if (es === 'fin') txt = 'Terminó · ' + (e.prem > 0 ? 'ganaste ~' + cop(e.prem) + ' · regístralo' : e.n + ' viajes, sin premio');
    else if (es === 'prox') txt = 'Empieza ' + fd(p.d) + ' ' + hm(pxWin(p)[0]);
    if (p.rq && !p.rk && p.rl && Date.now() < p.rl) txt = '⏰ Registrarme antes de ' + hm(p.rl) + (dk(p.rl) === dk(Date.now()) ? ' de hoy' : ' · ' + fd(p.rl)) + ' · ' + txt;
    return '<div class="kv tap" style="cursor:pointer;align-items:flex-start" onclick="tab=\'fin\';fsub=\'apps\';adet=\'' + p.aid + '\';render();window.scrollTo(0,0)"><span>' + (p.tp === 'meta' ? '🎯' : '💸') + ' ' + esc(pxNom(p)) + ' <small>· ' + esc(apNom(p.aid)) + '</small><br><small>' + txt + '</small></span><b>›</b></div>'
  }).join('') + rev.map(function (a) {
    return '<div class="kv" style="align-items:center;flex-wrap:wrap;gap:6px"><span>📣 ¿Revisaste las promos de <b>' + esc(a.nom) + '</b> de hoy?</span><span><button class="mini" onclick="pxForm(\'' + a.id + '\')">➕ Anotar</button> <button class="mini" onclick="pxRev(\'' + a.id + '\')">Hoy no hay</button></span></div>'
  }).join('') + '</div>'
}

/* ================= avisos (los consume avItems en avisos.js) ================= */
function pxAvisos() {
  var A = [], n = Date.now(), cfg = pxCfg();
  pxList().forEach(function (p) {
    if (!apById(p.aid) || p.x) return;
    var es = pxEstado(p), nm = esc(pxNom(p)), ap = esc(apNom(p.aid)), go = ['fin', 'apps', 'adet', p.aid];
    if (es === 'cob' || es === 'desc') return;
    if (p.rq && !p.rk && p.rl && n < p.rl && (es === 'prox' || es === 'act')) {
      var hs = p.rh && p.rh.length ? p.rh : cfg.hs, L = d0(p.rl), hr = null;
      hs.forEach(function (h) { var t = L + h * 3600000; if (t <= n && t < p.rl && (hr === null || h > hr)) hr = h });
      if (!hs.length) hr = 0;
      if (hr !== null) A.push({ k: 'prr' + p.id + 'h' + hr, sev: 1, ic: '⏰', tx: 'Registra “' + nm + '” de ' + ap, sub: 'Antes de ' + hm(p.rl) + (dk(p.rl) === dk(n) ? ' de hoy' : ' · ' + fd(p.rl)) + ' o pierdes la promoción', t: L + hr * 3600000, hr: hr, go: go })
    }
    if (es === 'esp') A.push({ k: 'pre' + p.id, sev: 1, ic: '🎁', tx: 'Premio esperado de ' + ap + ' · ' + cop(p.pv || 0), sub: '¿Ya llegó? Confírmalo para sumarlo al saldo', t: n, go: go });
    else if (es === 'fin') { var e = pxEst(p); if (e.prem > 0 && p.d >= d0(n) - 3 * 86400000) A.push({ k: 'pfn' + p.id, sev: 1, ic: '🎁', tx: '“' + nm + '” de ' + ap + ' terminó · ~' + cop(e.prem), sub: 'Regístralo como premio', t: n, go: go }) }
    else if (es === 'act' && p.tp === 'meta') {
      var e2 = pxEst(p); if (e2.next && e2.next.n - e2.n > 0 && e2.next.n - e2.n <= cfg.cerca) A.push({ k: 'pcr' + p.id + 'n' + e2.n, sev: 2, ic: '🎯', tx: 'Te ' + (e2.next.n - e2.n === 1 ? 'falta 1 viaje' : 'faltan ' + (e2.next.n - e2.n) + ' viajes') + ' en “' + nm + '”', sub: 'Premio de ' + cop(e2.next.v) + ' · ' + ap, t: n, go: go })
    }
  });
  return A
}

/* ================= ajustes: horas de aviso y alarma en el calendario ================= */
function pxCfgSet(o) { S.pxc = Object.assign({}, S.pxc, o); sv(); render() }
function pxHoraAdd() { var h = +$('#pxHa').value, c = pxCfg(); if (c.hs.indexOf(h) >= 0) { toast('Esa hora ya está'); return } pxCfgSet({ hs: c.hs.concat([h]).sort(function (a, b) { return a - b }) }) }
function pxHoraDel(h) { pxCfgSet({ hs: pxCfg().hs.filter(function (x) { return x !== h }) }) }
function pxCerca(n) { pxCfgSet({ cerca: +n }) }
function pxCfgHTML() {
  var c = pxCfg(), hs = [];
  for (var i = 5; i <= 23; i++) hs.push(i);
  return '<h2>🎯 Promociones: avisos de registro</h2><div class="card form"><small style="display:block;margin-bottom:8px">Si una promoción necesita registro previo (como en Uber), te aviso a estas horas del día del plazo. Cada aviso se detiene cuando marcas “Ya me registré”.</small>' +
    '<div class="hg" style="margin-bottom:10px">' + (c.hs.length ? c.hs.map(function (h) { return '<span class="chip">' + pxHora(h) + ' <button class="mini bad" aria-label="Quitar" onclick="pxHoraDel(' + h + ')">✕</button></span>' }).join('') : '<small>Sin horas: te aviso desde el comienzo del día del plazo.</small>') + '</div>' +
    '<div class="two"><label>Agregar hora<select id="pxHa">' + hs.map(function (h) { return '<option value="' + h + '"' + (h === 20 ? ' selected' : '') + '>' + pxHora(h) + '</option>' }).join('') + '</select></label><button class="btn out" style="align-self:end" onclick="pxHoraAdd()">➕ Agregar</button></div>' +
    '<label>Avisar cuando falten (viajes para la meta)<select onchange="pxCerca(this.value)">' + [1, 2, 3, 4, 5, 8, 10].map(function (n) { return '<option value="' + n + '"' + (c.cerca === n ? ' selected' : '') + '>' + n + (n === 1 ? ' viaje' : ' viajes') + '</option>' }).join('') + '</select></label>' +
    '<button class="btn out" onclick="pxIcs()">⏰ Crear alarma diaria en el calendario</button><small style="display:block;margin-top:6px">Con la app cerrada, Chrome no garantiza que la notificación llegue a la hora. La alarma del calendario sí suena a tiempo todos los días, a estas horas.</small></div>'
}
function pxIcs() {
  var hs = pxCfg().hs; if (!hs.length) { toast('Agrega al menos una hora'); return }
  function L(s) { return String(s).replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n') }
  function f(t, h) { var d = new Date(t), p = function (x) { return String(x).padStart(2, '0') }; return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + 'T' + p(h) + '0000' }
  var ahora = new Date(), hoy = d0(Date.now()), st = new Date().toISOString().replace(/[-:]/g, '').slice(0, 15) + 'Z';
  var ev = hs.map(function (h) {
    var ini = ahora.getHours() >= h ? addD(hoy, 1) : hoy;
    return ['BEGIN:VEVENT', 'UID:fj-promo-' + h + '@finanzas-jornada', 'DTSTAMP:' + st, 'DTSTART:' + f(ini, h), 'DTEND:' + f(ini, h).slice(0, 11) + '1500', 'RRULE:FREQ=DAILY',
      'SUMMARY:' + L('Registrar incentivos (Uber / DiDi)'), 'DESCRIPTION:' + L('Revisa y registra las promociones de mañana antes de la hora límite.'),
      'BEGIN:VALARM', 'ACTION:DISPLAY', 'DESCRIPTION:' + L('Registrar incentivos (Uber / DiDi)'), 'TRIGGER:PT0S', 'END:VALARM', 'END:VEVENT'].join('\r\n')
  });
  avBajar('alarma-incentivos.ics', ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Finanzas Jornada//ES'].join('\r\n') + '\r\n' + ev.join('\r\n') + '\r\nEND:VCALENDAR');
  toast('⏰ Abre el archivo para agregar las alarmas a tu calendario')
}
