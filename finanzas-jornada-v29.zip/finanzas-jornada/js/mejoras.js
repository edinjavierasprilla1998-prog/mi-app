/* Finanzas + Jornada — mejoras.js (Etapa 8): pausas propias, tipos de cobro, rentabilidad por app, premios en el historial,
   fondos fijos y de ahorro con «Apartar hoy», y ayudas del presupuesto.
   Todo es aditivo: no cambia ni borra datos existentes. Campos nuevos en S: pc (categorías de pausa), ct (tipos de cobro), sd (marca de datos iniciales). */

/* ================= Pausas: categorías propias ================= */
function paAll(extra) {
  var l = PA.concat((S.pc || []).map(function (x) { return [x.ico || '⏸️', x.nom] }));
  if (extra && !l.some(function (x) { return x[1] === extra })) l.push(['⏸️', extra]);
  return l
}
function paNomOk(nom) { return nom && !/['"<>&\\`]/.test(nom) }
function paForm() {
  openM('<h3>➕ Nueva categoría de pausa</h3><p>Aparecerá junto a las demás al pausar la jornada.</p>' +
    '<label>Nombre<input id="pcn" maxlength="24" placeholder="Ej. Lavar la moto"></label>' +
    '<label>Emoji<input id="pci" maxlength="4" value="⏸️"></label>' + btns('paSave()'))
}
function paSave() {
  var nom = $('#pcn').value.trim().replace(/\s+/g, ' '), ico = ($('#pci').value || '').trim() || '⏸️';
  if (!nom) { toast('Escribe un nombre'); return }
  if (!paNomOk(nom)) { toast('El nombre no puede tener comillas ni los símbolos < > & \\'); return }
  if (paAll().some(function (x) { return x[1].toLowerCase() === nom.toLowerCase() })) { toast('Ya existe esa categoría'); return }
  if (!Array.isArray(S.pc)) S.pc = [];
  S.pc.push({ id: uid(), ico: ico.slice(0, 4), nom: nom, ua: Date.now() });
  sv(); closeM(); render(); toast('✅ Categoría creada')
}
function paGest() {
  var l = S.pc || [];
  openM('<h3>⏸️ Mis categorías de pausa</h3>' + (l.length ? '<p>Las pausas ya registradas con una categoría que borres no cambian.</p>' + l.map(function (x) {
    return '<div class="li fh"><div class="wr" style="padding:0"><span class="ic">' + esc(x.ico) + '</span><div class="g"><b>' + esc(x.nom) + '</b></div><button class="mini bad" onclick="paDel(\'' + x.id + '\')">🗑️ Quitar</button></div></div>'
  }).join('') : '<p>Todavía no creaste categorías propias. Las 9 que vienen con la app no se pueden quitar.</p>') +
    '<div class="two"><button class="btn out" onclick="closeM()">Cerrar</button><button class="btn" onclick="closeM();paForm()">➕ Nueva</button></div>')
}
function paDel(id) { S.pc = (S.pc || []).filter(function (x) { return x.id !== id }); sv(); render(); paGest() }

/* ================= Por cobrar unificado (préstamos + cobros) ================= */
var cbFiltro = 'todos', CBG = [];
function cbItems() { var r = []; ['prestamos', 'cobros'].forEach(function (k) { var c = CU[k]; cuLst(c).forEach(function (f) { r.push({ k: k, f: f, c: c }) }) }); return r }
function cbNorm(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim() }
function cbSetF(x) { cbFiltro = x; render() }
function cbGrupos() {
  var it = cbItems().filter(function (x) { return !x.f.arch }), g = [], vistos = {}, ign = S.cbx || [];
  function add(l, why) {
    if (l.length < 2) return;
    var key = l.map(function (x) { return x.f.id }).sort().join('+');
    if (vistos[key] || ign.indexOf(key) >= 0) return; vistos[key] = 1; g.push({ key: key, why: why, l: l })
  }
  var a = {}, b = {};
  it.forEach(function (x) {
    (a[cbNorm(x.f.nom)] = a[cbNorm(x.f.nom)] || []).push(x);
    var s = cuSaldo(x.c, x.f.id); if (s >= 0.005) { var kk = Math.round(s) + '|' + d0(x.f.fi || x.f.ca) + '|' + ctGet(x.k, x.f).id; (b[kk] = b[kk] || []).push(x) }
  });
  Object.keys(a).forEach(function (k) { add(a[k], 'Mismo nombre') });
  Object.keys(b).forEach(function (k) { add(b[k], 'Mismo valor, tipo y fecha de inicio') });
  return g
}
function vCobros() {
  var all = cbItems(), arc = all.filter(function (x) { return x.f.arch }), act = all.filter(function (x) { return !x.f.arch }), T = ctAll(), tot = 0, pend = 0, venc = 0, hoy = d0(Date.now());
  act.forEach(function (x) { var s = cuSaldo(x.c, x.f.id); if (s > 0.005) { tot += s; pend++; if (x.f.fv && d0(x.f.fv) < hoy) venc++ } });
  var cnt = {}; act.forEach(function (x) { var id = ctGet(x.k, x.f).id; cnt[id] = (cnt[id] || 0) + 1 });
  if (cbFiltro !== 'todos' && !cnt[cbFiltro]) cbFiltro = 'todos';
  var ver = act.filter(function (x) { return cbFiltro === 'todos' || ctGet(x.k, x.f).id === cbFiltro });
  ver.sort(function (A, B) {
    var sa = cuSaldo(A.c, A.f.id) < 0.005, sb = cuSaldo(B.c, B.f.id) < 0.005; if (sa !== sb) return sa ? 1 : -1;
    var fa = A.f.fv || Infinity, fb = B.f.fv || Infinity; if (fa !== fb) return fa < fb ? -1 : 1; return (B.f.ua || 0) - (A.f.ua || 0)
  });
  var dups = cbGrupos().length;
  var h = '<div class="tiles">' + st('Total por cobrar', cop(tot)) + st('Pendientes', pend) + '</div>' +
    (venc ? '<div class="warn" style="margin-top:8px"><span>⚠️ ' + venc + (venc === 1 ? ' vencido' : ' vencidos') + '</span></div>' : '') +
    '<button class="btn" style="margin-top:12px" onclick="cuForm(\'cobros\')">➕ Nuevo por cobrar</button>' +
    '<div class="two" style="margin-top:8px"><button class="btn out sm" onclick="ctGest()">🏷️ Tipos</button><button class="btn out sm" onclick="cbRevisar()">🔍 Duplicados' + (dups ? ' (' + dups + ')' : '') + '</button></div>';
  if (Object.keys(cnt).length > 1) h += '<div class="seg s6" style="margin-top:8px"><button class="' + (cbFiltro === 'todos' ? 'on' : '') + '" onclick="cbSetF(\'todos\')">Todos (' + act.length + ')</button>' +
    T.filter(function (t) { return cnt[t.id] }).map(function (t) { return '<button class="' + (cbFiltro === t.id ? 'on' : '') + '" onclick="cbSetF(\'' + t.id + '\')">' + esc(t.ico + ' ' + t.nom) + ' (' + cnt[t.id] + ')</button>' }).join('') + '</div>';
  h += '<h2>⏳ Por cobrar</h2>' + (ver.length ? ver.map(function (x) { return cuCard(x.k, x.f) }).join('') : '<div class="li"><small>Aún no tienes nada por cobrar. Agrega un préstamo de dinero o una carrera o domicilio que aún no te pagan.</small></div>');
  if (arc.length) {
    h += '<button class="btn out sm" onclick="cArch=!cArch;render()">' + (cArch ? '🔽' : '▶️') + ' 📦 Archivados (' + arc.length + ')</button>';
    if (cArch) h += arc.map(function (x) { return cuCard(x.k, x.f) }).join('')
  }
  return h
}
/* ---- tipos de cobro propios ---- */
function ctGest() {
  var l = ctAll();
  openM('<h3>🏷️ Tipos de cobro</h3><p>Los dos primeros vienen con la app. Crea los tuyos si lo necesitas.</p>' + l.map(function (t) {
    var n = cbItems().filter(function (x) { return ctGet(x.k, x.f).id === t.id }).length;
    return '<div class="li fh"><div class="wr" style="padding:0"><span class="ic">' + esc(t.ico) + '</span><div class="g"><b>' + esc(t.nom) + '</b><br><small>' + (t.k === 'cobros' ? 'Al cobrar cuenta como ingreso' : 'No cuenta como ingreso') + ' · ' + n + ' en uso</small></div>' + (t.custom ? '<button class="mini bad" onclick="ctDel(\'' + t.id + '\')">🗑️</button>' : '') + '</div></div>'
  }).join('') + '<div class="two"><button class="btn out" onclick="closeM()">Cerrar</button><button class="btn" onclick="ctForm()">➕ Nuevo tipo</button></div>')
}
function ctForm() {
  openM('<h3>➕ Nuevo tipo de cobro</h3><label>Nombre<input id="ctn" maxlength="24" placeholder="Ej. Fiado de un cliente"></label><label>Emoji<input id="cti" maxlength="4" value="🏷️"></label>' +
    '<label>Al cobrarlo…<select id="ctk"><option value="cobros">Cuenta como ingreso (servicio que me deben)</option><option value="prestamos">No cuenta como ingreso (dinero que me devuelven)</option></select></label>' + btns('ctSave()'))
}
function ctSave() {
  var nom = $('#ctn').value.trim().replace(/\s+/g, ' '), ico = ($('#cti').value || '').trim() || '🏷️', k = $('#ctk').value;
  if (!nom) { toast('Escribe un nombre'); return }
  if (!paNomOk(nom)) { toast('El nombre no puede tener comillas ni los símbolos < > & \\'); return }
  if (ctAll().some(function (t) { return t.nom.toLowerCase() === nom.toLowerCase() })) { toast('Ya existe ese tipo'); return }
  if (!Array.isArray(S.ct)) S.ct = [];
  S.ct.push({ id: 'ct' + uid(), ico: ico.slice(0, 4), nom: nom, k: k === 'cobros' ? 'cobros' : 'prestamos', ua: Date.now() });
  sv(); closeM(); render(); toast('✅ Tipo creado'); ctGest()
}
function ctDel(id) {
  if (cbItems().some(function (x) { return ctGet(x.k, x.f).id === id })) { toast('Hay registros con este tipo. Cámbiales el tipo primero.'); return }
  S.ct = (S.ct || []).filter(function (x) { return x.id !== id }); sv(); render(); ctGest()
}
/* ---- revisar duplicados (con copia de seguridad antes de borrar) ---- */
function cbRevisar() {
  CBG = cbGrupos();
  if (!CBG.length) { openM('<h3>🔍 Duplicados</h3><p>✅ No encontré registros repetidos en Por cobrar.</p><button class="btn" onclick="closeM()">Cerrar</button>'); return }
  openM('<h3>🔍 Posibles duplicados</h3><p>Elige cuál quieres conservar. Los demás se eliminan con sus movimientos. Antes de borrar se guarda una copia interna.</p>' + CBG.map(function (g, gi) {
    return '<div class="card" style="margin-bottom:10px"><small><b>' + g.why + '</b></small>' + g.l.map(function (x, i) {
      var s = cuSaldo(x.c, x.f.id), nm = cuMovs(x.c, x.f.id).length;
      return '<div class="li fh" style="margin-top:6px"><b>' + esc(x.f.nom) + '</b> <small>' + cop(Math.max(0, s)) + '</small><br><small>' + cuFechas(x.k, x.f) + ' · ' + nm + ' mov.</small><button class="btn out sm" style="margin-top:6px" onclick="cbQuedar(' + gi + ',' + i + ')">Quedarme con este</button></div>'
    }).join('') + '<button class="mini" style="margin-top:6px" onclick="cbNoDup(' + gi + ')">No son duplicados</button></div>'
  }).join('') + '<button class="btn out" onclick="closeM()">Cerrar</button>')
}
function cbNoDup(gi) { var g = CBG[gi]; if (!g) return; if (!Array.isArray(S.cbx)) S.cbx = []; S.cbx.push(g.key); sv(); render(); cbRevisar() }
function cbQuedar(gi, i) {
  var g = CBG[gi]; if (!g) return;
  var otros = g.l.filter(function (x, j) { return j !== i }), cb = 0;
  otros.forEach(function (x) { cuMovs(x.c, x.f.id).forEach(function (m) { if (m.bil) cb++ }) });
  openM('<h3>¿Quedarte con “' + esc(g.l[i].f.nom) + '”?</h3><p>Se eliminará: ' + otros.map(function (x) { return '“' + esc(x.f.nom) + '”' }).join(', ') + '.' +
    (cb ? ' <b>' + cb + ' movimiento(s) afectaron billeteras: esas billeteras volverán al saldo que tendrían sin ellos.</b>' : '') + ' Se guarda una copia interna antes.</p>' +
    '<div class="two"><button class="btn out" onclick="cbRevisar()">Volver</button><button class="btn bad" onclick="cbQuedarOk(' + gi + ',' + i + ')">Eliminar los demás</button></div>')
}
function cbQuedarOk(gi, i) {
  var g = CBG[gi]; if (!g) return;
  var raw = JSON.stringify(S), hecho = function () {
    g.l.forEach(function (x, j) {
      if (j === i) return; var c = x.c;
      S[c.M] = (S[c.M] || []).filter(function (m) { return m.cid !== x.f.id }); S[c.L] = (S[c.L] || []).filter(function (f) { return f.id !== x.f.id })
    });
    cdet = null; sv(); closeM(); render(); toast('🗑️ Duplicados eliminados')
  };
  try { fjCrearSnap('manual', raw, 'Antes de quitar duplicados de Por cobrar').then(hecho).catch(function () { toast('No se pudo crear la copia interna. No se borró nada.') }) }
  catch (e) { toast('No se pudo crear la copia interna. No se borró nada.') }
}

/* ================= Rentabilidad por app (Historial) ================= */
var rtDias = false;
/* Por app entre a y b: ingresos de viajes (valor + propina), premios y costos (comisión por viaje, comisiones y pases de la app). Solo lectura. */
function rtNet(a, b) {
  var R = { apps: {}, dias: {} };
  function ent(id) { return R.apps[id] || (R.apps[id] = { ing: 0, pre: 0, cm: 0, n: 0, dir: 0, tar: 0, rf: 0 }) }
  function dia(t, id, v) { var k = dk(t); (R.dias[k] = R.dias[k] || {}); R.dias[k][id] = (R.dias[k][id] || 0) + v }
  (S.j || []).forEach(function (j) {
    (j.ca || []).forEach(function (c) {
      if (c.t < a || c.t >= b) return;
      var id = c.ap && apById(c.ap) ? c.ap : '_', e = ent(id), g = (c.v || 0) + (c.p || 0), cm = c.cm || 0;
      e.ing += g; e.cm += cm; e.n++; dia(c.t, id, g - cm);
      if (Array.isArray(c.pg)) c.pg.forEach(function (l) { if (l.k === 'a') e.tar += l.v; else e.dir += l.v }); else e.dir += c.v || 0
    })
  });
  (S.am || []).forEach(function (m) {
    if (m.t < a || m.t >= b) return;
    var id = apById(m.aid) ? m.aid : '_';
    if (m.tipo === 'premio') { ent(id).pre += m.v; dia(m.t, id, m.v) }
    else if (m.tipo === 'comision' || m.tipo === 'recarga') { ent(id).cm += m.v; dia(m.t, id, -m.v) }
    else if (m.tipo === 'retiro' && m.cr > 0) { ent(id).cm += m.cr; ent(id).rf += m.cr; dia(m.t, id, -m.cr) }
  });
  return R
}
function rtNom(id) { return id === '_' ? 'Sin app' : apNom(id) }
function rtGanDias(Y, M) {
  var R = rtNet(new Date(Y, M, 1).getTime(), new Date(Y, M + 1, 1).getTime()), W = {};
  Object.keys(R.dias).forEach(function (k) {
    var best = null; Object.keys(R.dias[k]).forEach(function (id) { if (id !== '_' && (best === null || R.dias[k][id] > R.dias[k][best])) best = id });
    if (best !== null && R.dias[k][best] > 0) W[k] = best
  });
  return W
}
function rtBadge(id) {
  if (!id) return '';
  var i = apList().map(function (a) { return a.id }).indexOf(id), n = apNom(id);
  return '<em class="wn c' + (i < 0 ? 0 : i % 4) + '" title="Más rentable: ' + esc(n) + '">' + esc((n || '?').charAt(0).toUpperCase()) + '</em>'
}
function rtCard(p) {
  if (!p || p.bad) return '';
  var R = rtNet(p.a, p.b), ids = Object.keys(R.apps); if (!ids.length) return '';
  var rows = ids.map(function (id) { var e = R.apps[id]; return { id: id, nom: rtNom(id), net: e.ing + e.pre - e.cm, ing: e.ing, pre: e.pre, cm: e.cm, n: e.n, dir: e.dir, tar: e.tar, rf: e.rf } }).sort(function (x, y) { return y.net - x.net });
  var max = Math.max.apply(null, rows.map(function (r) { return Math.max(r.net, 0) })) || 1, conApp = rows.filter(function (r) { return r.id !== '_' });
  var win = conApp.length > 1 && conApp[0].net > 0 && conApp[0].net > conApp[1].net ? conApp[0].id : null;
  var h = '<h2>🏆 Rentabilidad por app</h2><div class="card">' + rows.map(function (r) {
    return '<div class="rt"><div class="row"><b>' + (r.id === win ? '🏆 ' : '') + esc(r.nom) + '</b><b class="big ' + (r.net < 0 ? 'neg' : 'pos') + '">' + cop(r.net) + '</b></div>' +
      '<div class="pbar ok"><i style="width:' + Math.max(0, Math.min(100, r.net / max * 100)) + '%"></i></div>' +
      '<small>' + r.n + (r.n === 1 ? ' viaje' : ' viajes') + (r.n ? ' · ' + cop(r.net / r.n) + ' por viaje' : '') + '<br>Ingresos ' + cop(r.ing) + (r.pre ? ' + premios ' + cop(r.pre) : '') + ' − comisiones ' + cop(r.cm) + (r.rf ? ' (incluye ' + cop(r.rf) + ' de retiros)' : '') + (r.n ? '<br>💵 Directo a ti ' + cop(r.dir) + ' · 💳 Pagado por la app ' + cop(r.tar) : '') + '</small></div>'
  }).join('') + '</div>';
  if (p.b - p.a > 86400000 * 1.5) {
    var ks = Object.keys(R.dias).map(function (k) { var q = k.split('-'); return { k: k, t: new Date(+q[0], +q[1], +q[2]).getTime() } }).sort(function (x, y) { return y.t - x.t });
    h += '<button class="btn out sm" onclick="rtDias=!rtDias;render()">' + (rtDias ? '🔽' : '▶️') + ' Día por día (' + ks.length + ')</button>';
    if (rtDias) h += ks.map(function (x) {
      var o = R.dias[x.k], l = Object.keys(o).sort(function (a, b) { return o[b] - o[a] });
      return '<div class="li"><div class="row"><b>' + fd(x.t) + '</b><small>' + l.map(function (id, i) { return (i === 0 && l.length > 1 && o[id] > 0 ? '🏆 ' : '') + esc(rtNom(id)) + ' ' + cop(o[id]) }).join(' · ') + '</small></div></div>'
    }).join('')
  }
  return h
}

/* ================= Premios en el Historial ================= */
function prLista(a, b) { return (S.am || []).filter(function (m) { return m.tipo === 'premio' && m.t >= a && m.t < b }).sort(function (x, y) { return y.t - x.t }) }
function prFila(m) {
  return '<div class="li tap fh" onclick="tab=\'fin\';fsub=\'apps\';adet=\'' + m.aid + '\';render();window.scrollTo(0,0)"><div class="wr" style="padding:0"><span class="ic">🎁</span><div class="g"><b>Premio' + (m.pt ? ' · ' + ptNom(m.pt).replace(/^\S+\s/, '') : '') + ' · ' + esc(apNom(m.aid)) + '</b><br><small>' + fd(m.t) + ' ' + hm(m.t) + (m.nota ? ' · ' + esc(m.nota) : '') + '</small></div><b class="big pos">+' + cop(m.v) + '</b></div></div>'
}
function prHist(p) {
  if (!p || p.bad) return '';
  var l = prLista(p.a, p.b); if (!l.length) return '';
  var t = 0; l.forEach(function (m) { t += m.v });
  return '<h2>🎁 Premios (' + l.length + ') · ' + cop(t) + '</h2>' + l.map(prFila).join('')
}
function prDet(j) {
  var l = prLista(j.ini, (j.fin || Date.now()) + 1); if (!l.length) return '';
  var t = 0; l.forEach(function (m) { t += m.v });
  return '<h2>🎁 Premios de esta jornada · ' + cop(t) + '</h2>' + l.map(prFila).join('')
}

/* ================= Fondos fijos y de ahorro + «Apartar hoy» =================
   S.fo[i] extra: tp 'fijo'|'ahorro'|(vacío = libre) · ic emoji · pr prioridad 1-9 · bl billetera habitual · pz pausado
   fijo: mo monto · fq m|q|s|a|u · pv próximo pago · dp día del mes · rd aviso (días) · ld id de la deuda enlazada
   ahorro: ad monto por día · ap % de lo que ganas ese día · fl fecha meta · obj objetivo.
   Todo se calcula (cuota, faltante, proyección); lo único que se guarda son aportes y retiros, como siempre. */
var FXDIA = 86400000, FXQ = { m: 'Cada mes', q: 'Cada 15 días', s: 'Cada semana', a: 'Cada año', u: 'Una sola vez' };
function fxFormTipo(v) {
  function sh(id, on) { var e = $(id); if (e) e.style.display = on ? '' : 'none' }
  sh('#fxF', v === 'fijo'); sh('#fxO', v !== 'fijo'); sh('#fxA', v === 'ahorro'); sh('#fxP', v !== 'libre')
}
function fxDias(f) { return Math.round((d0(f.pv) - d0(Date.now())) / FXDIA) }
function fxFalta(f) { return Math.max(0, (f.mo || 0) - fSaldo(f.id)) }
function fxAporteHoy(f) { var a = d0(Date.now()), b = a + FXDIA, s = 0; fMovs(f.id).forEach(function (m) { if (m.tipo === 'aporte' && m.t >= a && m.t < b) s += m.v }); return s }
function fxSaldoIni(f) { var a = d0(Date.now()), s = fSaldo(f.id); fMovs(f.id).forEach(function (m) { if (m.tipo !== 'inicial' && m.t >= a) s -= fSig(m) }); return s }
function ganHoy() { var o = per; per = 'hoy'; var g = dash().gr; per = o; return g }
function fxProm() { var a = Date.now() - 30 * FXDIA, s = 0; (S.j || []).forEach(function (j) { if (j.ini >= a) s += js(j).gr }); return Math.max(0, s / 30) }
/* Lo que toca apartar cada día para ese fondo (sin descontar lo ya apartado hoy). */
function fxCuota(f) {
  if (f.pz) return 0;
  var s0 = fxSaldoIni(f);
  if (f.tp === 'fijo') {
    if (!(f.mo > 0) || !f.pv) return 0;
    var falta0 = Math.max(0, f.mo - s0); if (falta0 <= 0) return 0;
    return Math.min(falta0, Math.ceil(falta0 / Math.max(1, fxDias(f)) / 100) * 100)
  }
  if (f.tp === 'ahorro') {
    if (f.obj > 0 && s0 >= f.obj) return 0;
    if (f.ap > 0) return Math.round(Math.max(0, ganHoy()) * f.ap / 100);
    if (f.ad > 0) return f.ad;
    if (f.obj > 0 && f.fl) return Math.ceil(Math.max(0, f.obj - s0) / Math.max(1, Math.round((d0(f.fl) - d0(Date.now())) / FXDIA)) / 100) * 100;
    return 0
  }
  return 0
}
function fxPend(f) {
  var c = fxCuota(f); if (!(c > 0)) return 0;
  var r = Math.max(0, c - fxAporteHoy(f));
  if (f.tp === 'fijo') r = Math.min(r, fxFalta(f));
  else if (f.obj > 0) r = Math.min(r, Math.max(0, f.obj - fSaldo(f.id)));
  return Math.round(r)
}
function fxHoy() {
  var r = [];
  fFondos().forEach(function (f) { if (f.arch || f.pz || (f.tp !== 'fijo' && f.tp !== 'ahorro')) return; var v = fxPend(f); if (v >= 1) r.push({ f: f, v: v }) });
  r.sort(function (a, b) { return fxIx(a.f) - fxIx(b.f) || (a.f.tp === 'fijo' ? 0 : 1) - (b.f.tp === 'fijo' ? 0 : 1) || (a.f.pr || 5) - (b.f.pr || 5) || (a.f.pv || Infinity) - (b.f.pv || Infinity) });
  return r
}
function apHoyItem() {
  var l = fxHoy(); if (!l.length) return null;
  var t = 0; l.forEach(function (x) { t += x.v });
  return { k: 'apartar', sev: 2, ic: '📌', tx: 'Apartar hoy · ' + cop(t), sub: l.length + (l.length === 1 ? ' fondo' : ' fondos') + ' por alimentar', t: Date.now(), go: ['fin', 'fondos', null, null] }
}
function fxHoyHTML() {
  var l = fxHoy(); if (!l.length) return '';
  var t = 0; l.forEach(function (x) { t += x.v });
  var as = fxAsig(l), A = 0; as.forEach(function (x) { A += x.a });
  var g = mdDisp(), fj = 0; l.forEach(function (x) { if (x.f.tp === 'fijo') fj += x.v });
  return '<h2>📌 Apartar hoy · ' + cop(t) + '</h2><div class="card">' + as.map(function (x) {
    return '<div class="kv tap" style="cursor:pointer" onclick="fxApartar(\'' + x.f.id + '\')"><span>' + esc(x.f.ic || (x.f.tp === 'fijo' ? '📌' : '🎯')) + ' ' + esc(x.f.nom) + ' <small>' + (x.f.tp === 'fijo' ? 'fijo' : 'ahorro') + '</small></span><b>' + cop(x.v) + ' ›' + (x.a < x.v ? '<br><small>alcanza ' + cop(x.a) + '</small>' : '') + '</b></div>'
  }).join('') + (A >= 1 ? '<button class="btn" style="margin-top:10px" onclick="fxTodo()">Apartar ' + (A < t ? 'lo que alcanza' : 'todo') + ' (' + cop(A) + ')</button>' : '<small style="display:block;margin-top:10px">Aún no hay ganancia de hoy para apartar. Toca un fondo si quieres apartar igual.</small>') +
    '<small style="display:block;margin-top:8px">' + (mdMeta().modo ? 'Disponible hoy para fondos (ingresos menos gastos del día): <b>' : 'Ganado hoy (neto de costos): <b>') + cop(g) + '</b>' + (A < t ? ' · hoy no alcanza para todo: se aparta primero lo de tu orden de prioridad y lo que falte se suma a la cuota de los próximos días (en los fijos)' : '') + '. Toca uno para apartar solo ese.</small>' +
    '<button class="btn out sm" style="margin-top:8px" onclick="ctlOrden()">↕️ Orden de prioridad</button></div>'
}
function fxApartar(id) {
  var f = fById(id); if (!f) return; var v = fxPend(f);
  fMov(id, 'aporte');
  if ($('#fv')) { $('#fv').value = v > 0 ? v : ''; if (f.bl && BILX.indexOf(f.bl) >= 0) $('#fb').value = f.bl; $('#fnt').value = 'Apartado del día' }
}
function fxTodo() {
  var l = fxAsig(fxHoy()).filter(function (x) { return x.a >= 1 }); if (!l.length) return; var w = wal(), t = 0, b0 = fLastBil || BIL[0] || '';
  l.forEach(function (x) { t += x.a });
  openM('<h3>📌 Apartar lo de hoy</h3><p>Se registra un aporte a cada fondo, <b>' + cop(t) + '</b> en total.</p>' + l.map(function (x) { return '<div class="kv"><span>' + esc(x.f.ic || '📌') + ' ' + esc(x.f.nom) + '</span><b>' + cop(x.a) + '</b></div>' }).join('') +
    '<label style="margin-top:10px">¿De qué billetera sale?<select id="fb2"><option value="">Sin afectar billetera</option>' + bilOpts([b0]).map(function (b) { return '<option value="' + esc(b) + '"' + (b0 === b ? ' selected' : '') + '>' + esc(wl(b)) + ' (' + cop(w[b].s) + ')</option>' }).join('') + '</select></label>' + btns('fxTodoOk()'))
}
function fxTodoOk() {
  var l = fxAsig(fxHoy()).filter(function (x) { return x.a >= 1 }), b = $('#fb2').value; if (!l.length) { closeM(); return }
  if (BILX.indexOf(b) < 0) b = '';
  fEns(); var n = Date.now(), t = 0;
  l.forEach(function (x) { S.fm.push({ id: uid(), fid: x.f.id, t: n, tipo: 'aporte', v: x.a, bil: b || null, nota: 'Apartado del día', ua: n }); x.f.ua = n; t += x.a });
  fLastBil = b; sv(); closeM(); render();
  var neg = b && wal()[b].s < 0; toast(neg ? '⚠️ Apartado ' + cop(t) + '. ' + bn(b) + ' quedó en ' + cop(wal()[b].s) : '✅ Apartaste ' + cop(t))
}
function fxPausar(id) { var f = fById(id); if (!f) return; if (f.pz) delete f.pz; else f.pz = true; f.ua = Date.now(); sv(); render(); toast(f.pz ? '⏸️ Fondo en pausa' : '▶️ Fondo reanudado') }
/* ---- textos ---- */
function fxFijoTxt(f) {
  if (!(f.mo > 0)) return '⚙️ Falta el monto a pagar';
  if (!f.pv) return '⚙️ Falta la fecha del próximo pago';
  var d = fxDias(f), falta = fxFalta(f), c = fxCuota(f),
    cuando = d < 0 ? '⚠️ Venció hace ' + avDia(-d) : d === 0 ? '⏰ Se paga hoy' : d === 1 ? '⏰ Se paga mañana' : '📅 Se paga ' + fd(f.pv);
  if (f.pz) return cuando + ' · ⏸️ pausado';
  if (falta < 0.5) return cuando + ' · ✅ ya está completo';
  return cuando + ' · faltan ' + cop(falta) + (d > 0 && c ? ' · ' + cop(c) + ' por día' : '')
}
function fxEta(f) {
  if (!(f.obj > 0)) return '';
  var s = fSaldo(f.id); if (s >= f.obj) return '🎉 Meta alcanzada';
  var rate = f.ap > 0 ? fxProm() * f.ap / 100 : f.ad > 0 ? f.ad : 0; if (!(rate > 0)) return '';
  var d = Math.ceil((f.obj - s) / rate), tx = d < 60 ? d + ' días' : d < 700 ? 'unos ' + Math.round(d / 30) + ' meses' : 'unos ' + (d / 365).toFixed(1).replace('.0', '') + ' años';
  return '⏳ A este ritmo lo logras en ' + tx
}
function fxAhorroTxt(f) {
  var a = f.ap > 0 ? '🎯 ' + f.ap + ' % de lo que ganas cada día' : f.ad > 0 ? '🎯 ' + cop(f.ad) + ' por día' : (f.obj > 0 && f.fl) ? '🎯 Sugerido ' + cop(fxCuota(f)) + ' por día hasta ' + fd(f.fl) : 'Tú decides cuánto apartar';
  var e = fxEta(f); return a + (f.pz ? ' · ⏸️ pausado' : '') + (e && e.indexOf('🎉') < 0 ? ' · ' + e : '')
}
function fxInfo(f) {
  var tp = f.tp || 'libre', r = '', b = f.bl && BILX.indexOf(f.bl) >= 0 ? wl(f.bl) : 'Preguntar cada vez';
  if (tp === 'fijo') {
    r += kv('💵 Monto a pagar', f.mo > 0 ? cop(f.mo) : 'Sin definir') + kv('🔁 Se repite', FXQ[f.fq || 'm']) + kv('📅 Próximo pago', f.pv ? fdl(f.pv) : 'Sin fecha') +
      (f.pv && f.mo > 0 ? kv('💰 Faltan', cop(fxFalta(f))) + kv('📌 Aparta por día', cop(fxCuota(f))) + kv('✅ Ya apartaste hoy', cop(fxAporteHoy(f))) : '');
    if (f.ld) { var d = cuById(CU.deudas, f.ld); if (d) r += kv('💳 Deuda enlazada', esc(d.nom) + ' · saldo ' + cop(Math.max(0, cuSaldo(CU.deudas, d.id)))) }
    if (f.rd > 0) r += kv('🔔 Aviso', avDia(f.rd) + ' antes')
  } else if (tp === 'ahorro') {
    r += kv('📌 Cómo apartas', fxAhorroTxt(f).replace(/^🎯 /, '').split(' · ')[0]) + (f.fl ? kv('📅 Fecha meta', fdl(f.fl)) : '') + kv('✅ Ya apartaste hoy', cop(fxAporteHoy(f)));
    var e = fxEta(f); if (e) r += kv('⏳ Proyección', e.replace('⏳ ', ''))
  } else return '';
  return '<div class="card" style="padding:4px 16px;margin-top:10px">' + r + kv('↕️ Prioridad', f.pr || 5) + kv('👛 Billetera', esc(b)) + '</div>'
}
/* ---- pagar un gasto fijo ---- */
function fxSig(f, desde) {
  var q = f.fq || 'm'; if (q === 'u') return null;
  var dp = f.dp || new Date(f.pv).getDate();
  function nx(t) {
    var x = new Date(t);
    if (q === 's') return addD(t, 7); if (q === 'q') return addD(t, 15);
    if (q === 'a') return new Date(x.getFullYear() + 1, x.getMonth(), Math.min(dp, new Date(x.getFullYear() + 1, x.getMonth() + 1, 0).getDate())).getTime();
    return new Date(x.getFullYear(), x.getMonth() + 1, Math.min(dp, new Date(x.getFullYear(), x.getMonth() + 2, 0).getDate())).getTime()
  }
  var t = nx(f.pv), i = 0; while (t < d0(desde || Date.now()) && i < 60) { t = nx(t); i++ }
  return t
}
function fxPagar(id) {
  var f = fById(id); if (!f || f.arch) return; var s = fSaldo(id), w = wal(), v0 = f.mo > 0 ? f.mo : s, b0 = f.bl || fLastBil || '', d = f.ld ? cuById(CU.deudas, f.ld) : null;
  openM('<h3>✅ Pagar “' + esc(f.nom) + '”</h3><p>Saldo del fondo: <b>' + cop(s) + '</b>. El pago sale del fondo, no de tu presupuesto del día.' + (d ? ' También se registra como pago en la deuda “' + esc(d.nom) + '”.' : '') + '</p>' +
    '<label>Valor pagado<input id="pgv" type="number" inputmode="numeric" min="0" value="' + (v0 > 0 ? Math.round(v0) : '') + '"></label>' +
    '<label>Fecha y hora<input id="pgt" type="datetime-local" value="' + ldt(Date.now()) + '"></label>' +
    '<label>Si el fondo no alcanza, el faltante sale de<select id="pgb"><option value="">Sin afectar billetera</option>' + bilOpts([b0]).map(function (b) { return '<option value="' + esc(b) + '"' + (b0 === b ? ' selected' : '') + '>' + esc(wl(b)) + ' (' + cop(w[b].s) + ')</option>' }).join('') + '</select></label>' +
    btns("fxPagarOk('" + id + "')"))
}
function fxPagarOk(id) {
  var f = fById(id); if (!f) { closeM(); return }
  var v = num('#pgv'), t = pdt($('#pgt').value), b = $('#pgb').value; if (!(v > 0) || t === null) { toast('Revisa el valor y la fecha'); return }
  if (BILX.indexOf(b) < 0) b = '';
  fEns(); var n = Date.now(), s = fSaldo(id), falta = Math.max(0, v - s), nota = 'Pago de ' + f.nom;
  if (falta > 0) S.fm.push({ id: uid(), fid: id, t: t, tipo: 'aporte', v: falta, bil: b || null, nota: 'Faltante para pagar', ua: n });
  S.fm.push({ id: uid(), fid: id, t: t, tipo: 'retiro', v: v, bil: null, nota: nota, ua: n });
  var d = f.ld ? cuById(CU.deudas, f.ld) : null, pg = 0;
  if (d) { pg = Math.min(v, Math.max(0, cuSaldo(CU.deudas, d.id))); if (pg > 0) { cuEns(CU.deudas); S.dm.push({ id: uid(), cid: d.id, t: t, tipo: 'pago', v: pg, bil: null, nota: 'Pago desde el fondo “' + f.nom + '”', ua: n }); d.ua = n } }
  if (f.tp === 'fijo' && f.pv) { var nx = fxSig(f, t); if (nx) f.pv = nx; else { f.pv = null; f.pz = true } }
  f.ua = n; fLastBil = b || fLastBil; sv(); closeM(); render();
  toast(d && pg < v ? '✅ Pagado. A la deuda se registraron ' + cop(pg) + ' (lo que debía)' : '✅ Pago registrado' + (f.pv ? ' · próximo ' + fd(f.pv) : ''))
}
/* ---- deudas con cuota: su fondo de pago ---- */
function fxPvDia(cd) {
  var n = new Date(), y = n.getFullYear(), m = n.getMonth();
  function mk(yy, mm) { return new Date(yy, mm, Math.min(cd, new Date(yy, mm + 1, 0).getDate())).getTime() }
  var t = mk(y, m); if (t < d0(Date.now())) t = mk(y, m + 1); return t
}
function fxSyncDeuda(d) {
  fEns(); var f = S.fo.filter(function (x) { return x.ld === d.id })[0], n = Date.now();
  if (d.cq > 0 && d.cd > 0) {
    if (!f) { f = { id: uid(), nom: 'Cuota ' + d.nom, arch: false, ca: n, ua: n, tp: 'fijo', ic: '💳', fq: 'm', pr: 2, ld: d.id }; var nm = f.nom, i = 2; while (S.fo.some(function (x) { return x.nom.toLowerCase() === f.nom.toLowerCase() })) f.nom = nm + ' (' + (i++) + ')'; S.fo.push(f) }
    f.mo = d.cq; f.obj = d.cq; f.fq = 'm'; f.arch = false; f.ua = n; if (f.dp !== d.cd || !f.pv) { f.dp = d.cd; f.pv = fxPvDia(d.cd) }
    if (d.rd > 0) f.rd = d.rd; else delete f.rd
  } else if (f) {
    if (fMovs(f.id).length) { f.arch = true; f.ua = n } else S.fo = S.fo.filter(function (x) { return x.id !== f.id })
  }
}
function fxDesligarDeuda(id) { (S.fo || []).forEach(function (f) { if (f.ld === id) delete f.ld }) }
/* ---- fondos iniciales (una sola vez): vacíos, para completar en la app ---- */
function mjSeed() {
  if (S.sd) return;
  /* Nunca guardar encima de datos que no se pudieron leer: si fj1 está dañado o no se pudo normalizar, no se toca. */
  if (fjSeg && fjSeg.norm && fjSeg.norm.error) return;
  try { if (r0) JSON.parse(r0) } catch (e) { return }
  fEns(); var n = Date.now();
  [{ nom: 'Celular Tigo', tp: 'fijo', ic: '📱', mo: 99000, obj: 99000, fq: 'm', pr: 1 }, { nom: 'Aporte casa', tp: 'fijo', ic: '🏠', fq: 'm', pr: 1 }, { nom: 'Moto', tp: 'ahorro', ic: '🏍️', pr: 3 }].forEach(function (x) {
    if (S.fo.some(function (y) { return y.nom.toLowerCase() === x.nom.toLowerCase() })) return;
    var f = { id: uid(), arch: false, ca: n, ua: n }; Object.keys(x).forEach(function (k) { f[k] = x[k] }); S.fo.push(f)
  });
  S.sd = 1; sv()
}
mjSeed();
