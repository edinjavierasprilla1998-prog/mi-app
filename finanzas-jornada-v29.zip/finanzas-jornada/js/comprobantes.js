/* Comprobantes de pago por transferencia (fj-v26).
   Las fotos se guardan comprimidas en IndexedDB ('fj-comprobantes'), NO en localStorage.
   La carrera solo guarda c.cp (id de la foto) y c.rf (referencia opcional). */
var CPDB = null, CPQ = { id: null, rf: '' };
function cpDB() {
  if (CPDB) return CPDB;
  CPDB = new Promise(function (res, rej) {
    try {
      if (!window.indexedDB) throw new Error('IndexedDB no disponible en este navegador.');
      var q = indexedDB.open('fj-comprobantes', 1);
      q.onupgradeneeded = function () { var d = q.result; if (!d.objectStoreNames.contains('img')) d.createObjectStore('img', { keyPath: 'id' }) };
      q.onsuccess = function () { res(q.result) };
      q.onerror = function () { rej(q.error || new Error('No se pudo abrir el almacén de comprobantes.')) }
    } catch (e) { rej(e) }
  });
  return CPDB
}
function cpTx(modo, fn) {
  return cpDB().then(function (db) {
    return new Promise(function (res, rej) {
      var t = db.transaction('img', modo), rq = fn(t.objectStore('img'));
      t.oncomplete = function () { res(rq ? rq.result : undefined) };
      t.onerror = t.onabort = function () { rej(t.error || new Error('Error al guardar el comprobante.')) }
    })
  })
}
function cpGet(id) { return cpTx('readonly', function (s) { return s.get(id) }) }
function cpPut(r) { return cpTx('readwrite', function (s) { return s.put(r) }) }
function cpDel(id) { if (!id) return Promise.resolve(); return cpTx('readwrite', function (s) { return s.delete(id) }).catch(function () { }) }
function cpClear() { return cpTx('readwrite', function (s) { return s.clear() }).catch(function () { }) }
function cpAll() { return cpTx('readonly', function (s) { return s.getAll() }) }

function cpComprimir(file) {
  return new Promise(function (res, rej) {
    var url = URL.createObjectURL(file), im = new Image();
    im.onload = function () {
      var M = 1280, w = im.naturalWidth, h = im.naturalHeight, k = Math.min(1, M / Math.max(w, h)), cv = document.createElement('canvas');
      cv.width = Math.max(1, Math.round(w * k)); cv.height = Math.max(1, Math.round(h * k));
      var cx = cv.getContext('2d'); cx.fillStyle = '#fff'; cx.fillRect(0, 0, cv.width, cv.height); cx.drawImage(im, 0, 0, cv.width, cv.height);
      URL.revokeObjectURL(url);
      cv.toBlob(function (b) { b ? res(b) : rej(new Error('No se pudo procesar la imagen')) }, 'image/jpeg', 0.82)
    };
    im.onerror = function () { URL.revokeObjectURL(url); rej(new Error('No se pudo leer la imagen')) };
    im.src = url
  })
}
function cpPick(cam) {
  return new Promise(function (res) {
    var i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*'; i.style.display = 'none'; if (cam) i.setAttribute('capture', 'environment');
    i.onchange = function () { var f = i.files && i.files[0]; if (i.parentNode) i.parentNode.removeChild(i); res(f || null) };
    document.body.appendChild(i); i.click()
  })
}
/* Elige/toma la foto, la comprime y la guarda. Devuelve el id (o null si cancelaron). */
function cpNueva(cam) {
  return cpPick(cam).then(function (f) {
    if (!f) return null;
    toast('Guardando comprobante…');
    return cpComprimir(f).then(function (b) {
      var id = 'cp' + uid();
      return cpPut({ id: id, ts: Date.now(), blob: b, bytes: b.size }).then(function () { return id })
    })
  }).catch(function (e) { toast('No se pudo guardar el comprobante: ' + (e && e.message || e)); return null })
}

/* ---------- visor ---------- */
function cpVer(id) {
  cpGet(id).then(function (r) {
    if (!r || !r.blob) { toast('Ese comprobante no está en este teléfono (¿se restauró una copia en otro equipo?)'); return }
    var u = URL.createObjectURL(r.blob), d = document.createElement('div'), puede = false, fl = null;
    try { fl = new File([r.blob], 'comprobante.jpg', { type: 'image/jpeg' }); puede = !!(navigator.canShare && navigator.canShare({ files: [fl] })) } catch (e) { }
    d.id = 'cpv'; d.setAttribute('role', 'dialog'); d.setAttribute('aria-modal', 'true');
    d.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.92);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:12px';
    d.innerHTML = '<img alt="Comprobante" src="' + u + '" style="max-width:100%;max-height:80vh;object-fit:contain;border-radius:8px"><div style="display:flex;gap:8px;margin-top:12px"><button class="btn" id="cpvc">Cerrar</button>' + (puede ? '<button class="btn out" id="cpvs" style="background:#fff">Compartir</button>' : '') + '</div>';
    function cerrar() { URL.revokeObjectURL(u); if (d.parentNode) d.parentNode.removeChild(d) }
    d.addEventListener('click', function (e) { if (e.target === d) cerrar() });
    document.body.appendChild(d);
    document.getElementById('cpvc').onclick = cerrar;
    if (puede) document.getElementById('cpvs').onclick = function () { navigator.share({ files: [fl], title: 'Comprobante' }).catch(function () { }) }
  }).catch(function () { toast('No se pudo abrir el comprobante') })
}

/* ---------- en la lista de viajes ---------- */
function cpEsTransf(c) { return Array.isArray(c.pg) && c.pg.some(function (l) { return l.k === 'b' && l.b !== 'Efectivo' }) }
function cpDetTxt(c, ji) {
  var s = '';
  if (c.rf) s += ' · ref ' + esc(c.rf);
  if (c.cp) s += ' · <button class="mini" onclick="cpVer(\'' + c.cp + '\')">📎 Ver comprobante</button>';
  else if (ji && cpEsTransf(c)) s += ' · 📎 <button class="mini" onclick="cpRapido(\'' + ji + '\',\'' + c.id + '\',1)">📷 Foto</button> <button class="mini" onclick="cpRapido(\'' + ji + '\',\'' + c.id + '\')">🖼️ Galería</button>';
  return s
}
function cpRapido(ji, ci, cam) {
  cpNueva(cam).then(function (id) {
    if (!id) return;
    var j = jf(ji), c = j && j.ca.filter(function (x) { return x.id === ci })[0];
    if (!c) { cpDel(id); return }
    c.cp = id; sv(); render(); toast('📎 Comprobante guardado')
  })
}

/* ---------- formulario rápido (Registrar viaje) ---------- */
function cpQHTML() {
  return '<div id="cpq">' + (CPQ.id
    ? '<div class="kv"><span>📎 Comprobante listo</span><b><button class="mini" onclick="cpVer(CPQ.id)">Ver</button> <button class="mini bad" onclick="cpQQuitar()">Quitar</button></b></div>' +
    '<label>Referencia o nombre de quien pagó (opcional)<input id="vrf" type="text" value="' + esc(CPQ.rf || '') + '" oninput="CPQ.rf=this.value"></label>'
    : '<small style="display:block;font-weight:600;margin-bottom:4px">📎 Comprobante de transferencia (opcional)</small><div class="two"><button class="btn out sm" onclick="cpQAdd(1)">📷 Tomar foto</button><button class="btn out sm" onclick="cpQAdd()">🖼️ Galería</button></div>') + '</div>'
}
function cpQPaint() { var e = $('#cpq'); if (e) e.outerHTML = cpQHTML() }
function cpQAdd(cam) { cpNueva(cam).then(function (id) { if (!id) return; if (CPQ.id) cpDel(CPQ.id); CPQ.id = id; cpQPaint(); toast('📎 Listo: ahora toca cómo te pagaron') }) }
function cpQQuitar() { cpDel(CPQ.id); CPQ = { id: null, rf: '' }; cpQPaint() }
function cpQLimpiar() { CPQ = { id: null, rf: '' } }

/* ---------- ventana de editar / pago combinado ---------- */
function cpBoxInner() {
  return '<div id="cpbox">' + (VJ.cp
    ? '<div class="kv"><span>📎 Comprobante</span><b><button class="mini" onclick="cpVer(VJ.cp)">Ver</button> <button class="mini" onclick="cpVJAdd()">Cambiar</button> <button class="mini bad" onclick="cpVJQuitar()">Quitar</button></b></div>'
    : '<small style="display:block;font-weight:600;margin-bottom:4px">📎 Comprobante</small><div class="two"><button class="btn out sm" onclick="cpVJAdd(1)">📷 Tomar foto</button><button class="btn out sm" onclick="cpVJAdd()">🖼️ Galería</button></div>') + '</div>'
}
function cpBoxHTML() {
  return cpBoxInner() + '<label>Referencia o nombre de quien pagó (opcional)<input id="vcr" type="text" value="' + esc(VJ.rf || '') + '" oninput="VJ.rf=this.value"></label>'
}
function cpVJPaint() { var e = $('#cpbox'); if (e) e.outerHTML = cpBoxInner() }
function cpVJAdd(cam) { cpNueva(cam).then(function (id) { if (!id) return; VJ.cp = id; cpVJPaint() }) }
function cpVJQuitar() { VJ.cp = null; cpVJPaint() }

/* ---------- mantenimiento ---------- */
function cpLimpiar() {
  var uso = {}; (S.j || []).forEach(function (j) { (j.ca || []).forEach(function (c) { if (c.cp) uso[c.cp] = 1 }) });
  (S.mv || []).forEach(function (m) { if (m.cp) uso[m.cp] = 1 });
  if (CPQ.id) uso[CPQ.id] = 1;
  cpAll().then(function (l) { l.forEach(function (r) { if (!uso[r.id] && Date.now() - r.ts > 86400000) cpDel(r.id) }) }).catch(function () { })
}
function cpCfgHTML() {
  setTimeout(function () {
    cpAll().then(function (l) {
      var b = 0; l.forEach(function (r) { b += r.bytes || 0 }); var e = $('#cpinfo'); if (e) e.textContent = l.length ? l.length + ' foto' + (l.length === 1 ? '' : 's') + ' · ' + (b / 1048576).toFixed(1) + ' MB' : 'Aún no hay comprobantes guardados.'
    }).catch(function () { var e = $('#cpinfo'); if (e) e.textContent = 'No se pudo leer el almacén de comprobantes.' })
  }, 0);
  return '<h2>📎 Comprobantes</h2><div class="card"><div class="kv"><span>Guardados en este teléfono</span><b id="cpinfo">…</b></div><small>Las fotos se guardan comprimidas en este teléfono. <b>No van dentro de la copia de seguridad</b> (solo la referencia): si cambias de teléfono, no se mueven.</small></div>'
}
setTimeout(cpLimpiar, 4000);

/* ---------- comprobante en Movimientos (fj-v28) ---------- */
var MVC = { cp: null, rf: '', o: null };
function cpMovHTML() {
  return '<div id="cpmv">' + (MVC.cp
    ? '<div class="kv"><span>📎 Comprobante</span><b><button class="mini" onclick="cpVer(MVC.cp)">Ver</button> <button class="mini" onclick="cpMovAdd()">Cambiar</button> <button class="mini bad" onclick="cpMovQuitar()">Quitar</button></b></div>'
    : '<small style="display:block;font-weight:600;margin-bottom:4px">📎 Comprobante de transferencia (opcional)</small><div class="two"><button class="btn out sm" onclick="cpMovAdd(1)">📷 Tomar foto</button><button class="btn out sm" onclick="cpMovAdd()">🖼️ Galería</button></div>') +
    '</div><label>Referencia (opcional)<input id="mrf" type="text" value="' + esc(MVC.rf || '') + '" oninput="MVC.rf=this.value"></label>'
}
function cpMovPaint() { var e = $('#cpmv'); if (e) { var t = document.createElement('div'); t.innerHTML = cpMovHTML(); e.outerHTML = t.firstChild.outerHTML } }
function cpMovAdd(cam) { cpNueva(cam).then(function (id) { if (!id) return; if (MVC.cp && MVC.cp !== MVC.o) cpDel(MVC.cp); MVC.cp = id; cpMovPaint() }) }
function cpMovQuitar() { if (MVC.cp && MVC.cp !== MVC.o) cpDel(MVC.cp); MVC.cp = null; cpMovPaint() }
function cpMovReset(m) { MVC = m ? { cp: m.cp || null, rf: m.rf || '', o: m.cp || null } : { cp: null, rf: '', o: null } }
