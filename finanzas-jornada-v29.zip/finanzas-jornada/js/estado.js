/* Finanzas + Jornada — estado.js: estado, utilidades y cálculos (js, dash, wal). Separado de index.html en la Etapa 1, sin cambios de lógica. */

var K='fj1',S={j:[],mv:[],tema:'sistema'};
try{var r0=localStorage.getItem(K);if(r0)S=JSON.parse(r0)}catch(e){}
fjCargar();
function sv(){try{localStorage.setItem(K,JSON.stringify(S))}catch(e){}}
var tab='inicio',per='hoy',det=null,BIL=[],BILX=[],BN={},BI={};
/* Billeteras flexibles (Etapa 5): S.bw = {id,k,nom,ico,pay,arch}. Los movimientos guardan la CLAVE k en m.bil (nunca el nombre),
   así renombrar una billetera solo cambia nom. Las 4 claves por defecto ('Dinero digital','Daviplata','Efectivo','Propinas') no se borran, solo se archivan. */
function bwDef(){return [{id:'bw_nequi',k:'Dinero digital',nom:'Nequi',ico:'📱',pay:true,arch:false,ua:0},{id:'bw_daviplata',k:'Daviplata',nom:'Daviplata',ico:'📲',pay:true,arch:false,ua:0},{id:'bw_efectivo',k:'Efectivo',nom:'Efectivo',ico:'💵',pay:true,arch:false,ua:0},{id:'bw_propinas',k:'Propinas',nom:'Propinas',ico:'🎁',pay:false,arch:false,ua:0}]}
function apDef(){return [{id:'ap_didi',nom:'DiDi',arch:false,ua:0},{id:'ap_uber',nom:'Uber',arch:false,ua:0}]}
/* Recalcula BIL (claves activas), BILX (todas, incluso archivadas y referencias huérfanas), BN (nombres) y BI (íconos) a partir de un estado. */
function bilRefresh(st){st=st||S;var bw=Array.isArray(st.bw)?st.bw:bwDef(),n={},ic={},a=[],x=[];
bw.forEach(function(w){if(!w||typeof w.k!=='string')return;n[w.k]=w.nom||w.k;ic[w.k]=w.ico||'👛';x.push(w.k);if(!w.arch)a.push(w.k)});
function ref(k){if(typeof k==='string'&&k&&x.indexOf(k)<0){x.push(k);n[k]=k;ic[k]='❔'}}
ref('Dinero digital');ref('Propinas');
(st.mv||[]).forEach(function(m){ref(m.bil);ref(m.bil2)});
['fm','dm','pm','am'].forEach(function(l){(st[l]||[]).forEach(function(m){ref(m.bil)})});
(st.j||[]).forEach(function(j){(j.ca||[]).forEach(function(c){ref(c.pb);(c.pg||[]).forEach(function(l){ref(l.b)})})});
BIL=a;BILX=x;BN=n;BI=ic}
function bn(k){return BN[k]||k}
function wl(k){return (BI[k]||'❔')+' '+bn(k)}
function bilVis(w){return BILX.filter(function(b){var x=w[b];return BIL.indexOf(b)>=0||(x&&(x.i||x.g||x.t||Math.abs(x.s)>0.005))})}
function bilOpts(cur){return BIL.concat(cur.filter(function(b){return b&&BIL.indexOf(b)<0&&BILX.indexOf(b)>=0}))}
function bilSel(id,cur,extra){return '<select id="'+id+'">'+bilOpts([cur]).map(function(b){return '<option value="'+esc(b)+'"'+(cur===b?' selected':'')+'>'+esc(wl(b))+'</option>'}).join('')+(extra||'')+'</select>'}
var CO=['Gasolina','Alquiler de moto','Mantenimiento','Comisión y pase de apps','Otros'],CP=['Alimentación','Iglesia','Personal','Familia','Otros'];
var PA=[['🙏','Orar'],['🍳','Desayuno'],['🍽️','Almuerzo'],['🌧️','Lluvia'],['📱','Celular'],['🔧','Mantenimiento'],['🏍️','Moto varada'],['⏳','Espera'],['🏠','Descanso']];
function $(s){return document.querySelector(s)}
function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,6)}
function cop(n){return new Intl.NumberFormat('es-CO',{style:'currency',currency:'COP',maximumFractionDigits:0}).format(Math.round(n))}
function dur(ms){ms=Math.max(0,Math.floor(ms/1000));return Math.floor(ms/3600)+'h '+String(Math.floor(ms%3600/60)).padStart(2,'0')+'m '+String(ms%60).padStart(2,'0')+'s'}
function hm(t){return new Date(t).toLocaleTimeString('es-CO',{hour:'2-digit',minute:'2-digit',hour12:false})}
function fd(t){return new Date(t).toLocaleDateString('es-CO',{weekday:'short',day:'numeric',month:'short'})}
function dk(t){var d=new Date(t);return d.getFullYear()+'-'+d.getMonth()+'-'+d.getDate()}
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
var TT=null,UNDO=null;
function toast(m){var t=$('#toast');UNDO=null;t.textContent=m;t.style.display='block';clearTimeout(TT);TT=setTimeout(function(){t.style.display='none'},2200)}
function toastU(m,fn){var t=$('#toast');UNDO=fn;t.innerHTML='<span>'+esc(m)+'</span> <button class="tu" onclick="var f=UNDO;UNDO=null;$(\'#toast\').style.display=\'none\';if(f)f()">↩️ Deshacer</button>';t.style.display='block';clearTimeout(TT);TT=setTimeout(function(){t.style.display='none';UNDO=null},6000)}
function pstart(p){var d=new Date();d.setHours(0,0,0,0);if(p==='semana')d.setDate(d.getDate()-(d.getDay()+6)%7);if(p==='mes')d.setDate(1);return d.getTime()}
function act(){return S.j.filter(function(j){return !j.fin})[0]}
function js(j){var n=Date.now(),e=j.fin||n,tr=e-j.ini,ps=0,ing=0,co=0,gp=0;
j.pa.forEach(function(p){ps+=(p.b||n)-p.a});j.ca.forEach(function(c){ing+=c.v+c.p});
S.mv.forEach(function(m){if(m.t>=j.ini&&m.t<=e){if(m.tipo==='costo')co+=m.v;if(m.tipo==='personal')gp+=m.v}});
j.ca.forEach(function(c){co+=c.cm||0});var aw=amWin(j.ini,e);ing+=aw.ing;co+=aw.co;
var ef=Math.max(0,tr-ps),km=j.kf!=null?j.kf-j.ki:0,gr=ing-co;
return{tr:tr,ps:ps,ef:ef,ing:ing,co:co,gp:gp,gr:gr,dis:gr-gp,km:km,h:ef>=300000?gr/(ef/3600000):0,gk:km>0?gr/km:0,est:jEst(j)}}
function dash(){var a=pstart(per),ing=0,co=0,gp=0,ef=0,ps=0,km=0;
S.j.forEach(function(j){j.ca.forEach(function(c){if(c.t>=a){ing+=c.v+c.p;co+=c.cm||0}});if(j.ini>=a){var s=js(j);ef+=s.ef;ps+=s.ps;km+=s.km}});
S.mv.forEach(function(m){if(m.t<a)return;if(m.tipo==='ingreso')ing+=m.v;if(m.tipo==='costo')co+=m.v;if(m.tipo==='personal')gp+=m.v});
var aw=amWin(a,Infinity);ing+=aw.ing;co+=aw.co;
return{ing:ing,co:co,gp:gp,ef:ef,ps:ps,km:km,gr:ing-co,h:ef>=300000?(ing-co)/(ef/3600000):0}}
function wal(){var w={};BILX.forEach(function(b){w[b]={s:0,i:0,g:0,t:0}});
function W(k){return w[k]||(w[k]={s:0,i:0,g:0,t:0})}
/* Carreras: las nuevas (con pg) acreditan cada línea a su billetera; las antiguas (sin pg) siguen igual que siempre: valor a 'Dinero digital' y propina a 'Propinas'. */
S.j.forEach(function(j){j.ca.forEach(function(c){
 if(Array.isArray(c.pg)){c.pg.forEach(function(l){if(l.k==='b'&&l.b){var x=W(l.b);x.s+=l.v;x.i+=l.v}});if(c.p&&c.pb){var y=W(c.pb);y.s+=c.p;y.i+=c.p}}
 else{W('Dinero digital').s+=c.v;W('Dinero digital').i+=c.v;W('Propinas').s+=c.p;W('Propinas').i+=c.p}})});
S.mv.forEach(function(m){var a=W(m.bil);if(m.tipo==='ingreso'){a.s+=m.v;a.i+=m.v}else if(m.tipo==='transferencia'){var b=W(m.bil2);a.s-=m.v;a.t-=m.v;b.s+=m.v;b.t+=m.v}else if(m.tipo==='ajuste'){a.s+=(m.sg<0?-m.v:m.v)}else{a.s-=m.v;a.g+=m.v}});
(S.fm||[]).forEach(function(f){var x=f.bil&&W(f.bil);if(x&&f.tipo!=='inicial'){var d=f.tipo==='retiro'?f.v:-f.v;x.s+=d;x.t+=d}});
/* Etapa 3: deudas (pago sale, cargo entra) y préstamos (cobro entra, prestamo sale). 'inicial' no toca billeteras. */
(S.dm||[]).forEach(function(f){var x=f.bil&&W(f.bil);if(x&&f.tipo!=='inicial'){var d=f.tipo==='pago'?-f.v:f.v;x.s+=d;x.t+=d}});
(S.pm||[]).forEach(function(f){var x=f.bil&&W(f.bil);if(x&&(f.tipo!=='inicial'||f.bd)){var d=f.tipo==='cobro'?f.v:-f.v;x.s+=d;x.t+=d}});
/* Etapa 5: retiros de las apps entran a la billetera solo cuando se marcan como recibidos. */
(S.xm||[]).forEach(function(m){if(m.tipo==='cobro'&&m.bil){var x=W(m.bil);x.s+=m.v;x.i+=m.v}});
(S.am||[]).forEach(function(m){if(m.tipo==='retiro'&&m.est==='ok'&&m.bil){var x=W(m.bil),nt=m.v-(m.cr||0);x.s+=nt;x.t+=nt}});return w}
function num(id){var v=parseFloat($(id).value);return isNaN(v)?null:v}
function estTxt(j){var e=jEst(j);return hm(e)+(dk(e)!==dk(j.ini)?' (+1 día)':'')}
bilRefresh();
