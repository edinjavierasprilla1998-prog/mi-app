/* Finanzas + Jornada — acciones.js: acciones: jornadas, pausas, carreras, movimientos, ventanas. Separado de index.html en la Etapa 1, sin cambios de lógica. */
/* ---- acciones ---- */
function startJ(){if(act()){toast('Ya hay una jornada activa');return}var c=jfLeer(),h=c.h+c.mn/60,k=num('#ik');
if(!(h>0)||h>24||k===null||k<0){toast('Revisa horas (hasta 24) y km iniciales');return}
S.jc=Object.assign({},S.jc,{mt:c.mt,h:c.h,mn:c.mn,pv:c.pv,po:c.po});
S.j.push({id:uid(),ini:Date.now(),hp:Math.round(h*60)/60,mt:c.mt,pv:(c.po?c.pv.filter(function(x){return x.on&&x.m>0}).map(function(x){return{n:x.n,m:x.m}}):[]),ki:k,kf:null,fin:null,pa:[],ca:[]});sv();render()}
function endJ(){var j=act(),k=num('#kf');if(k===null||k<j.ki){toast('Los km finales deben ser ≥ '+j.ki);return}
var n=Date.now();j.pa.forEach(function(p){if(!p.b)p.b=n});j.kf=k;j.fin=n;sv();render()}
function startP(m){var j=act();if(!j)return;if(j.pa.some(function(p){return !p.b})){toast('Ya hay una pausa abierta');return}j.pa.push({id:uid(),m:m,a:Date.now(),b:null});sv();render()}
function endP(){var j=act();j.pa.forEach(function(p){if(!p.b)p.b=Date.now()});sv();render()}
function delC(ji,ci){var j=S.j.filter(function(x){return x.id===ji})[0];j.ca.forEach(function(c){if(c.id===ci)cpDel(c.cp)});j.ca=j.ca.filter(function(c){return c.id!==ci});sv();render()}
function delJ(ji){S.j=S.j.filter(function(x){return x.id!==ji});det=null;sv();render()}
var EM=null,RET=null,AF=null;
function ldt(t){var d=new Date(t);return iso(t)+'T'+String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0')}
function pdt(x){var t=new Date(x).getTime();return x&&!isNaN(t)?t:null}
function jf(id){return S.j.filter(function(x){return x.id===id})[0]}
function openM(h){$('#modal').innerHTML='<div class="mo" onclick="if(event.target===this)closeM()"><div class="sheet" role="dialog" aria-modal="true">'+h+'</div></div>'}
function closeM(){$('#modal').innerHTML=''}
function ask(b,fn,t){var L={pausa:'esta pausa',carrera:'esta carrera',jornada:'esta jornada'};AF=fn;openM('<h3>¿Eliminar '+(L[t]||'este movimiento')+'?</h3><p>Esta acción no se puede deshacer.</p><div class="two"><button class="btn out" onclick="closeM()">Cancelar</button><button class="btn bad" onclick="var f=AF;AF=null;closeM();f()">Eliminar</button></div>')}
function abtn(e,d,t){return '<div class="ab"><button class="ed" onclick="'+e+'">✏️ Editar</button><button onclick="ask(this,function(){'+d+'},\''+t+'\')">🗑️ Eliminar</button></div>'}
function btns(ok){return '<div class="two"><button class="btn out" onclick="closeM()">Cancelar</button><button class="btn" onclick="'+ok+'">Guardar</button></div>'}
function addM(){var tipo=$('#mt').value,v=num('#mv'),bil=$('#mb').value,b2=$('#mb2').value,t=pdt($('#mf').value)||Date.now();
if(!(v>0)){toast('Escribe un valor mayor que 0');return}
if(tipo==='transferencia'&&bil===b2){toast('Elige billeteras distintas');return}
var cat=tipo==='ingreso'?'Ingreso':tipo==='transferencia'?'Transferencia':$('#mc').value,n=Date.now(),l=S.mv[S.mv.length-1];
var rec={t:t,tipo:tipo,cat:cat,bil:bil,bil2:tipo==='transferencia'?b2:null,v:v,nota:$('#mn').value.slice(0,80)};var rfx=(MVC.rf||'').trim();if(MVC.cp)rec.cp=MVC.cp;if(rfx)rec.rf=rfx;
if(EM){var m=S.mv.filter(function(x){return x.id===EM})[0];if(m){for(var k in rec)m[k]=rec[k];if(!rec.cp)delete m.cp;if(!rec.rf)delete m.rf;if(MVC.o&&MVC.o!==MVC.cp)cpDel(MVC.o)}
cpMovReset();EM=null;var r=RET;RET=null;if(r==='hist')tab='hist';sv();render();toast('Movimiento actualizado');return}
if(l&&l.tipo===tipo&&l.v===v&&l.bil===bil&&l.cat===cat&&n-(l.cr||0)<5000){toast('Movimiento repetido, ignorado');return}
rec.id=uid();rec.cr=n;S.mv.push(rec);cpMovReset();sv();render()}
function fillEdit(){var m=EM&&S.mv.filter(function(x){return x.id===EM})[0];
if(!m){EM=null;$('#mf').value=ldt(Date.now());return}
$('#mt').value=m.tipo;fillC();if(m.tipo==='costo'||m.tipo==='personal')$('#mc').value=m.cat;
$('#mb').value=m.bil;if(m.bil2)$('#mb2').value=m.bil2;$('#mv').value=m.v;$('#mn').value=m.nota||'';$('#mf').value=ldt(m.t)}
function Medit(id,ret){cpMovReset(S.mv.filter(function(x){return x.id===id})[0]);EM=id;RET=ret||null;tab='mov';render();window.scrollTo(0,0)}
function Mcancel(){if(MVC.cp&&MVC.cp!==MVC.o)cpDel(MVC.cp);cpMovReset();EM=null;if(RET==='hist')tab='hist';RET=null;render()}
function PE(ji,pi){var p=jf(ji).pa.filter(function(x){return x.id===pi})[0];
openM('<h3>✏️ Editar pausa</h3><label>Motivo<select id="pm">'+paAll(p.m).map(function(x){return '<option'+(x[1]===p.m?' selected':'')+'>'+x[1]+'</option>'}).join('')+'</select></label><div class="two"><label>Inicio<input id="p1" type="datetime-local" value="'+ldt(p.a)+'"></label><label>Fin<input id="p2" type="datetime-local" value="'+(p.b?ldt(p.b):'')+'"></label></div><small>Deja el fin vacío si la pausa sigue abierta.</small><div style="height:12px"></div>'+btns("PS('"+ji+"','"+pi+"')"))}
function PS(ji,pi){var j=jf(ji),p=j.pa.filter(function(x){return x.id===pi})[0],a=pdt($('#p1').value),b=pdt($('#p2').value);
if(a===null||($('#p2').value&&b===null)||(b!==null&&b<=a)){toast('Revisa inicio y fin');return}
if(b===null&&(j.fin||j.pa.some(function(x){return x!==p&&!x.b}))){toast('Esta pausa necesita hora de fin');return}
p.m=$('#pm').value;p.a=a;p.b=b;sv();closeM();render()}
function delP(ji,pi){var j=jf(ji);j.pa=j.pa.filter(function(p){return p.id!==pi});sv();render()}
function JE(ji){var j=jf(ji);
openM('<h3>✏️ Editar jornada</h3><div class="two"><label>Inicio<input id="j1" type="datetime-local" value="'+ldt(j.ini)+'"></label><label>Salida<input id="j2" type="datetime-local" value="'+(j.fin?ldt(j.fin):'')+'"'+(j.fin?'':' disabled')+'></label><label>Horas programadas<input id="j3" type="number" step="0.25" inputmode="decimal" value="'+j.hp+'"></label><label>Km iniciales<input id="j4" type="number" inputmode="decimal" value="'+j.ki+'"></label></div>'+(j.fin?'<label>Km finales<input id="j5" type="number" inputmode="decimal" value="'+j.kf+'"></label>':'')+btns("JS('"+ji+"')"))}
function JS(ji){var j=jf(ji),a=pdt($('#j1').value),b=j.fin?pdt($('#j2').value):null,h=num('#j3'),ki=num('#j4'),kf=j.fin?num('#j5'):null;
if(a===null||(j.fin&&(b===null||b<=a))||!(h>0)||h>24||ki===null||ki<0||(j.fin&&(kf===null||kf<ki))){toast('Revisa fechas, horas y km');return}
j.ini=a;j.hp=h;j.ki=ki;if(j.fin){j.fin=b;j.kf=kf}sv();closeM();render()}
function movLi(m,ret){if(m.tipo==='ajuste'){return '<div class="li"><span class="ic">⚖️</span><div class="g"><b class="'+(m.sg<0?'neg':'pos')+'">'+(m.sg<0?'−':'+')+cop(m.v)+'</b> <span>Ajuste de saldo</span><br><small>'+fd(m.t)+' '+hm(m.t)+' · '+esc(wl(m.bil))+(m.nota?' · '+esc(m.nota):'')+'</small></div><div class="ab"><button onclick="ask(this,function(){delM(\''+m.id+'\')},\'movimiento\')">🗑️ Eliminar</button></div></div>'}
var neg=m.tipo==='costo'||m.tipo==='personal',a=m.tipo==='ingreso'?'+'+cop(m.v):neg?'−'+cop(m.v):cop(m.v);
return '<div class="li"><span class="ic">'+MI[m.tipo]+'</span><div class="g"><b class="'+(m.tipo==='ingreso'?'pos':neg?'neg':'')+'">'+a+'</b> <span>'+esc(m.cat)+'</span><br><small>'+fd(m.t)+' '+hm(m.t)+' · '+esc(wl(m.bil))+(m.bil2?' → '+esc(wl(m.bil2)):'')+(m.nota?' · '+esc(m.nota):'')+(m.rf?' · ref '+esc(m.rf):'')+(m.cp?' · <button class="mini" onclick="cpVer(\''+m.cp+'\')">📎 Ver comprobante</button>':'')+'</small></div>'+abtn("Medit('"+m.id+"','"+(ret||'')+"')","delM('"+m.id+"')",'movimiento').replace(/<\/div>$/,m.tipo==='ingreso'?'<button onclick="mvACobrar(\''+m.id+'\')">⏳ A por cobrar</button></div>':'</div>')+'</div>'}
function jmovs(j){var e=j.fin||Date.now(),l=S.mv.filter(function(m){return m.t>=j.ini&&m.t<=e}).sort(function(a,b){return b.t-a.t});
return l.length?'<h2>💰 Movimientos de la jornada</h2>'+l.map(function(m){return movLi(m,'hist')}).join(''):''}
function pausaList(j){return j.pa.slice().reverse().map(function(p){return '<div class="li"><span class="ic">⏸️</span><div class="g"><b>'+esc(p.m)+'</b><br><small>'+hm(p.a)+' → '+(p.b?hm(p.b):'abierta')+' · '+dur((p.b||Date.now())-p.a)+'</small></div>'+abtn("PE('"+j.id+"','"+p.id+"')","delP('"+j.id+"','"+p.id+"')",'pausa')+'</div>'}).join('')}
function delM(id){S.mv.forEach(function(m){if(m.id===id)cpDel(m.cp)});S.gl=(S.gl||[]).filter(function(x){return x.mid!==id});S.mv=S.mv.filter(function(m){return m.id!==id});sv();render()}
function fillC(){var t=$('#mt').value,c=$('#mc'),b2=$('#mb2').parentNode;
c.parentNode.style.display=(t==='costo'||t==='personal')?'block':'none';b2.style.display=t==='transferencia'?'block':'none';
c.innerHTML=ppCats(t==='personal'?'personal':'costo').map(function(x){return '<option>'+x+'</option>'}).join('')}
function go(t){tab=t;det=null;EM=null;RET=null;render()}
function setTema(v){S.tema=v;sv();render()}

/* Un ingreso que aún no te pagan: se quita de Ingresos y de la billetera y pasa a Por cobrar (entra al cobrarlo). */
function mvACobrar(id){var m=S.mv.filter(function(x){return x.id===id})[0];if(!m)return;
openM('<h3>⏳ Pasar a por cobrar</h3><p>Este ingreso de <b>'+cop(m.v)+'</b> aún no te lo pagan. Se quita de Ingresos y de la billetera y queda pendiente; entrará cuando lo cobres.</p><label>¿Quién te debe?<input id="xq" maxlength="40" value="'+esc(m.nota||'')+'" placeholder="Ej. Domicilio Laura"></label><label>Fecha límite (opcional)<input id="xf" type="date"></label>'+btns("mvACobrarOk('"+id+"')"))}
function mvACobrarOk(id){var m=S.mv.filter(function(x){return x.id===id})[0],nom=$('#xq').value.trim().slice(0,40),rf=$('#xf').value,fv=rf?pd(rf):null;if(!m){closeM();return}
if(!nom){toast('Escribe quién te debe');return}if(rf&&isNaN(fv)){toast('Revisa la fecha');return}
if(!Array.isArray(S.xc))S.xc=[];if(!Array.isArray(S.xm))S.xm=[];
if(S.xc.some(function(x){return x.nom.toLowerCase()===nom.toLowerCase()})){toast('Ya existe uno con ese nombre');return}
var n=Date.now(),f={id:uid(),nom:nom,fv:fv,arch:false,ca:n,ua:n};S.xc.push(f);S.xm.push({id:uid(),cid:f.id,t:m.t,tipo:'inicial',v:m.v,bil:null,nota:'Pasado desde Ingresos',ua:n});
S.mv=S.mv.filter(function(x){return x.id!==id});tab='fin';fsub='cobros';cdet=f.id;sv();closeM();render();toast('⏳ Pasado a por cobrar')}
