/* Finanzas + Jornada — control.js (Etapa 11): copia de seguridad (compartir + recordatorio), borrar todo y empezar de cero,
   meta diaria de ganancia y orden de prioridad de los fondos.
   Claves nuevas (opcionales): S.bk {on,dias,ult,ini} · S.mdc {on,pers,ex,lim} · S.fxo [ids de fondos en orden de prioridad]. */
var CTLDIA = 86400000;
/* ---------- copia de seguridad ---------- */
function bkCfg() { var c = S.bk || {}; return { on: c.on !== false, dias: c.dias >= 0 ? +c.dias : 7, ult: c.ult || 0, ini: c.ini || 0 } }
function bkSet(k, v) { S.bk = Object.assign({}, S.bk); S.bk[k] = v; sv(); render() }
function bkMarca() { S.bk = Object.assign({}, S.bk, { ult: Date.now() }); sv() }
function bkCompartir() {
  var raw = null; try { raw = localStorage.getItem(K) } catch (e) { }
  if (raw == null) raw = JSON.stringify(S);
  try {
    var pk = fjPaquete(raw); pk.origen = 'compartida';
    var nom = 'finanzas-jornada-backup-' + iso(Date.now()) + '.json', f = new File([JSON.stringify(pk, null, 2)], nom, { type: 'application/json' });
    if (navigator.canShare && navigator.canShare({ files: [f] }) && navigator.share) {
      navigator.share({ files: [f], title: 'Copia de seguridad · Finanzas + Jornada' }).then(function () { bkMarca(); render(); toast('✅ Copia compartida') }).catch(function (e) { if (!e || e.name !== 'AbortError') toast('No se pudo compartir; descargando…'), exportBackup() })
    } else exportBackup()
  } catch (e) { exportBackup() }
}
function bkAvisos() {
  var c = bkCfg(), n = Date.now(); if (!c.on || !(c.dias > 0)) return [];
  if (!c.ini && !c.ult) { S.bk = Object.assign({}, S.bk, { ini: n }); sv(); return [] }
  var ref = c.ult || c.ini; if (n - ref < c.dias * CTLDIA) return [];
  var d = Math.floor((n - ref) / CTLDIA);
  return [{ k: 'bkp', sev: 1, ic: '☁️', tx: c.ult ? 'Hace ' + avDia(d) + ' no guardas una copia de seguridad' : 'Aún no has guardado una copia de seguridad', sub: 'Compártela a Drive o WhatsApp con un toque (Ajustes)', t: n, go: ['cfg', typeof fsub !== 'undefined' ? fsub : null] }]
}
function bkHTML() {
  var c = bkCfg(), ds = [0, 3, 7, 14, 30];
  return '<h2>☁️ Copia de seguridad</h2><div class="card form"><button class="btn" onclick="bkCompartir()">📤 Compartir copia (Drive, WhatsApp…)</button>' +
    '<small style="display:block;margin:8px 0">' + (c.ult ? 'Última copia guardada: ' + fd(c.ult) + ' ' + hm(c.ult) : 'Aún no has guardado ninguna copia fuera de la app.') + ' Guárdala en tu Drive o mándala a tu WhatsApp: así no pierdes nada si cambias de celular o de enlace.</small>' +
    '<label>Recordarme cada<select onchange="bkSet(\'dias\',+this.value)">' + ds.map(function (n) { return '<option value="' + n + '"' + (c.dias === n ? ' selected' : '') + '>' + (n === 0 ? 'No recordar' : avDia(n)) + '</option>' }).join('') + '</select></label></div>'
}
/* ---------- borrar todo y empezar de cero ---------- */
function borrarHTML() {
  return '<h2>🗑️ Empezar de cero</h2><div class="card form"><button class="btn bad" onclick="borrarForm()">🗑️ Borrar todo y empezar de cero</button>' +
    '<small style="display:block;margin-top:8px">Antes de borrar se guarda una copia interna y se descarga un archivo. Así puedes volver atrás con “Importar / restaurar”.</small></div>'
}
function borrarForm() {
  openM('<h3>🗑️ Borrar todo</h3><p>Se borrarán <b>todas</b> tus jornadas, gastos, billeteras, deudas, fondos, apps y ajustes. La app quedará como nueva.</p>' +
    '<p>Antes se crea una copia interna y se descarga un archivo de respaldo.</p><label>Para confirmar escribe <b>BORRAR</b><input id="bkw" type="text" autocomplete="off" autocapitalize="characters"></label>' +
    '<div class="two"><button class="btn out" onclick="closeM()">Cancelar</button><button class="btn bad" onclick="borrarOk()">Borrar todo</button></div>')
}
function borrarOk() {
  if (($('#bkw').value || '').trim().toUpperCase() !== 'BORRAR') { toast('Escribe BORRAR para confirmar'); return }
  var raw = null; try { raw = localStorage.getItem(K) } catch (e) { }
  if (raw == null) raw = JSON.stringify(S);
  fjCrearSnap('pre-borrado', raw, 'Copia automática antes de borrar todo').then(function () {
    exportBackup();
    cpClear(); S = { j: [], mv: [], tema: S.tema || 'sistema', sd: 1 }; sv(); closeM(); toast('✅ Todo borrado. Empezando de cero…');
    setTimeout(function () { location.reload() }, 900)
  }).catch(function (e) { toast('No se borró nada: no se pudo crear la copia (' + (e && e.message || e) + ')') })
}
/* ---------- meta diaria de ganancia ---------- */
function mdCfg() {
  var c = S.mdc || {}, gd = [];
  (Array.isArray(c.gd) ? c.gd : []).forEach(function (x) { if (x && +x.m > 0) gd.push({ n: String(x.n || 'Gasto'), m: Math.round(+x.m), t: x.t === 'o' ? 'o' : 'p' }) });
  return { on: c.on !== false, pers: c.pers !== false, ex: c.ex > 0 ? +c.ex : 0, lim: c.lim !== false, mi: c.mi > 0 ? Math.round(+c.mi) : 0, gd: gd }
}
function mdSet(k, v) { S.mdc = Object.assign({}, S.mdc); S.mdc[k] = v; sv(); render() }
function mdExSet(v) { var n = parseFloat(v); mdSet('ex', n > 0 ? Math.round(n) : 0) }
function mdPers() {
  var a = Date.now() - 30 * CTLDIA, d = {}, t = 0;
  S.j.forEach(function (j) { if (j.ini >= a) d[dk(j.ini)] = 1 }); S.mv.forEach(function (m) { if (m.tipo === 'personal' && m.t >= a) t += m.v });
  var n = Object.keys(d).length; return n ? Math.round(t / n) : 0
}
function fxActivos() { return fFondos().filter(function (f) { return !f.arch && !f.pz && (f.tp === 'fijo' || f.tp === 'ahorro') }) }
function ingHoy() { var o = per; per = 'hoy'; var g = dash().ing; per = o; return g }
/* promedio diario de costos operativos de los últimos 30 días (solo se usa si no hay lista de gastos del día) */
function mdOp() {
  var a = Date.now() - 30 * CTLDIA, d = {}, t = 0;
  S.j.forEach(function (j) { if (j.ini >= a) d[dk(j.ini)] = 1; j.ca.forEach(function (c) { if (c.t >= a) t += c.cm || 0 }) });
  S.mv.forEach(function (m) { if (m.tipo === 'costo' && m.t >= a) t += m.v });
  var n = Object.keys(d).length; return n ? Math.round(t / n) : 0
}
function mdModo(c) { c = c || mdCfg(); return c.gd.length > 0 || c.mi > 0 }
function mdMeta() {
  var c = mdCfg(), fo = 0; fxActivos().forEach(function (f) { fo += fxCuota(f) }); fo = Math.round(fo);
  var modo = mdModo(c), o = 0, p = 0, auto = false;
  c.gd.forEach(function (x) { if (x.t === 'o') o += x.m; else p += x.m });
  if (modo && !c.gd.length) { o = mdOp(); p = c.pers ? mdPers() : 0; auto = true }
  else if (!modo) { p = c.pers ? mdPers() : 0 }
  var base = o + p + c.ex;
  return { fo: fo, pe: p, op: o, ex: c.ex, base: base, nec: base + fo, mi: c.mi, modo: modo, auto: auto, t: base + fo }
}
/* Lo disponible hoy para fondos: ingresos menos los gastos del día (modo ingresos) o la ganancia real (modo anterior). */
function mdDisp() { var m = mdMeta(); return m.modo ? Math.max(0, Math.floor(ingHoy() - m.base)) : ganHoy() }
function mdHTML() {
  var c = mdCfg(); if (!c.on) return ''; var m = mdMeta(); if (!(m.t > 0 || m.mi > 0)) return '';
  if (!m.modo) {
    var g = Math.max(0, ganHoy()), p = Math.min(100, Math.round(g / m.t * 100)), f = m.t - g;
    return '<h2>🎯 Meta del día · ' + cop(m.t) + '</h2><div class="card"><div class="pbar' + (f <= 0 ? ' ok' : '') + '"><i style="width:' + p + '%"></i></div>' +
      '<small>' + (f > 0 ? 'Llevas <b>' + cop(g) + '</b> de ganancia real · faltan <b>' + cop(f) + '</b>' : '✅ Cubriste lo del día. Lo que sigue es ganancia libre: <b>' + cop(-f) + '</b>') + '</small>' +
      '<div style="height:6px"></div>' + kv('📌 Fondos de hoy', cop(m.fo)) + (m.pe ? kv('👤 Personales habituales', cop(m.pe)) : '') + (m.ex ? kv('➕ Valor extra', cop(m.ex)) : '') + '</div>'
  }
  var I = Math.max(0, ingHoy()), T = Math.max(m.mi, m.nec), pc = Math.min(100, Math.round(I / T * 100)), msg;
  if (I < m.base) msg = 'Faltan <b>' + cop(m.base - I) + '</b> para cubrir tus gastos del día'
  else if (I < m.nec) msg = '✅ Gastos cubiertos · faltan <b>' + cop(m.nec - I) + '</b> para apartar todos los fondos'
  else if (I < T) msg = '✅ Gastos y fondos cubiertos · faltan <b>' + cop(T - I) + '</b> para tu meta de ' + cop(m.mi)
  else msg = '🎉 Meta cumplida · vas <b>' + cop(I - T) + '</b> por encima';
  var warn = (m.mi > 0 && m.mi < m.nec) ? '<div class="li"><small>⚠️ Con tus gastos y fondos, tu meta de <b>' + cop(m.mi) + '</b> no alcanza: necesitas <b>' + cop(m.nec) + '</b> (faltan ' + cop(m.nec - m.mi) + '). Los fondos de menor prioridad esperarán.</small></div>' : '';
  return '<h2>🎯 Meta del día · ' + cop(T) + '</h2><div class="card"><div class="pbar' + (I >= T ? ' ok' : '') + '"><i style="width:' + pc + '%"></i></div>' +
    '<small>Llevas <b>' + cop(I) + '</b> de ingresos · ' + msg + '</small>' + warn + '<div style="height:6px"></div>' +
    kv('🧾 Gastos del día' + (m.auto ? ' <small>(promedio 30 días)</small>' : ''), cop(m.op + m.pe)) +
    kv('📌 Fondos de hoy', cop(m.fo)) + (m.ex ? kv('➕ Valor extra', cop(m.ex)) : '') +
    kv('<b>Para cubrir todo</b>', '<b>' + cop(m.nec) + '</b>') + (m.mi ? kv('🎯 Tu meta de ingresos', cop(m.mi)) : '') + '</div>'
}
/* ---------- orden de prioridad de los fondos ---------- */
function fxIx(f) { var i = (S.fxo || []).indexOf(f.id); return i < 0 ? 1000 : i }
function fxOrdList() {
  return fxActivos().sort(function (a, b) { return fxIx(a) - fxIx(b) || (a.tp === 'fijo' ? 0 : 1) - (b.tp === 'fijo' ? 0 : 1) || (a.pr || 5) - (b.pr || 5) || (a.pv || Infinity) - (b.pv || Infinity) })
}
function ctlOrden() {
  var l = fxOrdList();
  openM('<h3>↕️ Orden de prioridad</h3><small>Si un día no alcanza para todo, se aparta primero lo de arriba.</small><div style="height:8px"></div>' +
    (l.length ? l.map(function (f, i) {
      return '<div class="row" style="align-items:center;gap:8px;margin-bottom:6px"><span style="flex:1">' + (i + 1) + '. ' + esc(f.ic || (f.tp === 'fijo' ? '📌' : '🎯')) + ' ' + esc(f.nom) + ' <small>' + (f.tp === 'fijo' ? 'fijo' : 'ahorro') + '</small></span>' +
        '<button class="mini" aria-label="Subir" ' + (i === 0 ? 'disabled' : '') + ' onclick="ctlMover(\'' + f.id + '\',-1)">▲</button><button class="mini" aria-label="Bajar" ' + (i === l.length - 1 ? 'disabled' : '') + ' onclick="ctlMover(\'' + f.id + '\',1)">▼</button></div>'
    }).join('') : '<div class="li"><small>Aún no tienes fondos fijos ni de ahorro.</small></div>') +
    '<button class="btn" style="margin-top:8px" onclick="closeM();render()">Listo</button>')
}
function ctlMover(id, d) {
  var ids = fxOrdList().map(function (f) { return f.id }), i = ids.indexOf(id), j = i + d; if (i < 0 || j < 0 || j >= ids.length) return;
  var t = ids[i]; ids[i] = ids[j]; ids[j] = t; S.fxo = ids; sv(); ctlOrden()
}
/* Reparte lo ganado hoy (neto de costos) por orden de prioridad. Con el límite apagado, se aparta todo lo que toca. */
function fxAsig(l) {
  var cfg = mdCfg(), rem = Infinity;
  if (cfg.lim) { var ap = 0; fxActivos().forEach(function (f) { ap += fxAporteHoy(f) }); rem = Math.max(0, Math.floor(mdDisp() - ap)) }
  return l.map(function (x) { var a = Math.min(x.v, rem); rem -= a; return { f: x.f, v: x.v, a: a } })
}
function mdGd() { return (S.mdc && Array.isArray(S.mdc.gd)) ? S.mdc.gd.slice() : [] }
function mdMiSet(v) { var n = parseFloat(v); mdSet('mi', n > 0 ? Math.round(n) : 0) }
function mdGdSet(i, k, v) {
  var l = mdGd(), x = Object.assign({}, l[i]); if (!l[i]) return;
  if (k === 'm') { var n = parseFloat(v); if (!(n > 0)) { l.splice(i, 1); mdSet('gd', l); return } x.m = Math.round(n) } else if (k === 't') x.t = v === 'o' ? 'o' : 'p'; else x.n = String(v || '').trim() || 'Gasto';
  l[i] = x; mdSet('gd', l)
}
function mdGdAdd() {
  var n = ($('#mgn').value || '').trim(), m = Math.round(parseFloat($('#mgm').value)), t = $('#mgt').value === 'o' ? 'o' : 'p';
  if (!n) { toast('Escribe el nombre del gasto'); return } if (!(m > 0)) { toast('Escribe un valor mayor que 0'); return }
  var l = mdGd(); l.push({ n: n, m: m, t: t }); mdSet('gd', l)
}
function ctlGdHTML() {
  var l = mdGd(), o = 0, p = 0; l.forEach(function (x) { if (+x.m > 0) { if (x.t === 'o') o += +x.m; else p += +x.m } });
  return '<label>Mi meta de ingresos por día (opcional)<input type="number" inputmode="numeric" min="0" value="' + (mdCfg().mi || '') + '" onchange="mdMiSet(this.value)"></label>' +
    '<div style="margin:6px 0"><b>🧾 Mis gastos de un día normal</b><br><small>Lo que gastas casi todos los días aunque lo anotes al llegar a casa. La meta suma esto + los fondos y se ajusta sola si agregas o cambias un fondo.</small></div>' +
    l.map(function (x, i) {
      return '<div class="row" style="align-items:center;gap:6px;margin-bottom:10px;flex-wrap:wrap"><input style="flex:1 1 100%" type="text" value="' + esc(x.n) + '" onchange="mdGdSet(' + i + ',\'n\',this.value)">' +
        '<input style="flex:1 1 40%;min-width:0" type="number" inputmode="numeric" min="0" value="' + x.m + '" onchange="mdGdSet(' + i + ',\'m\',this.value)">' +
        '<select style="flex:1 1 40%;min-width:0" onchange="mdGdSet(' + i + ',\'t\',this.value)"><option value="p"' + (x.t !== 'o' ? ' selected' : '') + '>👤 Personal</option><option value="o"' + (x.t === 'o' ? ' selected' : '') + '>🏍️ Operativo</option></select></div>'
    }).join('') +
    (l.length ? '<small>Total: <b>' + cop(o + p) + '</b> (operativos ' + cop(o) + ' · personales ' + cop(p) + '). Poner 0 en un valor lo quita.</small>' : '<small>Aún no hay gastos. Sin lista se usa el promedio de tus últimos 30 días.</small>') +
    '<div class="row" style="align-items:center;gap:6px;margin:8px 0;flex-wrap:wrap"><input id="mgn" style="flex:1 1 100%" type="text" placeholder="Ej. Almuerzo"><input id="mgm" style="flex:1 1 40%;min-width:0" type="number" inputmode="numeric" min="0" placeholder="Valor">' +
    '<select id="mgt" style="flex:1 1 40%;min-width:0"><option value="p">👤 Personal</option><option value="o">🏍️ Operativo</option></select></div>' +
    '<button class="btn out" onclick="mdGdAdd()">➕ Agregar gasto</button>'
}
function ctlHTML() {
  var c = mdCfg();
  return '<h2>🎯 Meta del día y prioridades</h2><div class="card form">' +
    '<label class="ck"><input type="checkbox" ' + (c.on ? 'checked' : '') + ' onchange="mdSet(\'on\',this.checked)"> <span>Mostrar la meta del día</span></label>' +
    ctlGdHTML() +
    '<label class="ck"><input type="checkbox" ' + (c.pers ? 'checked' : '') + ' onchange="mdSet(\'pers\',this.checked)"> <span>Si no hay lista de gastos, usar mis gastos personales habituales (promedio de 30 días)</span></label>' +
    '<label>Valor extra fijo por día (opcional)<input type="number" inputmode="numeric" min="0" value="' + (c.ex || '') + '" onchange="mdExSet(this.value)"></label>' +
    '<label class="ck"><input type="checkbox" ' + (c.lim ? 'checked' : '') + ' onchange="mdSet(\'lim\',this.checked)"> <span>“Apartar todo” solo con lo disponible hoy, por orden de prioridad</span></label>' +
    '<button class="btn out" onclick="ctlOrden()">↕️ Orden de prioridad de los fondos</button></div>'
}
