# Finanzas + Jornada (PWA)

## Publicar en Netlify
1. Entra a https://app.netlify.com/drop
2. Arrastra la CARPETA `finanzas-jornada` (descomprimida) o el contenido del ZIP.
3. Abre la URL https (Netlify la da automáticamente) en Chrome de Android.
4. Menú ⋮ → "Instalar aplicación" / "Añadir a pantalla de inicio".

## Notas
- Los datos se guardan en el navegador (localStorage, clave `fj1`). No hay nube.
- Abre la app una vez con internet; después funciona sin conexión.
- Al publicar cambios, sube `VERSION` en `service-worker.js` (p. ej. `fj-v4`).
- Los datos viven en el dominio donde se usa la app: si cambias de URL, no se trasladan.

## Etapa 0 — Seguridad y respaldo (fj-v4)
- `js/seguridad.js` (nuevo): copias internas en IndexedDB (`fj-seguridad`), importar/restaurar, normalización aditiva y verificación de conteos/totales. Se usa desde Ajustes → «Seguridad de datos».
- Los datos siguen en `localStorage` clave `fj1`. No se borra ni se cambia ningún valor; solo se añade el campo `esq` al siguiente guardado.
- Copias internas: `original` (primera, nunca se borra), `auto` (máx. 1 cada 24 h, últimas 7), `manual` (últimas 10), `pre-restauracion` (últimas 5) y `corrupto` (si fj1 no se puede leer).

## Etapa 1 — Refactor sin cambios funcionales (fj-v5)
`index.html` ahora solo contiene la estructura; el código se separó tal cual (sin cambiar lógica ni cálculos ni diseño):
- `css/app.css`: todos los estilos.
- `js/seguridad.js`: copias internas, importar/restaurar y verificación (Etapa 0).
- `js/estado.js`: estado `S`, utilidades y cálculos (`js`, `dash`, `wal`).
- `js/acciones.js`: acciones sobre jornadas, pausas, carreras y movimientos; ventanas.
- `js/vistas.js`: vistas Inicio, Jornada, Movimientos y Historial.
- `js/ajustes.js`: `exportBackup` y vista de Ajustes.
- `js/finanzas.js` (Etapa 2): pestaña 💰 Finanzas y sus subpestañas.
- `js/fondos.js` (Etapa 2): Fondos y metas.
- `js/app.js`: `render`, navegación y arranque.
Son scripts clásicos (no módulos) y el **orden en `index.html` importa**. Al cambiar cualquier archivo, sube `VERSION` en `service-worker.js` y añade los archivos nuevos a `CORE`.

## Etapa 2 — Fondos (fj-v6)
- Nueva pestaña inferior **💰 Finanzas** con subpestañas Fondos, Deudas, Préstamos y Presupuesto (las cuatro están activas desde la Etapa 4).
- Datos nuevos en `fj1`: `S.fo` (fondos) y `S.fm` (movimientos: `inicial`, `aporte`, `retiro`). El saldo y el progreso se calculan, no se guardan.
- Cada aporte o retiro puede afectar una billetera (aporte = sale de la billetera, retiro = entra) o no afectar ninguna. `wal()` suma ese efecto; sin fondos devuelve exactamente lo mismo que antes. En la tarjeta de la billetera se ve como `↔`.
- Eliminar un fondo borra sus movimientos y revierte su efecto en las billeteras; archivarlo lo oculta sin perder nada.
- `js/seguridad.js` valida, cuenta y verifica también los fondos al importar, restaurar y verificar.


## Etapa 3 — Deudas y Préstamos (fj-v7)
- `js/cuentas.js` (nuevo): una sola mecánica configurada para las dos listas.
- **Deudas** (lo que debes): `S.de` y `S.dm` (movimientos `inicial`, `pago`, `cargo`). Pago = sale de la billetera; aumento = entra.
- **Préstamos** (lo que te deben): `S.pr` y `S.pm` (movimientos `inicial`, `cobro`, `prestamo`). Cobro = entra a la billetera; prestar más = sale.
- Cada uno tiene fecha límite opcional (avisos de «vence hoy / vencida»), barra de progreso, archivar y eliminar (la eliminación revierte el efecto en billeteras).
- El saldo se calcula, no se guarda. No se puede pagar/cobrar más que el saldo ni dejarlo en negativo. `inicial` nunca toca billeteras.
- `wal()` suma estos movimientos (se ven como `↔` en la billetera); sin deudas ni préstamos devuelve exactamente lo mismo que antes.

## Etapa 4 — Presupuesto (fj-v7)
- `js/presupuesto.js` (nuevo): `S.pp` = límites `{id,tipo:'costo'|'personal',cat,lim}`, uno por categoría (las mismas de Movimientos). El límite se repite cada mes.
- Lo gastado sale de los movimientos del mes elegido (no se modifica nada de ellos). Barras en verde / ámbar (≥80 %) / rojo (excedido), total restante y cuánto puedes gastar por día en el mes actual.
- `js/seguridad.js` ahora también normaliza, valida, cuenta y verifica deudas, préstamos y presupuesto al importar, restaurar y verificar. Copias antiguas (sin estos datos) se siguen restaurando sin problema.

## Categorías propias (fj-v8)
- En Presupuesto, «➕ Nueva categoría» (costos operativos o gastos personales), con límite opcional. Datos: `S.cc` = `{id,tipo,nom}`.
- Las categorías propias también salen al registrar movimientos (`fillC` usa `ppCats`). Eliminar una categoría quita su límite pero no toca los movimientos.
- `js/seguridad.js` normaliza, valida y cuenta `S.cc`.

## Sin billetera Efectivo (fj-v9)
- `BIL` = Dinero digital y Propinas: son las únicas que ofrecen los formularios (movimientos, transferencias, fondos, deudas, préstamos).
- `BIL_OLD` = Efectivo, solo para datos antiguos: `wal()` y la seguridad lo siguen calculando/validando, así que ningún saldo cambia ni se rechazan copias viejas. Se muestra solo si tiene historial y solo se ofrece al editar un registro que ya lo usa.

## Disponible = saldo real (fj-v10)
- En Inicio, «Disponible ahora» es la suma de los saldos de las billeteras (no depende de Hoy/Semana/Mes). Ganancia real y Ganancia/hora siguen siendo del periodo.
- En Historial y detalle de jornada, lo que antes se llamaba «Disponible» (ganancia − gastos personales de ese periodo) ahora es «Neto tras gastos».

## Entrega 1 de la etapa 5 — Billeteras flexibles, apps y viaje rápido (fj-v11)
- **Billeteras** (`js/billeteras.js`, `S.bw`): se crean, renombran, archivan y eliminan (solo sin movimientos). Los movimientos guardan la *clave* `k` (nunca el nombre), así renombrar es seguro. Claves base: `Dinero digital` (ahora «Nequi»), `Daviplata`, `Efectivo`, `Propinas`. «Ajustar saldo» crea un movimiento `ajuste` (no es ingreso ni gasto).
- **Apps** (`js/apps.js`, `S.ap`, `S.am`): saldo de DiDi/Uber = parte pagada con tarjeta de cada viaje − comisión del viaje + premios/ajustes/comisiones/recargas/retiros. Retiro «en camino» no toca billeteras hasta marcarlo «Ya llegó». «Cuadrar» registra la diferencia como premio (ingreso), recarga o comisión (costo) o ajuste (neutral).
- **Viaje rápido** (`js/viaje.js`): monto + un toque en el método (App / cada billetera / Combinado) y se guarda; «Deshacer» durante 6 s; «Repetir último viaje». Carrera nueva = `{v,p,ap,pg:[{k:'a'|'b',b,v}],tf,cm,pb}`. Las carreras antiguas (sin `pg`) siguen acreditando a `Dinero digital` y `Propinas` como siempre.
- Costos/ingresos de apps entran a Inicio, Jornada y Presupuesto (recarga → «Alquiler de moto»).
- `seguridad.js` normaliza/valida/cuenta billeteras, apps, movimientos de apps y pagos de viajes; las copias anteriores se siguen restaurando.

## Entrega 2 y 3 (fj-v13) — Pase 24 h, Por cobrar, recordatorios, ingresos y rediseño
- **Pase de 24 h** (`js/apps.js`): comisión adelantada. Evento `recarga` en `S.am` (activo 24 h desde su hora; `a.pase` = valor habitual, 9.000 por defecto). Al guardar un viaje con tarjeta sin pase activo se pregunta «¿Se cobró el pase?» (`S.apq` evita insistir 3 h tras «No»). Cuenta como costo en la categoría «Comisión y pase de apps» (también comisión por viaje `cm` y comisiones de apps).
- **Por cobrar** (`js/cuentas.js`, `S.xc`/`S.xm`): mismo motor que Deudas/Préstamos. El cobro (`cobro`) entra a la billetera elegida y cuenta como INGRESO el día en que se cobra (`amWin`). «A por cobrar» en Movimientos convierte un ingreso ya anotado.
- **Recordatorios** (`js/avisos.js`): panel «Pendientes» en Inicio + contador en Finanzas; notificaciones al abrir la app (y Periodic Background Sync si Android lo permite, copia en IndexedDB `fj-avisos`); `.ics` para alarmas exactas; `S.av` = {on,dias}; fondos con `fr` (aportar cada N días).
- **Presupuesto**: ingresos del mes por app, neto y meta mensual (`S.meta`).
- **Rediseño** (`js/diseno.js` + bloque final de `css/app.css`): íconos SVG, tokens nuevos claro/oscuro, gráfico de 7 días, barra inferior con contador. Solo presentación.
- `seguridad.js` cubre `xc`/`xm` y los nuevos campos.

## fj-v14 — pase quitable, presupuesto semanal, moto
- **Quitar pase**: botón en Jornada (junto a «Pase activo») y en la app; elimina el cobro (`recarga`) y devuelve saldo/costo.
- **Presupuesto semanal**: selector Mensual | Semanal (semana lunes–domingo). Los límites semanales guardan `p:'s'`; meta semanal en `S.metaS`. Ingresos, neto y «por día» se calculan por la vista elegida.
- **Moto**: nuevo ícono de moto y silueta grande en la tarjeta de Jornada.
- Ganancia/hora no se calcula con menos de 5 min de tiempo efectivo (evita cifras absurdas al iniciar).

## Etapa 8 — Mejoras (fj-v15)
Todo es aditivo: no cambia ni borra datos existentes (se comprobó que saldos, ganancias, apps, deudas y presupuesto dan exactamente lo mismo que antes). Código nuevo en `js/mejoras.js`.
- **Punto rojo** pequeño, sin número, en la esquina superior del ícono de Finanzas. Se apaga en Ajustes → Avisos.
- **Avisos configurables**: anticipación (1–15 días), hora del aviso, qué tipos avisar (deudas, préstamos, por cobrar, gastos fijos, fondos, presupuesto al 80 %, retiros, pase) y un aviso propio en cada deuda, cobro o gasto fijo (campo `rd`).
- **Pausas**: categorías propias (`S.pc`), con «➕ Nueva categoría» al pausar y «Gestionar» en Ajustes. Las 9 originales no se quitan; las pausas ya guardadas conservan su nombre.
- **Por cobrar unificado**: una sola lista con préstamos y cobros. Cada registro tiene tipo (`tp`: préstamo de dinero · carrera o domicilio · los que crees en `S.ct`), fecha de inicio (`fi`) y fecha límite (`fv`). Los datos siguen en `S.pr/S.pm` y `S.xc/S.xm`; no hubo migración. Préstamo de dinero: lo cobrado no cuenta como ingreso. Carrera o domicilio: sí. «🔍 Duplicados» propone y, con copia interna previa, elimina.
- **Deudas**: fecha de inicio, fecha límite y cuota mensual con día de pago (`cq`, `cd`); con cuota se crea su fondo de pago.
- **Rentabilidad por app** en Historial (día, semana, mes, rango) y marca de la app ganadora en el calendario. Ranking por ganancia neta (viajes + propinas + premios − comisiones − pases) y por viaje.
- **Premios**: con fecha y tipo (`pt`: meta de viajes, bono, otro), editables, y visibles en el Historial y en el detalle de la jornada.
- **Fondos fijos y de ahorro**: `tp` fijo/ahorro, monto `mo`, frecuencia `fq`, próximo pago `pv`, ahorro por día `ad` o % `ap`, prioridad `pr`, billetera `bl`, pausa `pz`. «📌 Apartar hoy» en Inicio; «Pagar» descuenta del fondo (y de la deuda enlazada `ld`). Al primer arranque se crean vacíos «Celular Tigo» (99.000), «Aporte casa» y «Moto» (marca `S.sd`).
- **Presupuesto**: límite en % de ingresos, proyección de cierre, comparación con el periodo anterior, detalle por categoría (🔎), alerta al 80 %, y «Apartado a fondos / Libre después de apartar».

## Etapa 9 — Promociones e incentivos (fj-v16)
Todo es aditivo (con los mismos datos, saldos, ganancias, apps, deudas y presupuesto dan igual que en fj-v15). Código nuevo en `js/promos.js`.
- **Promociones** dentro de cada app (`S.px`): meta por viajes con tramos (45 → $30.000, 70 → $50.000) o bono por viaje (monto fijo o % de la tarifa). Horario, «Copiar la última», ajuste manual −1/+1. El conteo y el premio estimado se calculan de los viajes registrados.
- **Registro previo** (Uber): `rq` + límite `rl`. Avisos a las horas elegidas (por defecto 6, 7 y 9 p. m., editables en Ajustes → Avisos y por promoción) que se detienen con «Ya me registré». Cuentan para el punto rojo. «⏰ Crear alarma diaria en el calendario» genera un .ics con alarmas repetidas diarias.
- **Premio**: «Registrar premio» crea un movimiento `premio` normal (con `px` = id de la promoción) o lo deja como **esperado** hasta que llegue (aviso en Pendientes). Si borras ese premio, la promoción vuelve a abrirse.
- **Promos de hoy** en Inicio y en Jornada (con «¿Revisaste las promos de …?») y aviso cuando faltan pocos viajes para la meta.
- **Comisión de retiro** (`cr` en el movimiento `retiro`; habitual por app `rf` fijo o `rp` %): a la billetera llega monto − comisión y la comisión cuenta como costo de la app.
- **Rentabilidad por app**: ahora separa «directo a ti» y «pagado por la app (tarjeta)» e incluye las comisiones de retiro.

## Ajuste fj-v17
Historial cuenta ingresos, costos y personales por la fecha en que se registraron (igual que Inicio), no solo los que caen dentro del horario de la jornada.

## Etapa 10 (fj-v18): meta de la jornada
- Meta en horas y minutos, efectivas (sin pausas) o corridas; botones 6/8/10/12 h; recuerda la última elección.
- Pausas previstas (desayuno, almuerzo…): la salida estimada las suma y se corrige sola con las pausas reales.
- Progreso en la jornada, botón "Cambiar meta", avisos (falta poco / meta cumplida / ¿estás en pausa?) configurables en Ajustes.
- Campos nuevos opcionales: j.mt, j.pv, S.jc. Las jornadas anteriores siguen como horas corridas.

## Etapa 11 (fj-v19)
- Ajustes → Copia de seguridad: compartir (Drive/WhatsApp) con recordatorio cada N días.
- Ajustes → Empezar de cero: copia interna + archivo y luego borra todo (confirmar escribiendo BORRAR).
- Meta del día (Inicio y Jornada): fondos de hoy + gastos personales habituales (+ extra opcional) frente a la ganancia real de hoy.
- Orden de prioridad de fondos; "Apartar" reparte lo ganado hoy por ese orden. Claves nuevas: S.bk, S.mdc, S.fxo.

## Ajuste fj-v20
Una pausa prevista que ya terminó se da por cumplida aunque durara menos de lo previsto (ya no queda un resto pendiente).

## Ajuste fj-v21
Salida estimada (horas efectivas) = inicio + meta + solo las pausas reales. Las pausas previstas ya no se suman: aparecen como referencia ("si las haces, terminarías hacia…"). Los minutos sugeridos de cada pausa usan tu promedio real de 30 días (con 3 pausas o más); lo que tú cambies a mano se respeta.

## Ajuste fj-v22: pausas previstas flexibles e inteligentes
- Antes de iniciar: interruptor "Usar pausas previstas"; cada pausa con minutos, atajos 15/30/45/60 y tu historial (promedio, rango, % de días); botón "Sugerir según mis últimos días" (pausas que haces 50 % o más de los días).
- Con la jornada en curso: botón "Pausas previstas" para quitar, cambiar minutos o agregar.
- La salida real solo suma pausas reales; se muestra un rango (sin más pausas / con las previstas). Una pausa prevista cuya hora habitual pasó hace más de 3 h se da por omitida.

## Ajuste fj-v23
Poner 0 minutos en una pausa prevista la quita (antes de iniciar y con la jornada en curso).

## Ajuste fj-v24: préstamo de dinero con billetera
Al crear o editar un préstamo de dinero se elige de qué billetera salió el valor (o "Sin billetera"). El movimiento inicial lleva bil + bd:1 y wal() lo descuenta. Eliminar el préstamo revierte el descuento. Los préstamos anteriores quedan igual hasta que elijas billetera al editarlos.

## Ajuste fj-v25: meta del día inteligente (por ingresos)
En Ajustes → Meta del día: tu meta de ingresos diaria (S.mdc.mi) y la lista "Mis gastos de un día normal" (S.mdc.gd [{n,m,t:'p'|'o'}], personal u operativo). La meta se calcula sola: gastos del día + fondos de hoy (+ valor extra) = "para cubrir todo"; si agregas o cambias un fondo, sube o baja. La barra usa ingresos brutos de hoy (no se duplica el costo que anotas en casa) y avisa la etapa: gastos, fondos, tu meta. Si tu meta no alcanza, lo advierte. Sin lista usa el promedio de 30 días. "Apartar" usa lo disponible = ingresos − gastos del día. Sin meta ni lista, queda el comportamiento anterior (ganancia real).

## Ajuste fj-v26: comprobantes de transferencia en las carreras
Nuevo js/comprobantes.js. Se puede adjuntar una foto/captura del pago (y una referencia opcional) a cada carrera: en Registrar viaje (antes de tocar cómo te pagaron), en la ventana de editar/pago combinado y, en la lista, con el botón "📎 Adjuntar" de las carreras pagadas por billetera que no sea Efectivo. La foto se comprime (máx. 1280 px, JPEG) y se guarda en IndexedDB 'fj-comprobantes'; la carrera solo guarda c.cp (id) y c.rf (referencia). Las fotos NO van en la copia de seguridad. Borrar la carrera o "borrar todo" elimina las fotos; las huérfanas de más de un día se limpian solas. Ajustes muestra cuántas fotos hay.

## Ajuste fj-v27
Comprobantes: dos botones separados, "📷 Tomar foto" (abre la cámara, capture=environment) y "🖼️ Galería" (elegir captura), en el registro de viaje, en editar/combinado y en la lista. Antes un solo botón dependía del selector de archivos del teléfono, que en algunos equipos no ofrece cámara.

## Ajuste fj-v28: gastos programados con confirmación + comprobante en gastos
- Nuevo js/programados.js. S.gp = gastos programados (nombre, valor, personal/operativo, categoría, billetera, frecuencia: diaria, días de la semana, día del mes o cada N días, hora opcional). S.gl = bitácora de confirmaciones.
- Inicio muestra "Por confirmar hoy": ✅ Sí, fue eso (registra el gasto real con la hora real), ✏️ Otro (valor, billetera, nota y comprobante), ⏭️ No. Nada se registra hasta confirmar. Si ya lo anotaste a mano (mismo tipo y categoría, valor ±25 %), pregunta "¿es ese?" para no duplicar. Aprende el valor (promedio de las últimas 5 confirmaciones), sugiere pausar si se omite 3 veces seguidas y avisa (tipo de aviso 'gp') cuando llega la hora.
- Configuración en Ajustes → Gastos programados (importar desde "Mis gastos de un día normal").
- Movimientos: se puede adjuntar comprobante (📷/🖼️) y referencia a cualquier movimiento (c.cp, c.rf). Eliminar el gasto lo vuelve a dejar pendiente.

## Ajuste fj-v29: corte y cierre con saldos
- Nuevo js/corte.js. "✂️ Hacer corte" (Inicio y Jornada): escribes lo que tienes de verdad en cada billetera y app; la diferencia con lo que calcula la app se explica antes de guardar: billetera + → carreras (bloque por forma de pago), otro ingreso, ajuste; billetera − → gasto olvidado, gasto programado pendiente, ajuste; app + → carreras 💳 App, premio, ajuste; app − → pase de 24 h, comisión, ajuste. Nada se registra hasta "Guardar corte".
- Los bloques son carreras con bl:1 en la jornada del día (si ese día no hay jornada se crea una jornada man:1 sin horas). Las diferencias de ayer se pueden fechar "ayer" (S.sn guarda fotos de saldo; cada corte deja todo cuadrado, así el siguiente solo ve lo nuevo).
- Arranque de un toque ("Siguen igual"), "Este corte cierra el día" (S.cd), base de efectivo, sugerencia del siguiente corte (+$ configurable por app), avisos (por tiempo y en pausas).
- Una comisión o pase registrado con pase activo se marca ex:1 = cobro fuera del pase; se suma en la tarjeta (30 días).
