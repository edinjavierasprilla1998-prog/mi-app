/* Service Worker - Finanzas + Jornada. Cambia VERSION al publicar cambios. */
var VERSION = 'fj-v29';
var CORE = [
  './', './index.html', './css/app.css',
  './js/seguridad.js', './js/estado.js', './js/acciones.js', './js/vistas.js', './js/ajustes.js', './js/finanzas.js', './js/fondos.js', './js/cuentas.js', './js/billeteras.js', './js/apps.js', './js/viaje.js', './js/avisos.js', './js/diseno.js', './js/presupuesto.js', './js/mejoras.js', './js/promos.js', './js/meta.js', './js/control.js', './js/comprobantes.js', './js/programados.js', './js/corte.js', './js/app.js',
  './manifest.webmanifest', './favicon.ico',
  './icons/icon-192.png', './icons/icon-512.png',
  './icons/maskable-192.png', './icons/maskable-512.png',
  './icons/apple-touch-icon.png', './icons/favicon-16.png', './icons/favicon-32.png'
];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(VERSION).then(function (c) { return c.addAll(CORE); }).then(function () { return self.skipWaiting(); }));
});

self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (ks) {
    return Promise.all(ks.filter(function (k) { return k !== VERSION; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});

self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET') return;
  var url = new URL(req.url);

  // Navegación: red primero (para recibir actualizaciones), caché si no hay conexión
  if (req.mode === 'navigate') {
    e.respondWith(fetch(req).then(function (r) {
      var cp = r.clone(); caches.open(VERSION).then(function (c) { c.put('./index.html', cp); });
      return r;
    }).catch(function () { return caches.match('./index.html'); }));
    return;
  }

  // Mismo origen y fuentes de Google: caché primero, y se guarda lo nuevo
  if (url.origin === location.origin || /fonts\.(googleapis|gstatic)\.com$/.test(url.hostname)) {
    e.respondWith(caches.match(req).then(function (hit) {
      if (hit) return hit;
      return fetch(req).then(function (r) {
        if (r && (r.ok || r.type === 'opaque')) { var cp = r.clone(); caches.open(VERSION).then(function (c) { c.put(req, cp); }); }
        return r;
      }).catch(function () { return hit; });
    }));
  }
});

/* Avisos (Etapa 6): clic en una notificación abre la app; Periodic Background Sync muestra los avisos que ya tocan (copia en IndexedDB 'fj-avisos'). */
self.addEventListener('notificationclick', function (e) {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (l) { if (l.length) return l[0].focus(); return self.clients.openWindow('./') }))
});
self.addEventListener('periodicsync', function (e) {
  if (e.tag !== 'fj-avisos') return;
  e.waitUntil(new Promise(function (res) {
    var r = indexedDB.open('fj-avisos', 1);
    r.onupgradeneeded = function () { r.result.createObjectStore('a') };
    r.onerror = function () { res() };
    r.onsuccess = function () {
      var db = r.result, tx = db.transaction('a', 'readwrite'), st = tx.objectStore('a'), g = st.get('items');
      g.onsuccess = function () {
        var l = g.result || [], now = Date.now(), ps = [];
        l.forEach(function (x) { if (!x.hecho && x.t <= now) { x.hecho = true; ps.push(self.registration.showNotification(x.title, { body: x.body, tag: x.k, icon: 'icons/icon-192.png' })) } });
        st.put(l, 'items'); tx.oncomplete = function () { Promise.all(ps).then(function () { res() }, function () { res() }) }
      };
      g.onerror = function () { res() }
    }
  }))
});
